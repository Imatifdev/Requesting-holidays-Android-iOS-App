package com.example.transactionsapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
