class ApiManager {
  static const loginBaseUrl =
      "https://intenstest12.herokuapp.com/api/user/login";
}
