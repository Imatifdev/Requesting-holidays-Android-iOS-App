import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import 'package:hive/hive.dart';

import '../models/current_balance_model.dart';
import '../networks/apicall.dart';
import 'package:http/http.dart' as http;

class GetBalanceController extends GetxController {


 

  Future<CurrentBalance?> getCurrentBalance() async {
    String token = Hive.box('box').get('token');
    String url = '${baseURL}api/v1/get_user_balance';

    final response = await http.get(Uri.parse(url), headers: {
      "Accept": "application/json",
      "Authorization": 'Bearer $token'
    });

    if (response.statusCode == 200) {
      var data = jsonDecode(response.body);
      CurrentBalance currentBalance = CurrentBalance.fromJson(data);
      return currentBalance;
    }
    return null;
  }
}
