import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:http/http.dart' as http;

import '../models/getspecificorderbyusertype.dart';
import '../networks/apicall.dart';

class OrderController extends GetxController {
  
  Future<GetSpecificOrderByUsertype> orderFetch() async {
    String token = Hive.box('box').get('token');
    String url = '${baseURL}api/v1/get_specific_order_by_usertype';
    final response = await http.get(
      Uri.parse(url),
      // Send authorization headers to the backend.
      headers: {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
    );
    if (response.statusCode == 200) {
      // If the server did return a 200 OK response,
      // then parse the JSON.
      var data = jsonDecode(response.body);

      GetSpecificOrderByUsertype orderByUsertype =
          GetSpecificOrderByUsertype.fromJson(data);

   
      return orderByUsertype;
    } else {
      
      throw Exception('Failed to load album');
    }
  }
}
