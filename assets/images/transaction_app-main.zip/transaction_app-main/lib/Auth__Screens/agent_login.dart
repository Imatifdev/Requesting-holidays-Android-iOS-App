// // ignore_for_file: prefer_const_literals_to_create_immutables, prefer_const_constructors, prefer_final_fields, unused_field, depend_on_referenced_packages, avoid_print

// //import 'dart:html';

// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:transactionsapp/Auth__Screens/homeauth.dart';
// import 'package:transactionsapp/screens/Home.dart';
// import 'package:transactionsapp/utils/theme.dart';
// import 'package:transactionsapp/widgets/custombutton.dart';
// import 'package:transactionsapp/widgets/customtext.dart';
// import 'package:transactionsapp/widgets/customtextformfield.dart';
// import 'package:velocity_x/velocity_x.dart';

// class SignupPage extends StatefulWidget {
//   const SignupPage({super.key});

//   @override
//   State<SignupPage> createState() => _SignupPageState();
// }

// class _SignupPageState extends State<SignupPage> {
//   TextEditingController _emailController = TextEditingController();
//   TextEditingController _passController = TextEditingController();
//   TextEditingController _empidController = TextEditingController();

//   bool _ispasshidden = true;
//   void _togglePasswordView() {
//     setState(() {
//       _ispasshidden = !_ispasshidden;
//     });
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//         body: SingleChildScrollView(
//       child: Container(
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           mainAxisAlignment: MainAxisAlignment.start,
//           children: [
//             SizedBox(
//               height: 70,
//             ),
//             IconButton(
//               icon: Icon(
//                 CupertinoIcons.back,
//                 size: 40,
//                 color: AppTheme.darkbg,
//               ),
//               onPressed: () {
//                 Get.to(() => AuthHome());
//               },
//             ).pOnly(
//               right: 30,
//             ),
//             CustomText(
//                     TextValue: "Let's Get Started",
//                     fontweight: FontWeight.bold,
//                     TextColor: AppTheme.darkbg,
//                     fontsize: 40)
//                 .pOnly(left: 20),
//             SizedBox(
//               height: 50,
//             ),
//             Container(
//               width: MediaQuery.of(context).size.width,
//               height: 700,
//               decoration: BoxDecoration(
//                   borderRadius: BorderRadius.only(
//                     topRight: Radius.circular(40.0),
//                     topLeft: Radius.circular(40.0),
//                   ),
//                   color: AppTheme.darkbg),
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   CustomText(
//                       TextValue: "Create an Account",
//                       fontweight: FontWeight.bold,
//                       TextColor: Colors.white,
//                       fontsize: 35),
//                   CustomText(
//                           TextValue: "Email",
//                           fontweight: FontWeight.normal,
//                           TextColor: Colors.white,
//                           fontsize: 16)
//                       .pSymmetric(v: 10),
//                   //email field
//                   CustomTextformfield(
//                     hinttext: "abc@gmail.com",
//                     textInputType: TextInputType.emailAddress,
//                     fillcolor: Colors.white,
//                     controller: _emailController,
//                   ),
//                   CustomText(
//                           TextValue: "Employee id",
//                           fontweight: FontWeight.normal,
//                           TextColor: Colors.white,
//                           fontsize: 16)
//                       .pSymmetric(v: 10),
//                   //email field
//                   CustomTextformfield(
//                     hinttext: "Mxb-----",
//                     textInputType: TextInputType.emailAddress,
//                     fillcolor: Colors.white,
//                     controller: _empidController,
//                   ),

//                   CustomText(
//                           TextValue: "Password",
//                           fontweight: FontWeight.normal,
//                           TextColor: Colors.white,
//                           fontsize: 16)
//                       .pSymmetric(v: 10),
//                   //Password field
//                   TextFormField(
//                     obscureText: _ispasshidden,
//                     controller: _passController,
//                     keyboardType: TextInputType.visiblePassword,
//                     decoration: InputDecoration(
//                       suffixIcon: InkWell(
//                         onTap: _togglePasswordView,
//                         child: Icon(
//                           _ispasshidden
//                               ? Icons.visibility
//                               : Icons.visibility_off,
//                         ),
//                       ),
//                       hintText: "a124266",
//                       fillColor: Colors.white,
//                       focusedBorder: OutlineInputBorder(
//                           borderSide:
//                               BorderSide(width: 1, color: Colors.white)),
//                       border: OutlineInputBorder(
//                           borderSide: BorderSide(width: 1, color: Colors.white),
//                           borderRadius: BorderRadius.circular(20)),
//                       filled: true,
//                       enabledBorder: OutlineInputBorder(
//                         borderRadius: BorderRadius.circular(20),
//                         borderSide: BorderSide(width: 1, color: Colors.white),
//                       ),
//                       errorBorder: OutlineInputBorder(
//                         //<-- SEE HERE
//                         borderSide:
//                             BorderSide(width: 3, color: Colors.redAccent),
//                       ),
//                     ),
//                   ),
//                   CustomBtn(
//                           height: 60,
//                           width: MediaQuery.of(context).size.width,
//                           radius: 20,
//                           btncol: Colors.white,
//                           btntxtcol: AppTheme.darkbg,
//                           btntxt: "Create an Account",
//                           btntextsize: 20,
//                           onTap: () => Get.to(() => HomePage()),
//                           fontw: FontWeight.bold)
//                       .pOnly(top: 50, left: 30, right: 30),
//                   // InkWell(
//                   //   onTap: () {
//                   //     print("Working");
//                   //   },
//                   //   child: Text(
//                   //     "Already have an account? ",
//                   //     style: TextStyle(
//                   //       fontSize: 15,
//                   //       fontWeight: FontWeight.bold,
//                   //       color: Colors.white,
//                   //       decoration: TextDecoration.underline,
//                   //       decorationStyle: TextDecorationStyle.solid,
//                   //     ),
//                   //   ).pSymmetric(v: 10),
//                   // ),

//                   Row(
//                     children: [
//                       Text(
//                         "We don't take care of your privacy",
//                         style: TextStyle(
//                           fontSize: 16,
//                           color: Colors.white,
//                         ),
//                       ),
//                       Text(
//                         "Privacy",
//                         style: TextStyle(
//                             fontSize: 20,
//                             decoration: TextDecoration.underline,
//                             color: AppTheme.lightbg,
//                             fontWeight: FontWeight.bold),
//                       ).pOnly(left: 10),
//                     ],
//                   ).pOnly(top: 30, left: 10),
//                 ],
//               ).pSymmetric(h: 30, v: 20),
//             ),
//           ],
//         ),
//       ),
//     ));
//   }
// }

// ignore_for_file: prefer_const_literals_to_create_immutables, prefer_const_constructors, prefer_final_fields, unused_field, depend_on_referenced_packages, avoid_print

//import 'dart:html';

import 'dart:convert';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:hive/hive.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:transactionsapp/Auth__Screens/homeauth.dart';
import 'package:transactionsapp/models/agent_login_model.dart';
import 'package:transactionsapp/screens/agenthome.dart';
import 'package:transactionsapp/utils/loader.dart';
import 'package:transactionsapp/utils/theme.dart';
import 'package:transactionsapp/widgets/custombutton.dart';
import 'package:transactionsapp/widgets/customtext.dart';
import 'package:transactionsapp/widgets/customtextformfield.dart';
import 'package:velocity_x/velocity_x.dart';

import '../networks/apicall.dart';

class AgentLogin extends StatefulWidget {
  final String? userType;
  const AgentLogin({super.key, this.userType});

  @override
  State<AgentLogin> createState() => _AgentLoginState();
}

class _AgentLoginState extends State<AgentLogin> {
  TextEditingController _emailController = TextEditingController();
  TextEditingController _passController = TextEditingController();
  bool _ispasshidden = true;

  Future login(String email, password) async {
    String email = _emailController.text.toString();
    String password = _passController.text.toString();
    var userCridentials = jsonEncode({'user_code': email, 'password': password});
    PopupLoader.show();
    String url = '${baseURL}api/v1/login';
    final response = await http.post(Uri.parse(url),
        headers: {"Content-Type": "application/json"}, body: userCridentials);
    PopupLoader.hide();
    if (response.statusCode == 200) {
      var data = jsonDecode(response.body);
      var responsedata = AgentLoginModel.fromJson(data);
      Hive.box('box').put('token', responsedata.data!.token);
      Hive.box('box').put('name', responsedata.data!.name);
      if (responsedata.data!.userType == 'agent') {
        Hive.box('box').put('isLogin', true);
        Hive.box('box').put('userType', responsedata.data!.userType.toString());
        Hive.box('box')
            .put('agentType', responsedata.data!.agentType.toString());

        Get.offAll(() => AgentHome());
      } else {
        Fluttertoast.showToast(
            msg: "login failed! your are not a agent.. ",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.TOP,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0);
      }
    } else {
      // If the server did not return a 200 CREATED response,
      // then throw an exception.
      Fluttertoast.showToast(
          msg: "Wrong User Credintials ",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.TOP,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0);
    }
  }

  final _formKey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
          body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          SizedBox(
            height: 50,
          ),
          CustomText(
              TextValue: "Hi,",
              fontweight: FontWeight.bold,
              TextColor: Colors.black,
              fontsize: 35)
              .pOnly(
            left: 20,
          ),
          CustomText(
              TextValue: "Welcome Back!",
              fontweight: FontWeight.bold,
              TextColor: Colors.black,
              fontsize: 35)
              .pOnly(left: 20),
          SizedBox(
            height: 23,
          ),
          Expanded(
            child: Container(
              width: MediaQuery.of(context).size.width,
              height: 600,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.only(
                  topRight: Radius.circular(40.0),
                  topLeft: Radius.circular(40.0),
                ),
                gradient: LinearGradient(
                  begin: Alignment.topRight,
                  end: Alignment.bottomLeft,
                  colors: [
                    AppTheme.profilecardgrad1,
                    AppTheme.profilecardgrad2,
                  ],
                ),
              ),
              child: SingleChildScrollView(
                physics: BouncingScrollPhysics(),
                child: Form(
                  key: _formKey,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      CustomText(
                              TextValue: "Type 2 Login",
                              fontweight: FontWeight.bold,
                              TextColor: Colors.white,
                              fontsize: 30)
                          .pOnly(left: 5, bottom: 10),
                      //email field
                      Agentformfeild(
                          boolTitleShowHide: true,
                          fieldName: "User_code",
                          hint_text: "A0000",
                          returnDatacall: (val) {
                            _emailController.text = val;
                          }),
                      Agentformfeild(
                          boolTitleShowHide: true,
                          fieldName: "Password",
                          hint_text: "************",
                          // rightLabel: "Forget Password",
                          returnDatacall: (val) {
                            _passController.text = val;
                          }),
                      CustomBtn(
                              height: 40,
                              width: 200,
                              radius: 20,
                              btncol: Color(0xff4a4a4a),
                              btntxtcol: AppTheme.btntxt,
                              btntxt: "Login",
                              btntextsize: 16,
                              onTap: () {
                                if (_formKey.currentState!.validate()) {
                                  login(_emailController.text,
                                      _passController.text);
                                }
                                // Navigator.push(
                                //     context, MaterialPageRoute(builder: (BuildContext) => AgentHome()));
                              },
                              fontw: FontWeight.bold)
                          .pOnly(top: 0)
                          .centered(),
                    ],
                  ).pSymmetric(h: 30, v: 40),
                ),
              ),
            ),
          ),
        ],
      )),
    );
  }
}
