// ignore_for_file: prefer_const_literals_to_create_immutables, prefer_const_constructors, prefer_final_fields, unused_field, depend_on_referenced_packages, avoid_print

//import 'dart:html';

import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:hive/hive.dart';

import 'package:http/http.dart' as http;
import 'package:transactionsapp/Auth__Screens/agent_login.dart';
import 'package:transactionsapp/Auth__Screens/homeauth.dart';
import 'package:transactionsapp/models/user_login_model.dart';
import 'package:transactionsapp/networks/apicall.dart';
import 'package:transactionsapp/screens/mainbottom.dart';
import 'package:transactionsapp/utils/loader.dart';
import 'package:transactionsapp/utils/theme.dart';
import 'package:transactionsapp/widgets/custombutton.dart';
import 'package:transactionsapp/widgets/customtext.dart';
import 'package:transactionsapp/widgets/customtextformfield.dart';
import 'package:velocity_x/velocity_x.dart';

class LoginPage extends StatefulWidget {
  final String? userType;

  const LoginPage({super.key, this.userType});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  TextEditingController _emailController = TextEditingController();
  TextEditingController _passController = TextEditingController();
  bool _ispasshidden = true;

  final _formKey = GlobalKey<FormState>();

  Future login(String email, password) async {
    String email = _emailController.text.toString();
    String password = _passController.text.toString();
    var userCridentials =
        jsonEncode({'user_code': email, 'password': password});
    PopupLoader.show();
    String url = '${baseURL}api/v1/login';
    final response = await http.post(Uri.parse(url),
        headers: {"Content-Type": "application/json"}, body: userCridentials);
    PopupLoader.hide();
    if (response.statusCode == 200) {
      var data = jsonDecode(response.body);
      bool successStatus = data['success'];
      String checkStatus = data['data']['status'];
      print(data);
      if (successStatus) {}
      if (checkStatus == "1") {
        var responsedata = UserLoginModel.fromMap(data);
        Hive.box('box').put('token', responsedata.data.token);
        Hive.box('box').put('name', responsedata.data.name);
        Hive.box('box').put('email', email);
        Hive.box('box').put('password', password);
        if (responsedata.data.userType.toString() == 'user') {
          Hive.box('box').put('isLogin', true);
          Hive.box('box')
              .put('userType', responsedata.data.userType.toString());
          Get.to(() => MainScreen());
        } else {
          Fluttertoast.showToast(
              msg: "login failed! your are not a user.. ",
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.TOP,
              timeInSecForIosWeb: 1,
              backgroundColor: Colors.red,
              textColor: Colors.white,
              fontSize: 16.0);
        }
      } else if (checkStatus == "0") {
        Fluttertoast.showToast(
            msg: "Account is de-activated",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.TOP,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0);
      } else if (checkStatus == "2") {
        Fluttertoast.showToast(
            msg: "Account is deleted ",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.TOP,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0);
      }
      ;
    } else {
      // If the server did not return a 200 CREATED response,
      // then throw an exception.
      Fluttertoast.showToast(
          msg: "wrong userCridentials ",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.TOP,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0);
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
          body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          SizedBox(
            height: 50,
          ),
          CustomText(
                  TextValue: "Hi,",
                  fontweight: FontWeight.bold,
                  TextColor: Colors.black,
                  fontsize: 35)
              .pOnly(
            left: 20,
          ),
          CustomText(
                  TextValue: "Welcome Back!",
                  fontweight: FontWeight.bold,
                  TextColor: Colors.black,
                  fontsize: 35)
              .pOnly(left: 20),
          SizedBox(
            height: 23,
          ),
          Expanded(
            child: Container(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height * .70,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.only(
                  topRight: Radius.circular(40.0),
                  topLeft: Radius.circular(40.0),
                ),
                gradient: LinearGradient(
                  begin: Alignment.topRight,
                  end: Alignment.bottomLeft,
                  colors: [
                    AppTheme.profilecardgrad1,
                    AppTheme.profilecardgrad2,
                  ],
                ),
              ),
              child: SingleChildScrollView(
                physics: BouncingScrollPhysics(),
                child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        height: 23,
                      ),
                      CustomText(
                          TextValue: "Customer Login",
                          fontweight: FontWeight.bold,
                          TextColor: Colors.white,
                          fontsize: 35),
                      SizedBox(
                        height: 20,
                      ),
                      //email field
                      textformfeild(
                          boolTitleShowHide: true,
                          fieldName: "User_code",
                          hint_text: "C0000",
                          returnDatacall: (val) {
                            _emailController.text = val;
                          }),
                      textformfeild(
                          boolTitleShowHide: true,
                          fieldName: "Password",
                          hint_text: "*********",
                          // rightLabel: "Forget Password",
                          returnDatacall: (val) {
                            _passController.text = val;
                          }),

                      CustomBtn(
                              height: 40,
                              width: 200,
                              radius: 20,
                              btncol: Color(0xff4a4a4a),
                              btntxtcol: AppTheme.btntxt,
                              btntxt: "Login",
                              btntextsize: 16,
                              onTap: () {
                                if (_formKey.currentState!.validate()) {
                                  login(_emailController.text.trim(),
                                      _passController.text);
                                }
                                // Navigator.push(
                                //     context, MaterialPageRoute(builder: (BuildContext) => Main()));
                              },
                              fontw: FontWeight.bold)
                          .pOnly(top: 0)
                          .centered(),
                      SizedBox(height: 14),
                      Center(
                        child: RichText(
                          text: TextSpan(
                            children: [
                              TextSpan(
                                text: 'Another Type of Account',
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 16,
                                    fontWeight: FontWeight.w500),
                              ),
                              TextSpan(
                                text: '?',
                                style: TextStyle(
                                    color: Colors.redAccent,
                                    fontSize: 18,
                                    fontWeight: FontWeight.w700),
                              ),
                              WidgetSpan(
                                  child: InkWell(
                                onTap: () {
                                  Get.to((AgentLogin(
                                    userType: 'agent',
                                  )));
                                },
                                child: Text(
                                  'Type 2',
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 16,
                                      fontWeight: FontWeight.w900),
                                ),
                              ))
                            ],
                          ),
                        ),
                      )
                    ],
                  ).pSymmetric(h: 20, v: 40),
                ),
              ),
            ),
          ),
        ],
      )),
    );
  }
}
