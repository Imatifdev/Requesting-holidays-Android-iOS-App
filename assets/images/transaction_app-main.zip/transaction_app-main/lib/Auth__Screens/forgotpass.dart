// ignore_for_file: public_member_api_docs, sort_constructors_first
// ignore_for_file: prefer_const_literals_to_create_immutables, prefer_const_constructors, prefer_final_fields, unused_field, depend_on_referenced_packages, avoid_print

//import 'dart:html';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:transactionsapp/Auth__Screens/user_login.dart';
import 'package:transactionsapp/widgets/passfield.dart';
import 'package:velocity_x/velocity_x.dart';

import 'package:transactionsapp/utils/theme.dart';
import 'package:transactionsapp/widgets/custombutton.dart';
import 'package:transactionsapp/widgets/customtext.dart';

class ForGotPass extends StatefulWidget {
  const ForGotPass({super.key});

  @override
  State<ForGotPass> createState() => _ForGotPassState();
}

class _ForGotPassState extends State<ForGotPass> {
  TextEditingController _oldController = TextEditingController();

  TextEditingController _setnewController = TextEditingController();
  TextEditingController _confirmController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          SizedBox(
            height: 70,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              IconButton(
                icon: Icon(
                  CupertinoIcons.back,
                  size: 40,
                  color: AppTheme.darkbg,
                ),
                onPressed: () {
                  Get.to(LoginPage());
                },
              ).pOnly(
                right: 30,
              ),
              CustomText(
                      TextValue: "Create,",
                      fontweight: FontWeight.bold,
                      TextColor: AppTheme.darkbg,
                      fontsize: 40)
                  .pOnly(
                top: 5,
              ),
            ],
          ),
          CustomText(
                  TextValue: "New Password!",
                  fontweight: FontWeight.bold,
                  TextColor: AppTheme.darkbg,
                  fontsize: 40)
              .pOnly(left: 80),
          SizedBox(
            height: 50,
          ),
          Container(
            width: MediaQuery.of(context).size.width,
            height: 624,
            decoration: BoxDecoration(
                borderRadius: BorderRadius.only(
                  topRight: Radius.circular(40.0),
                  topLeft: Radius.circular(40.0),
                ),
                color: AppTheme.darkbg),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // CustomText(
                //     TextValue: "Create ",
                //     fontweight: FontWeight.bold,
                //     TextColor: Colors.white,
                //     fontsize: 35),

                CustomText(
                        TextValue: "Old Password",
                        fontweight: FontWeight.normal,
                        TextColor: Colors.white,
                        fontsize: 16)
                    .pSymmetric(v: 10),
                //Password field
                passfieldwidget(
                  controller: _oldController,
                ),
                CustomText(
                        TextValue: "New Password",
                        fontweight: FontWeight.normal,
                        TextColor: Colors.white,
                        fontsize: 16)
                    .pSymmetric(v: 10),
                //Password field
                passfieldwidget(
                  controller: _oldController,
                ),
                CustomText(
                        TextValue: "Confirm Password",
                        fontweight: FontWeight.normal,
                        TextColor: Colors.white,
                        fontsize: 16)
                    .pSymmetric(v: 10),
                //Password field
                passfieldwidget(
                  controller: _oldController,
                ),
                CustomBtn(
                        height: 50,
                        width: MediaQuery.of(context).size.width,
                        radius: 20,
                        btncol: Colors.white,
                        btntxtcol: AppTheme.darkbg,
                        btntxt: "Set Password",
                        btntextsize: 20,
                        onTap: () {},
                        fontw: FontWeight.bold)
                    .pOnly(top: 50),
              ],
            ).pSymmetric(h: 30, v: 40),
          ),
        ],
      ),
    ));
  }
}
