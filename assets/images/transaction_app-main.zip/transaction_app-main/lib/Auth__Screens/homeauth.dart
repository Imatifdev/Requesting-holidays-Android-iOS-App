// ignore_for_file: prefer_typing_uninitialized_variables, sized_box_for_whitespace, avoid_unnecessary_containers, avoid_print, prefer_const_constructors, depend_on_referenced_packages

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:velocity_x/velocity_x.dart';

import 'package:transactionsapp/Auth__Screens/agent_login.dart';
import 'package:transactionsapp/Auth__Screens/user_login.dart';
import 'package:transactionsapp/utils/theme.dart';
import 'package:transactionsapp/widgets/custombutton.dart';

class AuthHome extends StatelessWidget {
  const AuthHome({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Container(
          height: MediaQuery.of(context).size.height,
          child: Column(
            children: [
              Container(
                height: MediaQuery.of(context).size.height * .30,
                child: Image.asset(
                  'assets/images/applogo.png',
                  height: 200,
                  width: 200,
                ),
              ),
              SizedBox(
                height: 40,
              ),
              Expanded(
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.only(
                      topRight: Radius.circular(40.0),
                      topLeft: Radius.circular(40.0),
                    ),
                    gradient: LinearGradient(
                      begin: Alignment.topRight,
                      end: Alignment.bottomLeft,
                      colors: [
                        AppTheme.profilecardgrad1,
                        AppTheme.profilecardgrad2,
                      ],
                    ),
                  ),
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height * .70,
                  child: Container(
                    child: Column(
                      children: [
                        SizedBox(
                          height: 100,
                        ),
                        CustomBtn(
                            fontw: FontWeight.bold,
                            height: 50,
                            width: MediaQuery.of(context).size.width - 70,
                            radius: 20,
                            btncol: Color(0xff4a4a4a),
                            btntxtcol: AppTheme.btntxt,
                            btntxt: "User Login ",
                            btntextsize: 16,
                            onTap: () {
                              Get.to(() => LoginPage(
                                    userType: 'user',
                                  ));
                            }),
                        CustomBtn(
                          fontw: FontWeight.bold,
                          height: 50,
                          width: MediaQuery.of(context).size.width - 70,
                          radius: 20,
                          btncol: Color(0xff4a4a4a),
                          btntxtcol: AppTheme.btntxt,
                          btntxt: "Agent Login ",
                          btntextsize: 16,
                          onTap: () {
                            Get.to(() => AgentLogin(
                                  userType: 'agent',
                                ));
                          },
                        ).pOnly(top: 30)
                      ],
                    ),
                  ).pOnly(top: 70),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
