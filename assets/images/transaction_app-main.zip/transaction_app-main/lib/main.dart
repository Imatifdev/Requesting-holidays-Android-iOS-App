// ignore_for_file: prefer_const_constructors, depend_on_referenced_packages

import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:get/get.dart';
import 'package:hive_flutter/hive_flutter.dart';

// import 'package:path_provider/path_provider.dart';
import 'package:transactionsapp/Auth__Screens/homeauth.dart';
import 'package:transactionsapp/Auth__Screens/user_login.dart';
import 'package:transactionsapp/screens/agenthome.dart';
import 'package:transactionsapp/screens/banktransfer.dart';
import 'package:transactionsapp/screens/mainbottom.dart';


void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // var directory = await getApplicationDocumentsDirectory();
  //   Hive.init(directory.path);
  await Hive.initFlutter();
  await Hive.openBox('box');

  runApp(TransacApp());
}

class TransacApp extends StatelessWidget {
  const TransacApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      builder: EasyLoading.init(),
      debugShowCheckedModeBanner: false,
      home: Hive.box('box').get('isLogin') == true
          ? Hive.box('box').get('userType') == 'user'
              ? MainScreen()
              : AgentHome()
          : LoginPage(),
    );
  }
}
