
class UserLoginModel {
  bool success;
  Data data;
  String message;
  UserLoginModel({
    required this.success,
    required this.data,
    required this.message,
  });

  factory UserLoginModel.fromMap(Map<String, dynamic> map) {
    return UserLoginModel(
      success: map['success'] ?? false,
      data: Data.fromMap(map['data']),
      message: map['message'] ?? '',
    );
  }
}

class Data {
  String name;
  String email;
  String userType;
  String agentType;
  String priority;
  int balanceAmount;
  int convertedBalanceAmount;
  String token;
  Data({
    required this.name,
    required this.email,
    required this.userType,
    required this.agentType,
    required this.priority,
    required this.balanceAmount,
    required this.convertedBalanceAmount,
    required this.token,
  });

  factory Data.fromMap(Map<String, dynamic> map) {
    return Data(
      name: map['name'] ?? '',
      email: map['email'] ?? '',
      userType: map['user_type'] ?? '',
      agentType: map['agent_type'] ?? '',
      priority: map['priority'] ?? '',
      balanceAmount: map['balanceAmount']?.toInt() ?? 0,
      convertedBalanceAmount: map['convertedBalanceAmount']?.toInt() ?? 0,
      token: map['token'] ?? '',
    );
  }
}
