class MyOrderModel {
  bool? success;
  List<MyOrderList>? data;
  String? message;

  MyOrderModel({this.success, this.data, this.message});

  MyOrderModel.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    if (json['data'] != null) {
      data = <MyOrderList>[];
      json['data'].forEach((v) {
        data!.add(MyOrderList.fromJson(v));
      });
    }
    message = json['message'];
  }

  
}

class MyOrderList {
  String? id;
  String? orderType;
  String? depositerId;
  String? resolveAgentId;
  String? resolveDate;
  String? depositerCurrency;
  String? userRemarks;
  String? agentRemarks;
  String? phoneNumber;
  String? vTransferAccType;
  dynamic bTransferName;
  String? bTransferImg;
  String? bTransferImg2;
  String? bTransferImg3;
  dynamic mTransferNetworkType;
  String? agentCurrency;
  String? amount;
  String? tax;
  String? convertRate;
  String? amountAfterConvert;
  String? orderNature;
  String? bankId;
  String? orderStatus;
  String? agentTransectionId;
  String? agentEvidenceImage;
  String? createdAt;
  String? updatedAt;
  String? bankTitle;
  String? name;
  String? request_for_cancel;
  MyOrderList(
      {this.id,
      this.orderType,
      this.depositerId,
      this.resolveAgentId,
      this.resolveDate,
      this.depositerCurrency,
      this.userRemarks,
      this.agentRemarks,
      this.phoneNumber,
      this.vTransferAccType,
      this.bTransferName,
      this.bTransferImg,
        this.bTransferImg2,
        this.bTransferImg3,

        this.mTransferNetworkType,
      this.agentCurrency,
      this.amount,
      this.tax,
      this.convertRate,
      this.amountAfterConvert,
      this.orderNature,
      this.bankId,
      this.orderStatus,
      this.agentTransectionId,
      this.agentEvidenceImage,
      this.createdAt,
      this.updatedAt,
      this.bankTitle,this.name,
      this.request_for_cancel});

  MyOrderList.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    orderType = json['order_type'];
    depositerId = json['depositer_id'];
    resolveAgentId = json['resolve_agent_id'];
    resolveDate = json['resolve_date'];
    depositerCurrency = json['depositer_currency'];
    userRemarks = json['user_remarks'];
    agentRemarks = json['agent_remarks'];
    phoneNumber = json['phone_number'];
    vTransferAccType = json['v_transfer_acc_type'];
    bTransferName = json['b_transfer_name'];
    bTransferImg = json['b_transfer_img'];
    bTransferImg2 = json['b_transfer_img2'];
    bTransferImg3 = json['b_transfer_img3'];
    mTransferNetworkType = json['m_transfer_network_type'];
    agentCurrency = json['agent_currency'];
    amount = json['amount'];
    tax = json['tax'];
    convertRate = json['convert_rate'];
    amountAfterConvert = json['amount_after_convert'];
    orderNature = json['order_nature'];
    bankId = json['bank_id'];
    orderStatus = json['order_status'];
    agentTransectionId = json['agent_transection_id'];
    agentEvidenceImage = json['agent_evidence_image'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    bankTitle = json['bank_title'];name = json['title'];
    request_for_cancel = json['request_for_cancel'];
  }

  
}
