class AgentLoginModel {
  bool? success;
  Data? data;
  String? message;

  AgentLoginModel({this.success, this.data, this.message});

  AgentLoginModel.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    data = json['data'] != null ? Data.fromJson(json['data']) : null;
    message = json['message'];
  }

  
}

class Data {
  String? name;
  String? email;
  String? userType;
  String? agentType;
  String? priority;
  String? balanceAmount;
  String? convertedBalanceAmount;
  String? token;

  Data(
      {this.name,
      this.email,
      this.userType,
      this.agentType,
      this.priority,
      this.balanceAmount,
      this.convertedBalanceAmount,
      this.token});

  Data.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    email = json['email'];
    userType = json['user_type'];
    agentType = json['agent_type'];
    priority = json['priority'];
    balanceAmount = json['balance_amount'];
    convertedBalanceAmount = json['converted_balance_amount'];
    token = json['token'];
  }
 
}
