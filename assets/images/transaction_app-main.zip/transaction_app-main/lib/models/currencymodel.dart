import 'dart:convert';

class UserModel {
  bool success;
  DataList data;
  String message;
  UserModel({
    required this.success,
    required this.data,
    required this.message,
  });

   

  Map<String, dynamic> toMap() {
    final result = <String, dynamic>{};
  
    result.addAll({'success': success});
    result.addAll({'data': data.toMap()});
    result.addAll({'message': message});
  
    return result;
  }

  factory UserModel.fromMap(Map<String, dynamic> map) {
    return UserModel(
      success: map['success'] ?? false,
      data: DataList.fromMap(map['data']),
      message: map['message'] ?? '',
    );
  }

  String toJson() => json.encode(toMap());

  factory UserModel.fromJson(String source) => UserModel.fromMap(json.decode(source));
}

class DataList {
  int id;
  String name;
  String email;
  dynamic emailVerifiedAt;
  String userType;
  dynamic agentType;
  dynamic priority;
  String createdAt;
  String updatedAt;
  DataList({
    required this.id,
    required this.name,
    required this.email,
    required this.emailVerifiedAt,
    required this.userType,
    required this.agentType,
    required this.priority,
    required this.createdAt,
    required this.updatedAt,
  });

  

  Map<String, dynamic> toMap() {
    final result = <String, dynamic>{};
  
    result.addAll({'id': id});
    result.addAll({'name': name});
    result.addAll({'email': email});
    result.addAll({'emailVerifiedAt': emailVerifiedAt});
    result.addAll({'userType': userType});
    result.addAll({'agentType': agentType});
    result.addAll({'priority': priority});
    result.addAll({'createdAt': createdAt});
    result.addAll({'updatedAt': updatedAt});
  
    return result;
  }

  factory DataList.fromMap(Map<String, dynamic> map) {
    return DataList(
      id: map['id']?.toInt() ?? 0,
      name: map['name'] ?? '',
      email: map['email'] ?? '',
      emailVerifiedAt: map['emailVerifiedAt'],
      userType: map['userType'] ?? '',
      agentType: map['agentType'],
      priority: map['priority'],
      createdAt: map['createdAt'] ?? '',
      updatedAt: map['updatedAt'] ?? '',
    );
  }

  String toJson() => json.encode(toMap());

  factory DataList.fromJson(String source) => DataList.fromMap(json.decode(source));
}
