class HomeModel {
  bool? success;
  Data? data;
  String? message;

  HomeModel({this.success, this.data, this.message});

  HomeModel.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['success'] = this.success;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    data['message'] = this.message;
    return data;
  }
}

class Data {
  Balance? balance;
  UserStatus? userStatus;

  Data({this.balance, this.userStatus});

  Data.fromJson(Map<String, dynamic> json) {
    balance =
    json['balance'] != null ? new Balance.fromJson(json['balance']) : null;
    userStatus = json['user_status'] != null
        ? new UserStatus.fromJson(json['user_status'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.balance != null) {
      data['balance'] = this.balance!.toJson();
    }
    if (this.userStatus != null) {
      data['user_status'] = this.userStatus!.toJson();
    }
    return data;
  }
}

class Balance {
  String? balanceAmount;
  String? convertedBalanceAmount;

  Balance({this.balanceAmount, this.convertedBalanceAmount});

  Balance.fromJson(Map<String, dynamic> json) {
    balanceAmount = json['balance_amount'];
    convertedBalanceAmount = json['converted_balance_amount'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['balance_amount'] = this.balanceAmount;
    data['converted_balance_amount'] = this.convertedBalanceAmount;
    return data;
  }
}

class UserStatus {
  String? status;

  UserStatus({this.status});

  UserStatus.fromJson(Map<String, dynamic> json) {
    status = json['status'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    return data;
  }
}