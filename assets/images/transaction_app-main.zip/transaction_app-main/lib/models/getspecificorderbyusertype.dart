class GetSpecificOrderByUsertype {
  bool? success;
  List<GetSpecificOrderByUsertypeList>? data;
  String? message;

  GetSpecificOrderByUsertype({this.success, this.data, this.message});

  GetSpecificOrderByUsertype.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    if (json['data'] != null) {
      data = <GetSpecificOrderByUsertypeList>[];
      json['data'].forEach((v) {
        data!.add(GetSpecificOrderByUsertypeList.fromJson(v));
      });
    }
    message = json['message'];
  }
}

class GetSpecificOrderByUsertypeList {
  String? id;
  String? orderType;
  String? depositerId;
  String? resolveAgentId;
  String? resolveDate;
  String? depositerCurrency;
  String? userRemarks;
  String? phoneNumber;
  dynamic vTransferAccType;
  String? bTransferName;
  String? bTransferImg;
  String? bTransferImg2;
  String? bTransferImg3;
  dynamic mTransferNetworkType;
  String? agentCurrency;
  String? amount;
  String? tax;
  String? convertRate;
  String? amountAfterConvert;
  String? orderNature;
  String? bankId;
  String? orderStatus;
  String? agentTransectionId;
  String? agentEvidenceImage;
  String? createdAt;
  String? updatedAt;
  String? depositorName;
  String? banktitle;
  String? name;
  String? ispartial;
  String?request_for_cancel;
  String?agent_remarks;
  GetSpecificOrderByUsertypeList(
      {this.id,
        this.bTransferImg2,
        this.bTransferImg3,
      this.orderType,
      this.depositerId,
      this.resolveAgentId,
      this.resolveDate,
      this.depositerCurrency,
      this.userRemarks,
      this.phoneNumber,
      this.vTransferAccType,
      this.bTransferName,
      this.bTransferImg,
      this.mTransferNetworkType,
      this.agentCurrency,
      this.amount,
      this.tax,
      this.convertRate,
      this.amountAfterConvert,
      this.orderNature,
      this.bankId,
      this.orderStatus,
      this.agentTransectionId,
      this.agentEvidenceImage,
      this.createdAt,
      this.updatedAt,
      this.depositorName,
      this.banktitle,
      this.name,
      this.ispartial,
      this.request_for_cancel,
      this.agent_remarks});

  GetSpecificOrderByUsertypeList.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    orderType = json['order_type'];
    depositerId = json['depositer_id'];
    resolveAgentId = json['resolve_agent_id'];
    resolveDate = json['resolve_date'];
    depositerCurrency = json['depositer_currency'];
    userRemarks = json['user_remarks'];
    phoneNumber = json['phone_number'];
    vTransferAccType = json['v_transfer_acc_type'];
    bTransferName = json['b_transfer_name'];
    bTransferImg = json['b_transfer_img'];
    bTransferImg2 = json['b_transfer_img2'];
    bTransferImg3 = json['b_transfer_img3'];
    mTransferNetworkType = json['m_transfer_network_type'];
    agentCurrency = json['agent_currency'];
    amount = json['amount'];
    tax = json['tax'];
    convertRate = json['convert_rate'];
    amountAfterConvert = json['amount_after_convert'];
    orderNature = json['order_nature'];
    bankId = json['bank_id'];
    orderStatus = json['order_status'];
    agentTransectionId = json['agent_transection_id'];
    agentEvidenceImage = json['agent_evidence_image'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    depositorName = json['depositor_name'];
    banktitle = json['bank_title'];
    name = json['title'];
    request_for_cancel = json['request_for_cancel'];
    agent_remarks = json['agent_remarks'];
    ispartial = json['is_partial'];
  }
}
