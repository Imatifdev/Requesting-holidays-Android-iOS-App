class AllBankList {
  bool? success;
  List<Data>? data;
  String? message;

  AllBankList({this.success, this.data, this.message});

  AllBankList.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    if (json['data'] != null) {
      data = <Data>[];
      json['data'].forEach((v) {
        data!.add(Data.fromJson(v));
      });
    }
    message = json['message'];
  }

  
}

class Data {
  String? id;
  String? bankTitle;

  Data({this.id, this.bankTitle});

  Data.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    bankTitle = json['bank_title'];
  }

  
}
