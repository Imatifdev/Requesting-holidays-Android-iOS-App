class CurrentBalance {
  bool? success;
  Data? data;
  String? message;

  CurrentBalance({this.success, this.data, this.message});

  CurrentBalance.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    data = json['data'] != null ? Data.fromJson(json['data']) : null;
    message = json['message'];
  }
}

class Data {
  String? balanceAmount;
  String? convertedBalanceAmount;

  Data({this.balanceAmount, this.convertedBalanceAmount});

  Data.fromJson(Map<String, dynamic> json) {
    balanceAmount = json['balance_amount'] ?? '';
    convertedBalanceAmount = json['converted_balance_amount'] ?? '';
  }
}
