import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:open_file/open_file.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart';
import 'package:transactionsapp/models/myorder_model.dart';
import 'package:transactionsapp/utils/pdf_openfile.dart';

import '../models/getspecificorderbyusertype.dart';

class PdfInvoice {
  static String name = '';
  static Future<File?> generateFile({
    required double totalAmount,
    required double totalInSAR,
    required bool istypeAgent,
    GetSpecificOrderByUsertype? getSpecificOrderByUsertype,
    MyOrderModel? orderModel,
  }) async {
    name = Hive.box('box').get('name');
    final pdf = Document();
    pdf.addPage(MultiPage(build: (Context context) {
      return [
        buildHeader(),
        SizedBox(height: 0.4 * PdfPageFormat.inch),
        Divider(),
        ResuableRow(
            Balance: 'Balance',
            resolvedate: 'Date',
            orderType: 'OrderType',
            Tax: 'Tax',
            id: 'OrderId',
            istypeAgent: istypeAgent,
            Amount: 'Amount',
            AgentRemarks: 'AgentRemarks'),
        Divider(),
        builTitle(
            istypeAgent: istypeAgent,
            totalAmount: totalAmount,
            getSpecificOrderByUsertype: getSpecificOrderByUsertype,
            myOrderModel: orderModel),
        Divider(),
        buildFooter(totalAmount.toString(), istypeAgent, totalInSAR.toString())
      ];
    }));

    final file = await PdfApi.saveDocument(
      name: 'my_invoice.pdf',
      pdfDocument: pdf,
    );

    await OpenFile.open(file.path);
  }

  static Widget builTitle({
    required double totalAmount,
    MyOrderModel? myOrderModel,
    required bool istypeAgent,
    GetSpecificOrderByUsertype? getSpecificOrderByUsertype,
  }) {
    List<MyOrderList> completedList = [];
    List<GetSpecificOrderByUsertypeList> completedList2 = [];
    if (istypeAgent) {
      completedList2 = getSpecificOrderByUsertype!.data!
          .where((element) => element.orderStatus == 'Completed')
          .toList();
      totalAmount = completedList2
          .map((order) => double.parse(order.amount ?? '0'))
          .reduce((value, element) => value + element);
    } else {
      completedList = myOrderModel!.data!
          .where((element) => element.orderStatus == 'Completed')
          .toList();
      totalAmount = completedList
          .map((order) => double.parse(order.amount ?? '0'))
          .reduce((value, element) => value + element);
    }

    return istypeAgent == false
        ? ListView.separated(
      separatorBuilder: (context, index) {
        return SizedBox(height: 6);
      },
      direction: Axis.vertical,
      itemBuilder: (context, index) {
        MyOrderList myOrderList = completedList[index];
        DateTime resolvedDateTime =
        DateTime.parse(myOrderList.updatedAt ?? '');
        String formattedDate =
            '${resolvedDateTime.day}/${resolvedDateTime.month}/${resolvedDateTime.year}';
        String formattedTime =
            '${resolvedDateTime.hour}:${resolvedDateTime.minute}:${resolvedDateTime.second}';
        return Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,

          children: [
            Column(
              children:[
                Text(
                 formattedDate,
                  style:
                  TextStyle(fontSize: 16, fontWeight: FontWeight.normal),
                ), Text(
                 formattedTime,
                  style:
                  TextStyle(fontSize: 16, fontWeight: FontWeight.normal),
                ),
              ]
            ),
            Text(
              myOrderList.id!,
              style:
              TextStyle(fontSize: 16, fontWeight: FontWeight.normal),
            ),
            Text(
              myOrderList.orderType == "Created By Admin"
                  ? myOrderList.userRemarks ?? ''
                  : myOrderList.orderType ?? '',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.normal),
            ),
            Text(
              myOrderList.orderType == "Created By Admin"
                  ? "SAR:${myOrderList.amountAfterConvert}" ?? ''
                  : myOrderList.amount ?? '',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.normal),
            ),
            Text(
              myOrderList.tax!,
              style:
              TextStyle(fontSize: 16, fontWeight: FontWeight.normal),
            ),
            Text(
              myOrderList.amountAfterConvert!,
              style:
              TextStyle(fontSize: 16, fontWeight: FontWeight.normal),
            ),
          ],
        );
      },
      itemCount: completedList.length,
    )
    //Agent data list start here......
        : ListView.separated(
      separatorBuilder: (context, index) {
        return SizedBox(height: 6);
      },
      direction: Axis.vertical,
      itemBuilder: (context, index) {
        GetSpecificOrderByUsertypeList myOrderList =
        completedList2[index];
        DateTime resolvedDateTime =
        DateTime.parse(myOrderList.updatedAt ?? '');
        String formattedDate =
            '${resolvedDateTime.day}/${resolvedDateTime.month}/${resolvedDateTime.year}';
        String formattedTime =
            '${resolvedDateTime.hour}:${resolvedDateTime.minute}:${resolvedDateTime.second}';
        return Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              children: [
                Text(
                  formattedDate,
                  style:
                  TextStyle(fontSize: 16, fontWeight: FontWeight.normal),
                ),
                Text(
                  formattedTime,
                  style:
                  TextStyle(fontSize: 16, fontWeight: FontWeight.normal),
                ),
              ]
            ),
            Text(
              myOrderList.id!,
              style:
              TextStyle(fontSize: 16, fontWeight: FontWeight.normal),
            ),
            Text(
              myOrderList.orderType == "Created By Admin"
                  ? myOrderList.userRemarks ?? ''
                  : myOrderList.orderType ?? '',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.normal),
            ),
            Text(
              myOrderList.agent_remarks.toString(),
              style:
              TextStyle(fontSize: 16, fontWeight: FontWeight.normal),
            ),
            Text(
              myOrderList.amount!,
              style:
              TextStyle(fontSize: 16, fontWeight: FontWeight.normal),
            ),
          ],
        );
      },
      itemCount: completedList2.length,
    );
  }

  static Widget buildHeader() => Center(
      child: Text(
        "$name Statement",
        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
      ));
  static Widget buildFooter(
      String totalAmount, bool isAgent, String totalInSAR) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        // Text(totalAmount),
        buildSimpleText(
          value: isAgent == false ? 'SAR: $totalInSAR' : 'PKR:$totalAmount',
          isAgent: isAgent,
        ),
      ],
    );
  }

  static buildSimpleText({required String value, required bool isAgent}) {
    return Padding(
        padding: EdgeInsets.only(right: isAgent == false ? 48 : 40),
        child: Text(
          value.toString(),
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ));
  }

  static ResuableRow({
    required String Balance,
    String? Tax,
    required bool istypeAgent,
    required String resolvedate,
    required String orderType,
    required String AgentRemarks,
    required String id,
    required String Amount,
  }) {
    return istypeAgent == false
        ? Padding(
      padding: const EdgeInsets.all(3),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            resolvedate,
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
          Text(
            id,
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
          Text(
            orderType,
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
          Text(
            Amount,
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
          Text(
            Tax!,
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
          Text(
            Balance,
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
        ],
      ),
    )
    //Agent menu list.........
        : Padding(
      padding: const EdgeInsets.all(3),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            resolvedate,
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
          Padding(
              padding: EdgeInsets.only(left: 8),
              child: Text(
                id,
                style:
                TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              )),
          Text(
            orderType,
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
          Text(
            AgentRemarks,
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
          Text(
            Balance,
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }
}