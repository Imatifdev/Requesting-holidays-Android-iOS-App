// // ignore_for_file: avoid_print


// import 'package:shared_preferences/shared_preferences.dart';

// class DatabaseHandler {
//   Future<bool> isExists(String inputString) async {
//     SharedPreferences prefs = await SharedPreferences.getInstance();
//     var check = prefs.getString(inputString);
//     return check == null ? false : true;
//   }
// //? < = = = = = = = = = = = User Access Token = = = = = = = = = = = = = = = >
//   setToken(String token) async {
//     SharedPreferences prefs = await SharedPreferences.getInstance();
//     final result = await prefs.setString('token', token);
//     print("token saved $result");
//   }

//   getToken() async {
//     SharedPreferences prefs = await SharedPreferences.getInstance();
//     final response = prefs.getString('token') ?? "";
//     return response;
//   }

//   removeToken() async {
//     SharedPreferences prefs = await SharedPreferences.getInstance();
//     await prefs.remove('token');
//   }

// //? < = = = = = = = = = = = Logout = = = = = = = = = = = = =>
//   logOut() async {
//     SharedPreferences prefs = await SharedPreferences.getInstance();
//     await prefs.remove('token');
//     print("LogOut Successfull");
//   }
// }
