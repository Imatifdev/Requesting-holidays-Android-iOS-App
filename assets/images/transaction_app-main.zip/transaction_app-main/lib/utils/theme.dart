// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';

class AppTheme {
  static Color darkbg = Color(0xff3300CC);
  static Color lightbg = Color(0xff00CCFF);
  static Color greebg = Color(0xff6C9F00);
  static Color rkedColor = Colors.red;
  static Color kGreen = Colors.green;
  static Color kBlack = Colors.black;
  static Color dropdowncolo = Color(0xffF7E9FF);
  //new theme file
  static Color secbackground = Color(0xff4a4a4a);
  static Color newiconcolor = Color(0xff0877b3);
  static Color buttonbackground = Color.fromARGB(154, 247, 241, 241);
  static Color mainbackground = Colors.white;
  static Color btntxt = Colors.white;
  static Color profilecardgrad1 = Color(0xffdb75c1);
  static Color profilecardgrad2 = Color(0xfff5b15f);
  static Color profilecardgradtile = Color(0xffe6e7e9);
  static Color greytxt = Colors.grey;
}
