// ignore_for_file: prefer_const_constructors

import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import 'package:transactionsapp/Auth__Screens/forgotpass.dart';
import 'package:transactionsapp/Auth__Screens/homeauth.dart';
import 'package:transactionsapp/Auth__Screens/user_login.dart';
import 'package:transactionsapp/Auth__Screens/agent_login.dart';
import 'package:transactionsapp/screens/Banktransferconfirm.dart';
import 'package:transactionsapp/screens/Home.dart';
import 'package:transactionsapp/screens/PrivacyPolicy.dart';
import 'package:transactionsapp/screens/agentbankorder.dart';
import 'package:transactionsapp/screens/agenthome.dart';
import 'package:transactionsapp/screens/agentloadorder.dart';
import 'package:transactionsapp/screens/banktransfer.dart';
import 'package:transactionsapp/screens/loadconfirmation.dart';
import 'package:transactionsapp/screens/loadtransfer.dart';
import 'package:transactionsapp/screens/profile.dart';
import 'package:transactionsapp/screens/mainbottom.dart';
import 'package:transactionsapp/screens/userorder.dart';
import 'package:transactionsapp/screens/wallettransfer.dart';
import 'package:transactionsapp/screens/wallettransferconf.dart';

appRoutes() => [
      GetPage(
        name: '/Authhome',
        page: () => AuthHome(),
        transition: Transition.leftToRightWithFade,
        transitionDuration: Duration(milliseconds: 500),
      ),
      GetPage(
        name: '/HomePage',
        page: () => HomePage(),
        transition: Transition.leftToRightWithFade,
        transitionDuration: Duration(milliseconds: 500),
      ),
      GetPage(
        name: '/login',
        page: () => LoginPage(),
        middlewares: [MyMiddelware()],
        transition: Transition.leftToRightWithFade,
        transitionDuration: Duration(milliseconds: 500),
      ),
      GetPage(
        name: '/wallet confirm',
        page: () => WalletConfirmation(),
        middlewares: [MyMiddelware()],
        transition: Transition.leftToRightWithFade,
        transitionDuration: Duration(milliseconds: 500),
      ),
      GetPage(
        name: '/bank confirm',
        page: () => BankConfirmation(),
        middlewares: [MyMiddelware()],
        transition: Transition.leftToRightWithFade,
        transitionDuration: Duration(milliseconds: 500),
      ),
      GetPage(
        name: '/loadconfirm',
        page: () => LoadConfirmation(),
        middlewares: [MyMiddelware()],
        transition: Transition.leftToRightWithFade,
        transitionDuration: Duration(milliseconds: 500),
      ),
      GetPage(
        name: '/AgentLogin',
        page: () => AgentLogin(),
        middlewares: [MyMiddelware()],
        transition: Transition.leftToRightWithFade,
        transitionDuration: Duration(milliseconds: 500),
      ),
      GetPage(
        name: '/Agenthome',
        page: () => AgentHome(),
        middlewares: [MyMiddelware()],
        transition: Transition.leftToRightWithFade,
        transitionDuration: Duration(milliseconds: 500),
      ),
      GetPage(
        name: '/userorder',
        page: () => UserOrder(),
        middlewares: [MyMiddelware()],
        transition: Transition.leftToRightWithFade,
        transitionDuration: Duration(milliseconds: 500),
      ),
      GetPage(
        name: '/privacy',
        page: () => Privacy(),
        middlewares: [MyMiddelware()],
        transition: Transition.leftToRightWithFade,
        transitionDuration: Duration(milliseconds: 500),
      ),
      GetPage(
        name: '/Profile',
        page: () => Profile(),
        middlewares: [MyMiddelware()],
        transition: Transition.leftToRightWithFade,
        transitionDuration: Duration(milliseconds: 500),
      ),
      GetPage(
        name: '/Main',
        page: () => MainScreen(),
        middlewares: [MyMiddelware()],
        transition: Transition.leftToRightWithFade,
        transitionDuration: Duration(milliseconds: 500),
      ),
      GetPage(
        name: '/forgotpass',
        page: () => ForGotPass(),
        middlewares: [MyMiddelware()],
        transition: Transition.zoom,
        transitionDuration: Duration(milliseconds: 7000),
      ),
      // GetPage(
      //   name: '/loadtransfer',
      //   page: () => LoadTransfer(),
      //   middlewares: [MyMiddelware()],
      //   transition: Transition.zoom,
      //   transitionDuration: Duration(milliseconds: 7000),
      // ),
      // GetPage(
      //   name: '/banktransfer',
      //   page: () => BankTransfer(),
      //   middlewares: [MyMiddelware()],
      //   transition: Transition.zoom,
      //   transitionDuration: Duration(milliseconds: 7000),
      // ),
      // GetPage(
      //   name: '/wallettransfer',
      //   page: () => WalletTransfer(),
      //   middlewares: [MyMiddelware()],
      //   transition: Transition.zoom,
      //   transitionDuration: Duration(milliseconds: 7000),
      // ),
      GetPage(
        name: '/agentwaletorder',
        page: () => BankOrder(),
        middlewares: [MyMiddelware()],
        transition: Transition.zoom,
        transitionDuration: Duration(milliseconds: 7000),
      ),
      GetPage(
        name: '/agentloadorder',
        page: () => LoadOrder(),
        middlewares: [MyMiddelware()],
        transition: Transition.zoom,
        transitionDuration: Duration(milliseconds: 7000),
      ),
      GetPage(
        name: '/agentbankorder',
        page: () => BankOrder(),
        middlewares: [MyMiddelware()],
        transition: Transition.zoom,
        transitionDuration: Duration(milliseconds: 7000),
      ),
    ];

class MyMiddelware extends GetMiddleware {
  @override
  GetPage? onPageCalled(GetPage? page) {
    if (kDebugMode) {
      print(page?.name);
    }
    return super.onPageCalled(page);
  }
}
