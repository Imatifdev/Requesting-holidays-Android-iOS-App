// import 'package:http/http.dart' as http;

// import '../models/currencymodel.dart';

// class CurrencyAPIHelper {
//   CurrencyAPIHelper._();

//   static final CurrencyAPIHelper apiHelper = CurrencyAPIHelper._();

//   Future<Currency?> fetchCurrencyData() async {
//     var response = await http.get(
//       Uri.parse(
//           "https://openexchangerates.org/api/latest.json?base=USD&app_id=8494337db9d84b398dafc459d53103c7"),
//     );
//     final result = ratesModelFromJson(response.body);
//     return result;
//   }
// }

// String convertansy(Map exchangeRates, String amount, String currencybase,
//     String currencyfinal) {
//   String output = (double.parse(amount) /
//           exchangeRates[currencybase] *
//           exchangeRates[currencyfinal])
//       .toStringAsFixed(2)
//       .toString();

//   return output;
// }

txtMethod(double value) {
  if (value == 0 || value >=0) {
    return 0;
  }
  // if (value <= 0 && value ==0) {
  //   return 0;
  // }
  // else if (value >= 1 && value <= 25000) {
  //   return 200;
  // } else if (value >= 25001 && value <= 50000) {
  //   return 350;
  // } else if (value >= 50001 && value <= 100000) {
  //   return 500;
  // } else if (value >= 100001 && value <= 150000) {
  //   return 750;
  // } else if (value >= 150001 && value <= 200000) {
  //   return 1000;
  // } else if (value >= 200001 && value <= 250000) {
  //   return 1250;
  // } else if (value >= 250001 && value <= 300000) {
  //   return 1500;
  // } else if (value >= 300001 && value <= 350000) {
  //   return 1750;
  // } else if (value >= 350001 && value <= 400000) {
  //   return 2000;
  // } else if (value >= 400001 && value <= 450000) {
  //   return 2250;
  // } else if (value >= 450001 && value <= 500000) {
  //   return 2500;
  // } else {
    return 0.0;
  }




