// ignore_for_file: prefer_const_literals_to_create_immutables, prefer_const_constructors, file_names

import 'package:flutter/material.dart';
import 'package:transactionsapp/widgets/customtext.dart';

import '../utils/theme.dart';

class Privacy extends StatelessWidget {
  const Privacy({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          flexibleSpace: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    AppTheme.profilecardgrad1,
                    AppTheme.profilecardgrad2
                  ]),
            ),
          ),
          title: Text("Privacy Policy of Tranzac")),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CustomText(
                  TextValue: "Service Providers",
                  fontweight: FontWeight.bold,
                  TextColor: Colors.black,
                  fontsize: 23),
              Divider(
                thickness: 2,
              ),
              CustomText(
                  TextValue:
                      "We may employ third-party companies and individuals due to the following reasons:",
                  fontweight: FontWeight.normal,
                  TextColor: Colors.black,
                  fontsize: 18),
              CustomText(
                  TextValue:
                      "To facilitate our Service;\nTo provide the Service on our behalf;\nTo perform Service-related services;\n or To assist us in analyzing how our Service is used. We want to inform users of this Service that these third parties have access to their Personal Information. The reason is to perform the tasks assigned to them on our behalf. However, they are obligated not to disclose or use the information for any other purpose.",
                  fontweight: FontWeight.normal,
                  TextColor: Colors.black,
                  fontsize: 18),
              SizedBox(
                height: 10,
              ),
              CustomText(
                  TextValue: "Security",
                  fontweight: FontWeight.bold,
                  TextColor: Colors.black,
                  fontsize: 23),
              Divider(
                thickness: 2,
              ),
              CustomText(
                  TextValue:
                      "We value your trust in providing us your Personal Information, thus we are striving to use commercially acceptable means of protecting it. But remember that no method of transmission over the internet, or method of electronic storage is 100% secure and reliable, and we cannot guarantee its absolute security. Links to Other Sites This Service may contain links to other sites. If you click on a third-party link, you will be directed to that site. Note that these external sites are not operated by us. Therefore, we strongly advise you to review the Privacy Policy of these websites. We have no control over and assume no responsibility for the content, privacy policies, or practices of any third-party sites or services. Children’s Privacy These Services do not address anyone under the age of 13. We do not knowingly collect personally identifiable information from children under 13 years of age. In the case we discover that a child under 13 has provided us with personal information, we immediately delete this from our servers. If you are a parent or guardian and you are aware that your child has provided us with personal information, please contact us so that we will be able to do the necessary actions. Changes to This Privacy Policy We may update our Privacy Policy from time to time. Thus, you are advised to review this page periodically for any changes. We will notify you of any changes by posting the new Privacy Policy on this page.This policy is effective as of 2023-02-09.Contact Us If you have any questions or suggestions about our Privacy Policy, do not hesitate to contact us at ",
                  fontweight: FontWeight.normal,
                  TextColor: Colors.black,
                  fontsize: 18),
              CustomText(
                  TextValue: "Infor@Tranzac.com",
                  fontweight: FontWeight.bold,
                  TextColor: Colors.black,
                  fontsize: 23),
              Divider(
                thickness: 2,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
