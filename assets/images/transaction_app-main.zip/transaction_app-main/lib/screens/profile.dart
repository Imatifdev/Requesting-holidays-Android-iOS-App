// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables, depend_on_referenced_packages

import 'package:accordion/accordion.dart';
import 'package:accordion/accordion_section.dart';
import 'package:accordion/controllers.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:hive_flutter/adapters.dart';
import 'package:transactionsapp/Auth__Screens/user_login.dart';
import 'package:velocity_x/velocity_x.dart';

import 'package:transactionsapp/Auth__Screens/homeauth.dart';
import 'package:transactionsapp/screens/PrivacyPolicy.dart';
import 'package:transactionsapp/screens/mainbottom.dart';
import 'package:transactionsapp/utils/theme.dart';

class Profile extends StatefulWidget {
  const Profile({super.key});

  @override
  State<Profile> createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  String? name, email, userType;
  @override
  void initState() {
    super.initState();
    name = Hive.box('box').get('name');
    email = Hive.box('box').get('email');
    userType = Hive.box('box').get('userType');
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Color(0xffe6e7e9),
        body: Center(
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.center, children: [
            SizedBox(
              height: 50,
            ),
            Container(
                height: MediaQuery.of(context).size.height * .33,
                width: MediaQuery.of(context).size.width * .90,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  gradient: LinearGradient(
                    begin: Alignment.topRight,
                    end: Alignment.bottomLeft,
                    colors: [
                      AppTheme.profilecardgrad1,
                      AppTheme.profilecardgrad2,
                    ],
                  ),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CircleAvatar(
                      backgroundColor: Color.fromARGB(35, 0, 0, 0),
                      radius: 40,
                      child: Icon(Icons.person, size: 30),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          "Customer id:",
                          style:
                              TextStyle(fontSize: 20, color: AppTheme.btntxt),
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Text(
                          name!,
                          style: TextStyle(
                            color: AppTheme.btntxt,
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Text(
                      email!,
                      style: TextStyle(fontSize: 14, color: AppTheme.btntxt),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    InkWell(
                      onTap: () {},
                      child: Container(
                        height: 30,
                        width: MediaQuery.of(context).size.height * .10,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: Colors.white),
                        child: Row(
                          children: [
                            Text(
                              "  Profile",
                              style: TextStyle(color: Colors.black),
                            ),
                            Icon(
                              Icons.person,
                              color: AppTheme.newiconcolor,
                            ),
                          ],
                        ).centered(),
                      ),
                    )
                  ],
                )),
            Container(
              decoration: BoxDecoration(
                  color: Colors.white, borderRadius: BorderRadius.circular(20)),
              width: MediaQuery.of(context).size.width * .80,
              child: Column(
                children: [
                  InkWell(
                    onTap: () => Get.to(() => MainScreen()),
                    child: Container(
                      width: MediaQuery.of(context).size.width * .70,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: Color(0xffe6e7e9)),
                      child: Row(
                        children: [
                          Icon(
                            Icons.dashboard,
                            size: 30,
                          ),
                          SizedBox(
                            width: 10,
                          ),
                          Text("DashBoard")
                        ],
                      ).p(5),
                    ),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  InkWell(
                    onTap: () => Get.to(() => Privacy()),
                    child: Container(
                      width: MediaQuery.of(context).size.width * .70,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: Color(0xffe6e7e9)),
                      child: Row(
                        children: [
                          Icon(
                            Icons.policy,
                            size: 30,
                          ),
                          SizedBox(
                            width: 10,
                          ),
                          Text("Privacy Policy")
                        ],
                      ).p(5),
                    ),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  InkWell(
                    onTap: () {
                      Hive.box('box').clear();
                      Fluttertoast.showToast(
                          msg: "User LogOut",
                          toastLength: Toast.LENGTH_SHORT,
                          gravity: ToastGravity.BOTTOM,
                          timeInSecForIosWeb: 1,
                          backgroundColor: Colors.green,
                          textColor: Colors.white,
                          fontSize: 16.0);
                      Get.offAll(() => LoginPage());
                    },
                    child: Container(
                      width: MediaQuery.of(context).size.width * .70,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: Color(0xffe6e7e9)),
                      child: Row(
                        children: [
                          Icon(
                            Icons.logout_outlined,
                            size: 30,
                          ),
                          SizedBox(
                            width: 10,
                          ),
                          Text("Sign Out")
                        ],
                      ).p(5),
                    ),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  InkWell(
                    onTap: () {},
                    child: Container(
                      width: MediaQuery.of(context).size.width * .70,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: Color(0xffe6e7e9)),
                      child: Row(
                        children: [
                          Icon(
                            Icons.translate,
                            size: 30,
                          ),
                          SizedBox(
                            width: 10,
                          ),
                          Text("Urdu")
                        ],
                      ).p(5),
                    ),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  InkWell(
                    onTap: () {
                      showModalBottomSheet<void>(
                          // context and builder are
                          // required properties in this widget
                          context: context,
                          builder: (BuildContext context) {
                            // we set up a container inside which
                            // we create center column and display text

                            // Returning SizedBox instead of a Container
                            return Container(
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(20)),
                              height: 300,
                              child: Center(
                                child: Padding(
                                  padding:
                                      const EdgeInsets.only(top: 10, left: 20),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: const <Widget>[
                                      Text(
                                        'Slab Rate',
                                        style: TextStyle(
                                            fontSize: 20,
                                            fontWeight: FontWeight.bold),
                                      ),
                                      Divider(
                                        thickness: 2,
                                        height: 10,
                                      ),
                                      Text(
                                        '6 riyal to 350 Royal tax 3.5 Riyal.',
                                        style: TextStyle(fontSize: 14),
                                      ),
                                      Text(
                                        '351 Riyal to 700 riyal tax 5 riyal',
                                        style: TextStyle(fontSize: 14),
                                      ),
                                      Text(
                                        '701 riyal to 1426 riyal tax 7 riyal.',
                                        style: TextStyle(fontSize: 14),
                                      ),
                                      Text(
                                        '1427 to 2150 riyal tax 11 riyal',
                                        style: TextStyle(fontSize: 14),
                                      ),
                                      Text(
                                        '2151 to 2853 riyal tax 15 riyal',
                                        style: TextStyle(fontSize: 14),
                                      ),
                                      Text(
                                        '2854 to 3566 riyal tax 18 riyal ',
                                        style: TextStyle(fontSize: 14),
                                      ),
                                      Text(
                                        '3567 to 4279 riyal tax 21 riyal ',
                                        style: TextStyle(fontSize: 14),
                                      ),
                                      Text(
                                        '4280 to 4990 riyal tax 24 riyal ',
                                        style: TextStyle(fontSize: 14),
                                      ),
                                      Text(
                                        '4991 to 5700 riyal tax 28 riyal',
                                        style: TextStyle(fontSize: 14),
                                      ),
                                      Text(
                                        '5701 to 6420 Riyal tax 32 riyal',
                                        style: TextStyle(fontSize: 14),
                                      ),
                                      Text(
                                        '6421 to 7500 riyal tax 36 riyal',
                                        style: TextStyle(fontSize: 14),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            );
                          });
                    },
                    child: Container(
                      width: MediaQuery.of(context).size.width * .70,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: Color(0xffe6e7e9)),
                      child: Row(
                        children: [
                          Icon(
                            Icons.rate_review_sharp,
                            size: 30,
                          ),
                          SizedBox(
                            width: 10,
                          ),
                          Text("Check Slab Rate")
                        ],
                      ).p(5),
                    ),
                  ),
                ],
              ).p(20),
            ).p(20),
          ]),
        ));
  }
}
