// ignore_for_file: prefer_const_constructors, avoid_unnecessary_containers, depend_on_referenced_packages, prefer_const_literals_to_create_immutables

import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

import 'package:get/get.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:transactionsapp/models/all_bank_list.dart';
import 'package:transactionsapp/screens/mainbottom.dart';
import 'package:transactionsapp/utils/constants.dart';
import 'package:velocity_x/velocity_x.dart';

import 'package:transactionsapp/networks/apicall.dart';
import 'package:transactionsapp/utils/loader.dart';
import 'package:transactionsapp/utils/theme.dart';
import 'package:transactionsapp/widgets/custombutton.dart';

import '../widgets/customtext.dart';
import 'Home.dart';

class BankTransfer extends StatefulWidget {
  String? bankRate, imediateRate;

  BankTransfer(this.bankRate, this.imediateRate);

  @override
  State<BankTransfer> createState() => _BankTransferState();
}

class _BankTransferState extends State<BankTransfer> {
  final _formKey = GlobalKey<FormState>();
  TextEditingController phonenumberController = TextEditingController();
  TextEditingController ammountcontroller = TextEditingController();
  TextEditingController namecontroller = TextEditingController();
  TextEditingController vouchercontroller = TextEditingController();
  TextEditingController remarkController = TextEditingController();
  double multiplier = 0.0;
  double? num1;
  double? num2;
  int val = 0;
  File? _image;
  String taxType = '0.0';
  double totalAmount = 0.0;
  double pkr = 0.0;
  final _picker = ImagePicker();

  double? voucherNum = 0;
  int valueMultiply = 1;
  int voucherValue = 0;
  bool voucherbool = false;
  String voucher_id = 'none';

  AllBankList? bankList;
  final List<String> bankitems = [
    'Advans Microfinance Bank',
    'Al Baraka Islamic Limited',
    'Alfa Pay',
    'Allied Bank Limited',
    'Apna Microfinance Bank',
    'Askari Commercial Bank Limited',
    'Bank Al Habib Limited',
    'Bank Alflah Limited',
    'Bank Islamic Pakistan Limited',
    'Bank of Punjab',
    'Bank of Khyber',
    'Burj Bank Limited',
    'Citi Bank',
    'Digtt',
    'Dubai Islamic Bank',
    'Fina',
    'First Women Bank',
    ' HBL Konnect',
    'HBL MFB',
    'Habib Bank Limited',
    'Habib Metropolitian Bank',
    'ICBC',
    'Js Bank',
    'KASB Bank',
    'MCB Islamic Bank',
    'Meezan Bank',
    'Mobilink MicroFinance Bank',
    ' NIB Bank',
    'NRSP Bank Fori Cash',
    'NBP',
    'Paymax',
    'NayaPay',
    'SadaPay',
    'Samba Bank',
    'Silk Bank',
    'SimSim',
    'Sindh Bank',
    'Soneri Bank Ltd',
    'Standard Chartered Bank',
    'Summit Bank',
    'Telenor Microfinance Bank',
    'U Microfinance Bank',
    'ZTBL',
    'UBL'
  ];
  bool isOpen = false;
  String? selectedValue;
  String selectBank = 'Select Bank';
  String? transfertype = "Next Day";
  List<String> totalsplit = [];
  List<String> taxSplit = [];
  @override
  void initState() {
    super.initState();
    getAllList();
  }

  void _handleRadioValueChange(String? value) {
    setState(() {
      transfertype = value;
    });
  }

  List<File> _imageList = [];

  Future<void> _getImage(ImageSource source) async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: source);
    if (pickedFile != null) {
      setState(() {
        _imageList = List.from(_imageList)..add(File(pickedFile.path));
        print("Number of images in _imageList: ${_imageList.length}");
      });
    }
  }
  Future<void> _showImagePickerDialog() async {
    if (_imageList.length >= 3) {
      return;
    }

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Select Image'),
          content: SingleChildScrollView(
            child: ListBody(
              children: [
                GestureDetector(
                  child: Text(
                    'From Camera',
                    style: TextStyle(
                      color: Colors.orangeAccent,
                      fontWeight: FontWeight.w600,
                      fontSize: 18,
                    ),
                  ),
                  onTap: () {
                    _getImage(ImageSource.camera);
                    Navigator.of(context).pop();
                  },
                ),
                SizedBox(height: 25),
                GestureDetector(
                  child: Text(
                    'From Gallery',
                    style: TextStyle(
                      color: Colors.orangeAccent,
                      fontWeight: FontWeight.w600,
                      fontSize: 18,
                    ),
                  ),
                  onTap: () {
                    _getImage(ImageSource.gallery);
                    Navigator.of(context).pop();
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    num1 = double.parse(widget.bankRate.toString());
    num2 = double.parse(widget.imediateRate.toString());

    final limitedImageList = _imageList.take(3).toList();
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topRight,
                    end: Alignment.bottomLeft,
                    colors: [
                      AppTheme.profilecardgrad1,
                      AppTheme.profilecardgrad2,
                    ],
                  ),
                  borderRadius: BorderRadius.only(
                    bottomRight: Radius.circular(30.0),
                    bottomLeft: Radius.circular(30.0),
                  ),
                ),
                width: double.infinity,
                height: MediaQuery.of(context).size.height * .30,
                child: Column(
                  children: [
                    SizedBox(
                      height: 20,
                    ),
                    Image(
                      height: 100,
                      width: 130,
                      image: AssetImage("assets/images/apptit.png"),
                    ),
                    SizedBox(
                      height: 30,
                    ),
                    CustomText(
                        TextValue: "Bank Transfer",
                        fontweight: FontWeight.bold,
                        TextColor: Colors.white,
                        fontsize: 36),
                  ],
                )),
            SizedBox(
              height: 30,
            ),
            Container(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Form(
                    key: _formKey,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            CustomText(
                                TextValue: "Select Transfer",
                                fontweight: FontWeight.bold,
                                TextColor: Colors.black,
                                fontsize: 20),
                          ],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Flexible(
                              child: RadioListTile(
                                title: Text("Immediate"),
                                value: "immediate",
                                groupValue: transfertype,
                                onChanged: _handleRadioValueChange,
                              ),
                            ),
                            Flexible(
                              child: RadioListTile(
                                title: Text("Next Day"),
                                value: "Next Day",
                                groupValue: transfertype,
                                onChanged: _handleRadioValueChange,
                              ),
                            ),
                          ],
                        ),

                        SizedBox(
                          height: 15,
                        ),
                        TextFormField(
                          keyboardType: TextInputType.text,
                          textInputAction: TextInputAction.next,
                          controller: namecontroller,
                          // validator: (value) {
                          // //   if (value!.isEmpty) {
                          //     return 'Please select number';
                          //   }
                          //   return null;
                          // },
                          decoration: InputDecoration(
                            counterText: "",
                            hintText: "Enter Your Name",
                            fillColor: AppTheme.dropdowncolo,
                            //Add isDense true and zero Padding.
                            //Add Horizontal padding using buttonPadding and Vertical padding by increasing buttonHeight instead of add Padding here so that The whole TextField Button become clickable, and also the dropdown menu open under The whole TextField Button.
                            contentPadding: EdgeInsets.all(10),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20),
                            ),
                            //Add more decoration as you want here
                            //Add label If you want but add hint outside the decoration to be aligned in the button perfectly.
                          ),
                        ),
                        SizedBox(
                          height: 15,
                        ),

                        TextFormField(
                          keyboardType: TextInputType.number,
                          maxLength: 24,
                          textInputAction: TextInputAction.next,
                          controller: phonenumberController,
                          validator: (value) {
                            if (value!.isEmpty || value.length <4) {
                              return 'Please add a valid account number';
                            }
                            return null;
                          },
                          decoration: InputDecoration(
                            counterText: "",
                            hintText: "Enter Account Number",
                            fillColor: AppTheme.dropdowncolo,
                            contentPadding: EdgeInsets.all(10),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 15,
                        ),
                        Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                Expanded(
                                  child: SizedBox(
                                    width: 200,
                                    height: 75,
                                    child: Padding(
                                      padding: const EdgeInsets.only(top: 7),
                                      child: TextFormField(
                                        keyboardType: TextInputType.number,
                                        textInputAction: TextInputAction.next,
                                        controller: ammountcontroller,


                                          // if (int.parse(value) > 500000) {
                                          //   return 'range (6)=>(500000)';
                                          // }
                                          // if (int.parse(value) < 1) {
                                          //   return 'range (6)=>(1)';
                                          // }
                                          // return null;

                                        validator: (value) {
                                          if (value!.isEmpty) {
                                            return 'Please enter amount';
                                          }
                                          int amount = int.parse(value);
                                          if (transfertype == "Next Day" && amount > 2000000) {
                                            return 'Amount should be less than or equal to 2,000,000';
                                          }
                                          if (transfertype == "immediate" && amount > 500000) {
                                            return 'Amount should be less than or equal to 500,000';
                                          }
                                          if (amount < 1) {
                                            return 'Amount should be greater than or equal to 1';
                                          }
                                          return null;
                                        },
                                        onChanged: (String value) {
                                          setState(
                                            () {
                                              multiplier = value.isEmpty ||
                                                      value == null
                                                  ? 0.0
                                                  : double.parse(value) *
                                                      (tranfertypeValueSelect()! +
                                                          voucherNum!);
                                              valueMultiply = int.parse(value);

                                              taxType = transfertype ==
                                                      'immediate'
                                                  ? txtMethod(double.parse(
                                                          ammountcontroller.text
                                                                  .trim()
                                                                  .isEmpty
                                                              ? '0'
                                                              : ammountcontroller
                                                                  .text
                                                                  .trim()
                                                                  .toString()))
                                                      .toString()
                                                  : '0.0';
                                              taxSplit = taxType.split('.');

                                              pkr = (double.parse(taxType) +
                                                      double.parse(
                                                          ammountcontroller
                                                                  .text.isEmpty
                                                              ? '0.0'
                                                              : ammountcontroller
                                                                  .text
                                                                  .toString())) *
                                                  num1!;
                                              totalAmount = transfertype ==
                                                      'immediate'
                                                  ? double.parse(
                                                          ammountcontroller
                                                                  .text.isEmpty
                                                              ? '0.0'
                                                              : ammountcontroller
                                                                  .text
                                                                  .toString()) +
                                                      double.parse(taxType)
                                                  : 0.0;
                                              totalsplit = totalAmount
                                                  .toString()
                                                  .split('.');
                                            },
                                          );
                                        },
                                        maxLength: 10,
                                        decoration: InputDecoration(
                                          counterText: "",
                                          hintText: "Enter amount in PKR",
                                          fillColor: AppTheme.dropdowncolo,
                                          //Add isDense true and zero Padding.
                                          //Add Horizontal padding using buttonPadding and Vertical padding by increasing buttonHeight instead of add Padding here so that The whole TextField Button become clickable, and also the dropdown menu open under The whole TextField Button.
                                          contentPadding: EdgeInsets.all(10),
                                          border: OutlineInputBorder(
                                            borderRadius:
                                                BorderRadius.circular(20),
                                          ),
                                          //Add more decoration as you want here
                                          //Add label If you want but add hint outside the decoration to be aligned in the button perfectly.
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                        transfertype == "immediate"
                            ? Padding(
                                padding: const EdgeInsets.only(top: 10),
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      " Tax in PKR",
                                      style: TextStyle(
                                          color: Colors.black,
                                          fontSize: 16,
                                          fontWeight: FontWeight.w500),
                                    ),
                                    Text(
                                      "=",
                                      style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.w500),
                                    ),
                                    Column(
                                      children: [
                                        Text("0"),
                                        // Text(transfertype == 'immediate'
                                        //     ? taxSplit.isEmpty
                                        //         ? '0'
                                        //         : taxSplit.length == 1
                                        //             ? '${taxSplit[0]}.0'
                                        //             : '${taxSplit[0]}.${taxSplit[1]}'
                                        //     : '0.0'),
                                      ],
                                    ),
                                  ],
                                ),
                              )
                            : Container(),
                        SizedBox(
                          height: 15,
                        ),
                        transfertype == "immediate"
                            ? Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    " Total Amount in PKR",
                                    style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 16,
                                        fontWeight: FontWeight.w500),
                                  ),
                                  Text(
                                    "=",
                                    style: TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.w500),
                                  ),
                                  Column(
                                    children: [
                                      Text(totalsplit.isEmpty
                                          ? '0'
                                          : "${totalsplit[0]}.${totalsplit.isEmpty ? '0' : totalsplit[1].toString()}"),
                                    ],
                                  ),
                                ],
                              )
                            : Container(),
                        SizedBox(
                          height: 15,
                        ),
                        InkWell(
                          onTap: () {
                            isOpen = !isOpen;
                            setState(() {});
                          },
                          child: Container(
                            height: 52,
                            width: double.infinity,
                            decoration:
                                BoxDecoration(color: Colors.grey.shade200),
                            child: Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 10),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(selectBank),
                                  Icon(
                                    isOpen
                                        ? Icons.keyboard_arrow_up
                                        : Icons.keyboard_arrow_down,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 15,
                        ),
                        if (isOpen)
                          ListView(
                            padding: EdgeInsets.zero,
                            primary: true,
                            shrinkWrap: true,
                            children: bankList!.data!
                                .map(
                                  (e) => InkWell(
                                    onTap: () {
                                      setState(() {
                                        selectBank = e.bankTitle.toString();
                                        selectedValue = e.id.toString();
                                        isOpen = false;
                                      });
                                    },
                                    child: Container(
                                      padding: EdgeInsets.all(8),
                                      decoration: BoxDecoration(
                                        color: selectBank == e.bankTitle
                                            ? AppTheme.greytxt
                                            : Colors.grey.shade200,
                                      ),
                                      child: Text(
                                        e.bankTitle.toString(),
                                        style: TextStyle(
                                          color: selectBank == e.bankTitle
                                              ? Colors.white
                                              : AppTheme.kBlack,
                                        ),
                                      ),
                                    ),
                                  ),
                                )
                                .toList(),
                          ),

                        SizedBox(
                          height: 15,
                        ),
                        Container(
                          height: 65,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(20),
                              color: Colors.grey.shade200),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              SizedBox(
                                width: MediaQuery.of(context).size.width * 0.55,
                                height: 60,
                                child: Padding(
                                  padding: const EdgeInsets.only(top: 7),
                                  child: TextFormField(
                                    keyboardType: TextInputType.number,
                                    textInputAction: TextInputAction.next,
                                    controller: vouchercontroller,
                                    // validator: (value) {
                                    //   if (value!.isEmpty) {
                                    //     return 'Please enter ammount';
                                    //   }
                                    //   return null;
                                    // },
                                    onChanged: (String value) {},
                                    decoration: InputDecoration(
                                      counterText: "",
                                      hintText: "Enter Voucher",
                                      fillColor: AppTheme.dropdowncolo,
                                      //Add isDense true and zero Padding.
                                      //Add Horizontal padding using buttonPadding and Vertical padding by increasing buttonHeight instead of add Padding here so that The whole TextField Button become clickable, and also the dropdown menu open under The whole TextField Button.
                                      contentPadding: EdgeInsets.all(10),
                                      border: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(20),
                                      ),
                                      //Add more decoration as you want here
                                      //Add label If you want but add hint outside the decoration to be aligned in the button perfectly.
                                    ),
                                  ),
                                ),
                              ),
                              ElevatedButton(
                                child: Text("Apply"),
                                onPressed: () {
                                  getVoucherValidate(
                                    vouchercontroller.text.toString().trim(),
                                  );
                                },
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Visibility(
                          visible: voucherbool,
                          child: Text(
                            "Voucher Add $voucherNum",
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Colors.green),
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        TextFormField(
                          keyboardType: TextInputType.text,
                          textInputAction: TextInputAction.next,
                          controller: remarkController,
                          decoration: InputDecoration(
                            hintText: "Enter your Remarks",
                            fillColor: AppTheme.dropdowncolo,
                            //Add isDense true and zero Padding.
                            //Add Horizontal padding using buttonPadding and Vertical padding by increasing buttonHeight instead of add Padding here so that The whole TextField Button become clickable, and also the dropdown menu open under The whole TextField Button.
                            contentPadding: EdgeInsets.all(10),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20),
                            ),
                            //Add more decoration as you want here
                            //Add label If you want but add hint outside the decoration to be aligned in the button perfectly.
                          ),
                        ),
                        SizedBox(
                          height: 20,
                        ),
                        Column(
                          children: [
                            Center(
                              child: ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: _imageList.length >= 3
                                      ? Colors.grey
                                      : Colors.deepOrangeAccent.shade100,
                                  onPrimary: Colors.black,
                                ),
                                onPressed: _imageList.length >= 3 ? null : _showImagePickerDialog,
                                child: Text(
                                  'Upload Bank Card Image',
                                  style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 18,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                            ),
                            _imageList.isNotEmpty
                                ? Row(
                              children: [
                                for (var i = 0; i < _imageList.length; i++)
                                  Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Stack(
                                      alignment: Alignment.topRight,
                                      children: [
                                        Image.file(
                                          _imageList[i],
                                          width: 100,
                                          height: 200,
                                          fit: BoxFit.cover,
                                        ),
                                        IconButton(
                                          onPressed: () {
                                            setState(() {
                                              _imageList.removeAt(i);
                                            });
                                          },
                                          icon: Icon(
                                            Icons.cancel_outlined,
                                            color: Colors.orangeAccent,
                                            size: 28,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                              ],
                            )
                                : Container(
                              height: 150,
                              child: Center(
                                child: Text(
                                  "No Image Found",
                                  style: TextStyle(
                                    color: Colors.black38,
                                    fontSize: 20,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            CustomBtn(
                                height: 40,
                                width: 120,
                                radius: 15,
                                btncol: Color(0xff4a4a4a),
                                btntxtcol: Colors.white,
                                btntxt: "Continue",
                                btntextsize: 16,
                                onTap: () {
                                  if (_formKey.currentState!.validate()) {
                                    if (selectedValue == null) {
                                      Fluttertoast.showToast(
                                          msg: "Select Bank",
                                          toastLength: Toast.LENGTH_SHORT,
                                          gravity: ToastGravity.TOP,
                                          timeInSecForIosWeb: 1,
                                          backgroundColor: Colors.red,
                                          textColor: Colors.white,
                                          fontSize: 16.0);
                                    } else {
                                      showDialog(
                                        context: context,
                                        builder: (ctx) => AlertDialog(
                                          title: const Text("Confirmation"),
                                          content: SizedBox(
                                            // height: 240,
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                const Text(
                                                  "Please Confirm your details",
                                                  style: TextStyle(
                                                      fontSize: 17,
                                                      fontWeight:
                                                          FontWeight.bold),
                                                ),
                                                SizedBox(
                                                  height: 10,
                                                ),
                                                Text(
                                                  "Account Number",
                                                  style: TextStyle(
                                                      fontSize: 14,
                                                      fontWeight:
                                                          FontWeight.bold),
                                                ),
                                                Divider(),
                                                Text(
                                                  phonenumberController.text,
                                                  style: TextStyle(
                                                    fontSize: 12,
                                                  ),
                                                ),
                                                // Text(
                                                //   "Account Number",
                                                //   style: TextStyle(
                                                //       fontSize: 14,
                                                //       fontWeight:
                                                //           FontWeight.bold),
                                                // ),
                                                Divider(),
                                                Text(
                                                  "Transfer Type",
                                                  style: TextStyle(
                                                    fontSize: 12,
                                                  ),
                                                ),
                                                Text(
                                                  transfertype.toString(),
                                                  style: TextStyle(
                                                    fontSize: 12,
                                                  ),
                                                ),
                                                SizedBox(
                                                  height: 10,
                                                ),
                                                Divider(),
                                                Text(
                                                  "Amount",
                                                  style: TextStyle(
                                                      fontSize: 14,
                                                      fontWeight:
                                                          FontWeight.bold),
                                                ),
                                                transfertype == 'immediate'
                                                    ? Text(
                                                        totalsplit.isEmpty
                                                            ? '0'
                                                            : "${totalsplit[0]}.${totalsplit.isEmpty ? '0' : totalsplit[1].toString()}",
                                                        style: TextStyle(
                                                            fontSize: 12),
                                                      )
                                                    : Text(
                                                        ammountcontroller.text,
                                                        style: TextStyle(
                                                          fontSize: 12,
                                                        ),
                                                      ),
                                                SizedBox(
                                                  height: 10,
                                                ),
                                                Divider(),
                                                Text(
                                                  "Selected Bank ",
                                                  style: TextStyle(
                                                      fontSize: 14,
                                                      fontWeight:
                                                          FontWeight.bold),
                                                ),

                                                Text(
                                                  selectBank,
                                                  style: TextStyle(
                                                      fontSize: 12,
                                                      fontWeight:
                                                          FontWeight.bold),
                                                ),

                                                Divider(),
                                                SizedBox(
                                                  height: 10,
                                                ),
                                                Text(
                                                  "Voucher  Amount  ",
                                                  style: TextStyle(
                                                      fontSize: 14,
                                                      fontWeight:
                                                          FontWeight.bold,
                                                      color: Colors.green),
                                                ),

                                                Text(
                                                  voucherNum.toString(),
                                                  style: TextStyle(
                                                      fontSize: 12,
                                                      fontWeight:
                                                          FontWeight.bold,
                                                      color: Colors.green),
                                                ),
                                                Divider(),
                                                SizedBox(
                                                  height: 10,
                                                ),
                                                Text(
                                                  "Total Rate  ",
                                                  style: TextStyle(
                                                      fontSize: 14,
                                                      fontWeight:
                                                          FontWeight.bold,
                                                      color: Colors.red),
                                                ),

                                                Text(
                                                  "${total()}",
                                                  style: TextStyle(
                                                      fontSize: 12,
                                                      fontWeight:
                                                          FontWeight.bold,
                                                      color: Colors.red),
                                                ),
                                                Divider(),
                                              ],
                                            ),
                                          ),
                                          actions: <Widget>[
                                            Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.spaceAround,
                                              children: [
                                                TextButton(
                                                  onPressed: () {
                                                    Navigator.of(ctx).pop();
                                                  },
                                                  child: Container(
                                                    decoration: BoxDecoration(
                                                        color: AppTheme.darkbg,
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(20)),
                                                    padding:
                                                        const EdgeInsets.all(
                                                            14),
                                                    child: const Text(
                                                      "Edit Info",
                                                      style: TextStyle(
                                                          color: Colors.white),
                                                    ),
                                                  ),
                                                ),
                                                TextButton(
                                                  onPressed: () {
                                                    createOrder();
                                                    Navigator.of(ctx).pop();
                                                  },
                                                  child: Container(
                                                    decoration: BoxDecoration(
                                                        color: AppTheme.darkbg,
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(20)),
                                                    padding:
                                                        const EdgeInsets.all(
                                                            14),
                                                    child: const Text(
                                                      "Create Order",
                                                      style: TextStyle(
                                                          color: Colors.white),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            )
                                          ],
                                        ),
                                      );
                                      //createOrder();
                                    }
                                  }
                                },
                                fontw: FontWeight.bold),
                            CustomBtn(
                                height: 40,
                                width: 120,
                                radius: 15,
                                btncol: Color(0xff4a4a4a),
                                btntxtcol: AppTheme.btntxt,
                                btntxt: "Cancel",
                                btntextsize: 16,
                                onTap: () {
                                  showDialog(
                                    context: context,
                                    builder: (ctx) => AlertDialog(
                                      title: const Text("Alert"),
                                      content: const Text(
                                          "Are you sure to want cancel this order"),
                                      actions: <Widget>[
                                        TextButton(
                                          onPressed: () {
                                            Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                    builder: (context) =>
                                                        MainScreen()));
                                          },
                                          child: Container(
                                            decoration: BoxDecoration(
                                                color: AppTheme.darkbg,
                                                borderRadius:
                                                    BorderRadius.circular(20)),
                                            padding: const EdgeInsets.all(14),
                                            child: const Text(
                                              "Cancel",
                                              style: TextStyle(
                                                  color: Colors.white),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  );
                                },
                                fontw: FontWeight.bold)
                          ],
                        ),
                      ],
                    ),
                  ).pSymmetric(h: 30),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  double? tranfertypeValueSelect() {
    if (transfertype == 'immediate') {
      return num2;
    } else {
      return num1;
    }
  }

  double total() {
    double aa = tranfertypeValueSelect()! + voucherNum!;

    return aa;
  }

  void createOrder() async {
    try {
      print("this function call++++++++++++++++");

      PopupLoader.show();
      String token = Hive.box('box').get('token');

      String url = '${baseURL}api/v1/create_order';

      if (_imageList.isEmpty) {
        final response = await http.post(Uri.parse(url), headers: {
          "Accept": "application/json",
          "Authorization": 'Bearer $token',
        }, body: {
          "order_type": "Bank Transfer",
          "amount": ammountcontroller.text.toString(),
          "user_remarks": remarkController.text.toString(),
          "phone_number": phonenumberController.text.toString(),
          "bank": selectedValue.toString(),
          "order_nature": transfertype.toString(),
          "tax": pkr.toString().substring(0, 3),
          'convert_rate': tranfertypeValueSelect().toString(),
          'amount_after_convert': total().toString(),
          "title": namecontroller.text.toString(),
        });
        if (response.statusCode == 200) {
          print("after status function call..........");
          Fluttertoast.showToast(
              msg: "Order Created Successfully",
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.BOTTOM,
              timeInSecForIosWeb: 1,
              backgroundColor: Colors.green,
              textColor: Colors.white,
              fontSize: 16.0);
          PopupLoader.hide();
          Get.back();
        } else {
          print("else function call..........");
          Fluttertoast.showToast(
              msg: "Transaction failed",
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.TOP,
              timeInSecForIosWeb: 1,
              backgroundColor: Colors.red,
              textColor: Colors.white,
              fontSize: 16.0);
          PopupLoader.hide();
          // Get.back();
        }
      } else {
        var request = http.MultipartRequest('POST', Uri.parse(url));
        request.fields.addAll({
          "order_type": "Bank Transfer",
          "amount": ammountcontroller.text.toString(),
          "user_remarks": remarkController.text.toString(),
          "phone_number": phonenumberController.text.toString(),
          "bank": selectedValue.toString(),
          "order_nature": transfertype.toString(),
          "tax": taxType,
          'convert_rate': tranfertypeValueSelect().toString(),
          'amount_after_convert': multiplier.toString(),
          "title": namecontroller.text.toString(),
          "voucher_id": voucher_id,
        });
        for (int i = 0; i < _imageList.length; i++) {
          String key = "b_transfer_img";
          if (i == 0) {
            key = "b_transfer_img";
          }
          if (i == 1) {
            key = "b_transfer_img2";
          }
          if (i == 2) {
            key = "b_transfer_img3";
          }
          request.files
              .add(await http.MultipartFile.fromPath(key, _imageList[i].path));
        }

        request.headers.addAll(
          {"Accept": "application/json", "Authorization": 'Bearer $token'},
        );
        http.StreamedResponse response = await request.send();
        if (response.statusCode == 200) {
          Fluttertoast.showToast(
              msg: "Order Created Successfully",
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.BOTTOM,
              timeInSecForIosWeb: 1,
              backgroundColor: Colors.green,
              textColor: Colors.white,
              fontSize: 16.0);
          PopupLoader.hide();
          Get.back();
        } else {
          Fluttertoast.showToast(
              msg: "Transaction failed",
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.TOP,
              timeInSecForIosWeb: 1,
              backgroundColor: Colors.red,
              textColor: Colors.white,
              fontSize: 16.0);
          PopupLoader.hide();
          Get.back();
        }
      }
    } catch (e) {
      PopupLoader.hide();
      if (kDebugMode) {}
    }
  }

  void getVoucherValidate(String voucher) async {
    try {
      String token = Hive.box('box').get('token');

      String url = '${baseURL}api/v1/get_single_voucher';
      PopupLoader.show();

      final response = await http.post(Uri.parse(url), body: {
        "voucher_no": voucher,
      }, headers: {
        "Accept": "application/json",
        "Authorization": 'Bearer $token'
      });
      var data = jsonDecode(response.body);
      if (response.statusCode == 200) {
        if (data['data']['status'] == "used") {
          voucherbool = false;
          voucherNum = 0;
          Fluttertoast.showToast(
              msg: "Voucher Used ",
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.BOTTOM,
              timeInSecForIosWeb: 1,
              backgroundColor: Colors.green,
              textColor: Colors.white,
              fontSize: 16.0);
          PopupLoader.hide();
        } else {
          Fluttertoast.showToast(
              msg: "Voucher Active ",
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.BOTTOM,
              timeInSecForIosWeb: 1,
              backgroundColor: Colors.green,
              textColor: Colors.white,
              fontSize: 16.0);
          PopupLoader.hide();
          setState(() {
            if (data['data']['status'] == 'not-used') {
              voucherNum = double.parse(data['data']['voucher_percent']);
              voucher_id = data['data']['id'];
            }
            voucherbool = true;
          });
          // Get.back();
        }
      } else {
        remarkController.clear();
        Fluttertoast.showToast(
            msg: "Voucher Used",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.TOP,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0);
        PopupLoader.hide();
        // Get.back();
      }
    } catch (e) {
      PopupLoader.hide();
    }
  }

  getAllList() async {
    String token = Hive.box('box').get('token');

    String url = '${baseURL}api/v1/get_bank_list';
    final response = await http.get(Uri.parse(url), headers: {
      "Accept": "application/json",
      "Authorization": 'Bearer $token'
    });
    if (response.statusCode == 200) {
      var data = jsonDecode(response.body);
      bankList = AllBankList.fromJson(data);
    } else {}
  }
}

Future<List<File>> pickImages() async {
  final ImagePicker _picker = ImagePicker();
  List<File> _imageList = [];
  String name = "gallery";

  try {
    if (name != "camera") {
      final List<XFile>? _imageFiles = await _picker.pickMultiImage();
      for (XFile imageFile in _imageFiles!) {
        File file = File(imageFile.path);
        _imageList.add(file);
      }
    } else {
      final XFile? _imageFile =
          await _picker.pickImage(source: ImageSource.camera);

      if (_imageFile != null) {
        File file = File(_imageFile.path);
        _imageList.add(file);
      }
    }
  } catch (e) {}

  return _imageList;
}

class ImagePickerScreen extends StatefulWidget {
  @override
  _ImagePickerScreenState createState() => _ImagePickerScreenState();
}

class _ImagePickerScreenState extends State<ImagePickerScreen> {
  List<File> _imageList = [];

  Future<void> _pickImages() async {
    List<File> images = await pickImages();

    setState(() {
      _imageList = images;
    });
  }

  String name = "camera";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Image Picker'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _imageList.isNotEmpty
                ? Expanded(
                    child: ListView.builder(
                      itemCount: _imageList.length,
                      itemBuilder: (context, index) {
                        return Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Image.file(_imageList[index]),
                        );
                      },
                    ),
                  )
                : Container(),
            Divider(),
            Divider(),
            GestureDetector(
              onTap: () {
                _pickImages();
              },
              child: Container(
                height: 40,
                width: 200,
                child: Text("Camera"),
                color: Colors.deepOrangeAccent,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
