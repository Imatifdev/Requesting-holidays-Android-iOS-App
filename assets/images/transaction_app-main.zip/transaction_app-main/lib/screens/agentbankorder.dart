// ignore_for_file: prefer_final_fields, unused_field, non_constant_identifier_names, prefer_const_constructors, depend_on_referenced_packages

import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:velocity_x/velocity_x.dart';

import 'package:transactionsapp/utils/theme.dart';
import 'package:transactionsapp/widgets/custombutton.dart';
import 'package:transactionsapp/widgets/customtext.dart';

import 'banktransfer.dart';

class BankOrder extends StatefulWidget {
  const BankOrder({super.key});

  @override
  State<BankOrder> createState() => _BankOrderState();
}

class _BankOrderState extends State<BankOrder> {
  TextEditingController showcompletedcompleted = TextEditingController();
  TextEditingController showcompletedcompletedremarks = TextEditingController();
  TextEditingController showpartiallycompleted = TextEditingController();
  TextEditingController showpartiallycompletedremarks = TextEditingController();
  TextEditingController showunverifiedcompleted = TextEditingController();
  TextEditingController showunverifiedcompletedremarks =
      TextEditingController();

  TextEditingController shownoaccount = TextEditingController();
  TextEditingController shownoaccountremarks = TextEditingController();

  bool _showcompleted = false;
  bool _partiallycompleted = false;
  bool _Unverified = false;
  bool _noaccount = false;
  bool _cancel = false;
  File? _image;
  final _picker = ImagePicker();
  // Implementing the image picker
  Future<void> _openImagePicker() async {
    final XFile? pickedImage =
        await _picker.pickImage(source: ImageSource.gallery);
    if (pickedImage != null) {
      setState(() {
        _image = File(pickedImage.path);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
          child: Column(
            children: [
              Container(
                decoration: BoxDecoration(
                  color: AppTheme.darkbg,
                  borderRadius: BorderRadius.only(
                    bottomRight: Radius.circular(30.0),
                    bottomLeft: Radius.circular(30.0),
                  ),
                ),
                width: double.infinity,
                height: 250,
                child: Column(
                  children: [
                    Row(
                      children: [
                        CircleAvatar(
                          radius: 25,
                          backgroundColor: Colors.white,
                          backgroundImage: AssetImage("assets/images/splash.png"),
                        ),
                        CustomText(
                                TextValue: "Transec",
                                fontweight: FontWeight.normal,
                                TextColor: Colors.white,
                                fontsize: 25)
                            .pOnly(left: 10),
                      ],
                    ),
                    SizedBox(
                      height: 50,
                    ),
                    CustomText(
                        TextValue: "Bank Order",
                        fontweight: FontWeight.bold,
                        TextColor: Colors.white,
                        fontsize: 50),
                  ],
                ).pSymmetric(h: 20, v: 20),
              ),
              Column(
                children: [
                  Row(
                    children: [
                      // This switch controls the existence of the green box
                      Switch(
                        activeColor: AppTheme.darkbg,
                        value: _showcompleted,
                        onChanged: (value) {
                          setState(() {
                            _showcompleted = value;
                            _partiallycompleted = false;
                            _Unverified = false;
                            _noaccount = false;
                            _cancel = false;
                          });
                        },
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        child: const Text('Completed'),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      // This switch controls the existence of the green box
                      Switch(
                        activeColor: AppTheme.darkbg,
                        value: _partiallycompleted,
                        onChanged: (value) {
                          setState(() {
                            _showcompleted = false;
                            _partiallycompleted = value;
                            _Unverified = false;
                            _noaccount = false;
                            _cancel = false;
                          });
                        },
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        child: const Text('Partially Completed'),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      // This switch controls the existence of the green box
                      Switch(
                        activeColor: AppTheme.darkbg,
                        value: _Unverified,
                        onChanged: (value) {
                          setState(() {
                            _showcompleted = false;
                            _partiallycompleted = false;
                            _Unverified = value;
                            _noaccount = false;
                            _cancel = false;
                          });
                        },
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        child: const Text('Unverified'),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      // This switch controls the existence of the green box
                      Switch(
                        activeColor: AppTheme.darkbg,
                        value: _noaccount,
                        onChanged: (value) {
                          setState(() {
                            _noaccount = value;
                            _showcompleted = false;
                            _partiallycompleted = false;
                            _Unverified = false;
                            _cancel = false;
                          });
                        },
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        child: const Text('No Account'),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      // This switch controls the existence of the green box
                      Switch(
                        activeColor: AppTheme.darkbg,
                        value: _cancel,
                        onChanged: (value) {
                          setState(() {
                            _showcompleted = false;
                            _partiallycompleted = false;
                            _Unverified = false;
                            _noaccount = false;
                            _cancel = value;
                          });
                        },
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        child: const Text('Cancel'),
                      ),
                    ],
                  ),
                  if (_showcompleted)
                    SizedBox(
                      width: double.infinity,
                      height: 500,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          CustomText(
                              TextValue: "Completed",
                              fontweight: FontWeight.bold,
                              TextColor: Colors.black,
                              fontsize: 20),
                          TextFormField(
                            controller: showcompletedcompleted,
                            decoration:
                                InputDecoration(hintText: "Enter Transaction ID"),
                          ),
                          TextFormField(
                            decoration: InputDecoration(
                                suffixIcon: IconButton(
                                  icon: Icon(
                                    Icons.photo,
                                    size: 50,
                                    color: AppTheme.darkbg,
                                  ),
                                  onPressed: _openImagePicker,
                                ).p(10),
                                hintText: "Upload Picture"),
                          ),
                          TextFormField(
                            controller: showcompletedcompletedremarks,
                            decoration:
                                InputDecoration(hintText: "Note or Remarks"),
                          ),
                          const SizedBox(height: 35),
                          Container(
                            alignment: Alignment.center,
                            width: double.infinity,
                            height: 200,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(20)),
                            child: _image != null
                                ? Image.file(_image!, fit: BoxFit.contain)
                                : const Text('Please select an image'),
                          )
                        ],
                      ),
                    ),
                  if (_partiallycompleted)
                    SizedBox(
                      width: double.infinity,
                      height: 500,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          CustomText(
                              TextValue: "Partially Completed",
                              fontweight: FontWeight.bold,
                              TextColor: Colors.black,
                              fontsize: 20),
                          TextFormField(
                            controller: showpartiallycompleted,
                            decoration:
                                InputDecoration(hintText: "Enter Transaction ID"),
                          ),
                          TextFormField(
                            decoration: InputDecoration(
                                suffixIcon: IconButton(
                                  icon: Icon(
                                    Icons.photo,
                                    size: 50,
                                    color: AppTheme.darkbg,
                                  ),
                                  onPressed: _openImagePicker,
                                ).p(10),
                                hintText: "Upload Picture"),
                          ),
                          TextFormField(
                            controller: showpartiallycompletedremarks,
                            decoration:
                                InputDecoration(hintText: "Note or Remarks"),
                          ),
                          const SizedBox(height: 35),
                          Container(
                            alignment: Alignment.center,
                            width: double.infinity,
                            height: 200,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(20)),
                            child: _image != null
                                ? Image.file(_image!, fit: BoxFit.contain)
                                : const Text('Please select an image'),
                          )
                        ],
                      ),
                    ),
                  if (_cancel)
                    SizedBox(
                      width: double.infinity,
                      height: 500,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          CustomText(
                              TextValue: "Cancel/Unverified ",
                              fontweight: FontWeight.bold,
                              TextColor: Colors.black,
                              fontsize: 20),
                          TextFormField(
                            controller: showunverifiedcompletedremarks,
                            decoration:
                                InputDecoration(hintText: "Note or Remarks"),
                          ),
                        ],
                      ),
                    ),
                  if (_Unverified)
                    SizedBox(
                      width: double.infinity,
                      height: 500,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          CustomText(
                              TextValue: "Cancel/Unverified ",
                              fontweight: FontWeight.bold,
                              TextColor: Colors.black,
                              fontsize: 20),
                          TextFormField(
                            controller: showunverifiedcompletedremarks,
                            decoration:
                                InputDecoration(hintText: "Note or Remarks"),
                          ),
                        ],
                      ),
                    ),
                  CustomBtn(
                      height: 50,
                      width: MediaQuery.of(context).size.width - 100,
                      radius: 20,
                      btncol: AppTheme.darkbg,
                      btntxtcol: Colors.white,
                      btntxt: "Confirm",
                      btntextsize: 16,
                      onTap: () {},
                      fontw: FontWeight.bold)
                ],
              ).p(20),
            ],
          )),
    );
  }
}