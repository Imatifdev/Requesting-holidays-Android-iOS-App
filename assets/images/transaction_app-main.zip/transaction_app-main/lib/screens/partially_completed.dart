import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hive/hive.dart';
import 'package:open_file/open_file.dart';

import 'package:transactionsapp/models/getspecificorderbyusertype.dart';
import 'package:transactionsapp/screens/update_agent_screen.dart';
import 'package:transactionsapp/utils/pdf_invoice.dart';
import 'package:transactionsapp/utils/pdf_openfile.dart';
import 'package:shimmer/shimmer.dart';
import 'package:http/http.dart' as http;
import '../controller/get_agentside_orderlist_controller.dart';
import '../networks/apicall.dart';

class PartiallyCompletedView extends StatefulWidget {


  @override
  State<PartiallyCompletedView> createState() => _PartiallyCompletedViewState();
}

class _PartiallyCompletedViewState extends State<PartiallyCompletedView> {
  StreamController<GetSpecificOrderByUsertype> streamController4 =
  StreamController();
  Timer? _timer;
  @override
  void initState() {
    super.initState();
    orderFetch();
    _timer = Timer.periodic(
      const Duration(seconds: 6),
          (timer) {
        orderFetch();
      },
    );
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();

    _timer?.cancel();
  }

  List<GetSpecificOrderByUsertypeList> compeletList = [];
  GetSpecificOrderByUsertype? getSpecificOrderByUser;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: StreamBuilder<GetSpecificOrderByUsertype>(
        stream: streamController4.stream,
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            switch (snapshot.connectionState) {
              case ConnectionState.waiting:
                return ListView.builder(
                  itemCount: 4,
                  itemBuilder: (context, index) {
                    return Shimmer.fromColors(
                      baseColor: Colors.grey.shade700,
                      highlightColor: Colors.grey.shade100,
                      enabled: true,
                      child: Column(
                        children: [
                          ListTile(
                            leading: Container(
                              height: 50,
                              width: 50,
                              color: Colors.white,
                            ),
                            title: Container(
                              width: 100,
                              height: 8.0,
                              color: Colors.white,
                            ),
                            subtitle: Container(
                              width: double.infinity,
                              height: 8.0,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                );

              default:
                if (snapshot.hasError) {
                  return const Center(
                    child: Text('data'),
                  );
                } else {
                  GetSpecificOrderByUsertype specificOrderByUsertype =
                  snapshot.data as GetSpecificOrderByUsertype;
                  getSpecificOrderByUser = specificOrderByUsertype;
                  compeletList = specificOrderByUsertype.data!
                      .where((element) => element.orderStatus == 'Completed' )
                      .toList();
                  if (kDebugMode) {
                    print("length: ${compeletList.length.toString()}");
                  }
                  if (compeletList.isEmpty) {
                    return const Center(
                      child: Text('Empty List'),
                    );
                  }

                  return ListView.builder(
                    shrinkWrap: true,
                    scrollDirection: Axis.vertical,
                    physics: const BouncingScrollPhysics(),
                    itemCount: compeletList.length,
                    itemBuilder: (BuildContext context, int index) {
                      var specificOrderByUsertypeList = compeletList[index];
                      return GestureDetector(
                          onTap: () {
                            Get.to(
                                  () => AgentUpdateScreen(
                                orderByUsertype: specificOrderByUsertypeList,

                                  ),
                            );
                          },
                          child:
                          specificOrderByUsertypeList.ispartial =='1'?
                          Card(
                            color: Colors.grey.shade300,
                            elevation: 2,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12)),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Center(
                                  child: Text(specificOrderByUsertypeList.agent_remarks.toString(),style: TextStyle(
                                    color: Colors.blueGrey.shade600,fontSize: 15,fontWeight: FontWeight.w500,
                                  ),),
                                ),
                                Padding(
                                  padding: const EdgeInsets.all(8.0)
                                      .copyWith(bottom: 0),
                                  child: Row(
                                    children: [
                                      const Text(
                                        'Order Id',
                                        style: TextStyle(
                                            fontSize: 16,
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold),
                                      ),
                                      const Spacer(),
                                      Text(
                                        specificOrderByUsertypeList.id.toString(),
                                        style: const TextStyle(
                                            fontSize: 16,
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold),
                                      )
                                    ],
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Row(
                                    children: [
                                      const Text(
                                        'Order Type',
                                        style: TextStyle(
                                            fontSize: 16,
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold),
                                      ),
                                      const Spacer(),
                                      Text(
                                        specificOrderByUsertypeList.orderType
                                            .toString(),
                                        style: const TextStyle(
                                            fontSize: 16,
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold),
                                      )
                                    ],
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Row(
                                    children: [
                                      const Text(
                                        'Account No ',
                                        style: TextStyle(
                                            fontSize: 16,
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold),
                                      ),
                                      const Spacer(),
                                      Text(
                                        specificOrderByUsertypeList.phoneNumber
                                            .toString(),
                                        style: const TextStyle(
                                            fontSize: 16,
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold),
                                      )
                                    ],
                                  ),
                                ),
                                Padding(
                                  padding:
                                  const EdgeInsets.all(8.0).copyWith(top: 0),
                                  child: Row(
                                    children: [
                                      const Text(
                                        'Amount',
                                        style: TextStyle(
                                            fontSize: 15,
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold),
                                      ),
                                      const Spacer(),
                                      Text(
                                        'Pkr: ${specificOrderByUsertypeList.amount.toString()}',
                                        style: const TextStyle(
                                            fontSize: 15,
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold),
                                      ),
                                    ],
                                  ),
                                ),
                                // Padding(
                                //   padding:
                                //       const EdgeInsets.all(8.0).copyWith(top: 0),
                                //   child: Row(
                                //     children: [
                                //       const Text(
                                //         'Depositer Name',
                                //         style: TextStyle(
                                //             fontSize: 15,
                                //             color: Colors.black,
                                //             fontWeight: FontWeight.bold),
                                //       ),
                                //       const Spacer(),
                                //       Text(
                                //         specificOrderByUsertypeList.depositorName
                                //             .toString(),
                                //         style: const TextStyle(
                                //             fontSize: 15,
                                //             color: Colors.black,
                                //             fontWeight: FontWeight.bold),
                                //       )
                                //     ],
                                //   ),
                                // ),
                                Padding(
                                  padding:
                                  const EdgeInsets.all(8.0).copyWith(top: 0),
                                  child: Row(
                                    children: [
                                      const Text(
                                        'Date',
                                        style: TextStyle(
                                            fontSize: 15,
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold),
                                      ),
                                      const Spacer(),
                                      Text(
                                        specificOrderByUsertypeList.createdAt
                                            .toString(),
                                        style: const TextStyle(
                                            fontSize: 15,
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold),
                                      )
                                    ],
                                  ),
                                ),
                                Padding(
                                  padding:
                                  const EdgeInsets.all(8.0).copyWith(top: 0),
                                  child: Row(
                                    children: [
                                      const Text(
                                        'Order Status',
                                        style: TextStyle(
                                            fontSize: 15,
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold),
                                      ),
                                      const Spacer(),
                                      Text(
                                        "Partially-Completed",
                                        // specificOrderByUsertypeList.orderStatus
                                        //     .toString(),
                                        style: TextStyle(
                                            color: specificOrderByUsertypeList
                                                .orderStatus ==
                                                'Pending'
                                                ? Colors.redAccent
                                                : specificOrderByUsertypeList
                                                .orderStatus ==
                                                'Completed'
                                                ? Colors.green
                                                : Colors.black12,
                                            fontSize: 15,
                                            fontWeight: FontWeight.bold),
                                      )
                                    ],
                                  ),
                                )
                              ],
                            ),
                          ):Container()
                      );
                    },
                  );
                }
            }
          }
          return ListView.builder(
            itemCount: 4,
            itemBuilder: (context, index) {
              return Shimmer.fromColors(
                baseColor: Colors.grey.shade700,
                highlightColor: Colors.grey.shade100,
                enabled: true,
                child: Column(
                  children: [
                    ListTile(
                      leading: Container(
                        height: 50,
                        width: 50,
                        color: Colors.white,
                      ),
                      title: Container(
                        width: 100,
                        height: 8.0,
                        color: Colors.white,
                      ),
                      subtitle: Container(
                        width: double.infinity,
                        height: 8.0,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.black,
        onPressed: () async {
          List<GetSpecificOrderByUsertypeList> mycompletedList = [];
          double totalAmount = 0.0;
          double totalInSAR = 0.0;
          mycompletedList = compeletList
              .where((element) => element.orderStatus == 'Completed')
              .toList();
          for (int i = 0; i < mycompletedList.length; i++) {
            if (kDebugMode) {
              print(mycompletedList[i].amountAfterConvert);
            }
            totalAmount += double.parse(mycompletedList[i].amountAfterConvert!);
          }
          final pdf = await PdfInvoice.generateFile(
              getSpecificOrderByUsertype: getSpecificOrderByUser,
              istypeAgent: true,
              totalAmount: totalAmount,
            totalInSAR: totalInSAR,
          );

// Open the PDF file using the default viewer
          try {
            final result = await OpenFile.open(pdf!.path);
            print('Open file: ${result.message}');
          } catch (e) {
            print('Error opening file: $e');
          }
        },
        child: const Icon(
          Icons.print,
          size: 24,
        ),
      ),
    );
  }

  Future<void> orderFetch() async {
    String token = Hive.box('box').get('token');

    String url = '${baseURL}api/v1/get_specific_order_by_usertype';
    final response = await http.get(
      Uri.parse(url),
      // Send authorization headers to the backend.
      headers: {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
    );
    if (response.statusCode == 200) {
      // If the server did return a 200 OK response,
      // then parse the JSON.
      var data = jsonDecode(response.body);
      GetSpecificOrderByUsertype getSpecificOrderByUsertype =
      GetSpecificOrderByUsertype.fromJson(data);
      streamController4.sink.add(getSpecificOrderByUsertype);
    } else {
      throw Exception('Failed to load album');
    }
  }
}
