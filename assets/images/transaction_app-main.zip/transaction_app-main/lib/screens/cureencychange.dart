// // ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables, curly_braces_in_flow_control_structures

// import 'package:flutter/material.dart';
// import 'package:transactionsapp/utils/constants.dart';
// import 'package:transactionsapp/utils/theme.dart';
// import 'package:velocity_x/velocity_x.dart';
// import '../models/currencymodel.dart';
// import 'package:dropdown_button2/dropdown_button2.dart';

// class CurrencyCon extends StatefulWidget {
//   const CurrencyCon({Key? key}) : super(key: key);

//   @override
//   State<CurrencyCon> createState() => _CurrencyConState();
// }

// class _CurrencyConState extends State<CurrencyCon> {
//   late Future<Currency?> getCurrencyData;

//   String dropdownValue1 = 'INR';
//   String dropdownValue2 = 'INR';

//   String pickerValue1 = "AMD";
//   String pickerValue2 = "AMD";
//   String? value;
//   String answer = '';

//   final currencyExchangeFormKey = GlobalKey<FormState>();
//   final TextEditingController amountofCurrencyController =
//       TextEditingController();
//   final TextEditingController iosAmountofCurrencyController =
//       TextEditingController();

//   @override
//   void initState() {
//     // TODO: implement initState
//     super.initState();
//     getCurrencyData = CurrencyAPIHelper.apiHelper.fetchCurrencyData();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return SingleChildScrollView(
//       child: Container(
//         child: Form(
//           key: currencyExchangeFormKey,
//           child: Column(
//             mainAxisAlignment: MainAxisAlignment.center,
//             crossAxisAlignment: CrossAxisAlignment.center,
//             children: [
//               FutureBuilder(
//                 future: getCurrencyData,
//                 builder: (context, AsyncSnapshot snapshot) {
//                   if (snapshot.hasError) {
//                     return Center(
//                       child: Text("Error : ${snapshot.error}"),
//                     );
//                   } else if (snapshot.hasData) {
//                     Currency? data = snapshot.data;

//                     return Center(
//                       child: Column(
//                         mainAxisAlignment: MainAxisAlignment.center,
//                         crossAxisAlignment: CrossAxisAlignment.center,
//                         children: [
//                           Card(
//                             shape: RoundedRectangleBorder(
//                                 borderRadius: BorderRadius.circular(20)),
//                             elevation: 10,
//                             color: Colors.white,
//                             child: Container(
//                               child: Column(
//                                 children: [
//                                   Padding(
//                                     padding: const EdgeInsets.only(
//                                         left: 20, right: 70),
//                                     child: TextFormField(
//                                       keyboardType: TextInputType.number,
//                                       cursorColor: Colors.blueGrey,
//                                       cursorHeight: 20,
//                                       validator: (value) {
//                                         if (value!.isEmpty)
//                                           return "Enter ammount";
//                                       },
//                                       controller: amountofCurrencyController,
//                                       decoration: const InputDecoration(
//                                         hintText: "Enter Your Amount..",
//                                         hintStyle: TextStyle(
//                                           color: Colors.blueGrey,
//                                           fontSize: 15,
//                                         ),
//                                         focusedBorder: UnderlineInputBorder(
//                                           borderSide: BorderSide(
//                                               color: Colors.blueGrey),
//                                         ),
//                                         border: UnderlineInputBorder(
//                                           borderSide: BorderSide(
//                                             style: BorderStyle.solid,
//                                           ),
//                                         ),
//                                         icon: Icon(
//                                             size: 30,
//                                             color: Colors.blueGrey,
//                                             Icons.attach_money),
//                                       ),
//                                     ),
//                                   ),
//                                   SizedBox(
//                                     height: 10,
//                                   ),
//                                   DropdownButtonFormField2(
//                                     focusColor: AppTheme.dropdowncolo,
//                                     decoration: InputDecoration(
//                                       fillColor: AppTheme.dropdowncolo,
//                                       //Add isDense true and zero Padding.
//                                       //Add Horizontal padding using buttonPadding and Vertical padding by increasing buttonHeight instead of add Padding here so that The whole TextField Button become clickable, and also the dropdown menu open under The whole TextField Button.
//                                       contentPadding: EdgeInsets.zero,
//                                       border: OutlineInputBorder(
//                                         borderRadius: BorderRadius.circular(20),
//                                       ),
//                                       //Add more decoration as you want here
//                                       //Add label If you want but add hint outside the decoration to be aligned in the button perfectly.
//                                     ),
//                                     isExpanded: true,
//                                     hint: const Text(
//                                       'Saudi Riyal',
//                                       style: TextStyle(fontSize: 14),
//                                     ),
//                                     icon: const Icon(
//                                       Icons.arrow_drop_down,
//                                       color: Colors.black45,
//                                     ),
//                                     iconSize: 30,
//                                     buttonHeight: 60,
//                                     buttonPadding: const EdgeInsets.only(
//                                         left: 20, right: 10),
//                                     dropdownDecoration: BoxDecoration(
//                                       color: AppTheme.dropdowncolo,
//                                       borderRadius: BorderRadius.circular(15),
//                                     ),
//                                     items: data!.rates.keys
//                                         .toSet()
//                                         .toList()
//                                         .map<DropdownMenuItem<String>>((value) {
//                                       return DropdownMenuItem<String>(
//                                         value: value,
//                                         child: Text(
//                                           '$value:    Select From',
//                                           style: TextStyle(
//                                               fontWeight: FontWeight.bold),
//                                         ),
//                                       );
//                                     }).toList(),
//                                     value: dropdownValue2,
//                                     validator: (value) {
//                                       if (value == null) {
//                                         return 'Please select account';
//                                       }
//                                     },
//                                     onChanged: (String? value) {
//                                       setState(() {
//                                         dropdownValue2 = value!;
//                                       });
//                                     },
//                                   ),
//                                   GestureDetector(
//                                     child: Image.asset(
//                                       "assets/images/exg.png",
//                                       height: 50,
//                                       width: 50,
//                                     ),
//                                     onTap: () {
//                                       if (currencyExchangeFormKey.currentState!
//                                           .validate())
//                                         setState(() {
//                                           answer =
//                                               "${amountofCurrencyController.text} $dropdownValue1 = ${convertansy(
//                                             data.rates,
//                                             amountofCurrencyController.text,
//                                             dropdownValue1,
//                                             dropdownValue2,
//                                           )}$dropdownValue2";
//                                         });
//                                     },
//                                   ).p(20),
//                                   DropdownButtonFormField2(
//                                     focusColor: AppTheme.dropdowncolo,
//                                     decoration: InputDecoration(
//                                       fillColor: AppTheme.dropdowncolo,
//                                       //Add isDense true and zero Padding.
//                                       //Add Horizontal padding using buttonPadding and Vertical padding by increasing buttonHeight instead of add Padding here so that The whole TextField Button become clickable, and also the dropdown menu open under The whole TextField Button.
//                                       contentPadding: EdgeInsets.zero,
//                                       border: OutlineInputBorder(
//                                         borderRadius: BorderRadius.circular(20),
//                                       ),
//                                       //Add more decoration as you want here
//                                       //Add label If you want but add hint outside the decoration to be aligned in the button perfectly.
//                                     ),
//                                     isExpanded: true,
//                                     hint: const Text(
//                                       'JazzCash',
//                                       style: TextStyle(fontSize: 14),
//                                     ),
//                                     icon: const Icon(
//                                       Icons.arrow_drop_down,
//                                       color: Colors.black45,
//                                     ),
//                                     iconSize: 30,
//                                     buttonHeight: 60,
//                                     buttonPadding: const EdgeInsets.only(
//                                         left: 20, right: 10),
//                                     dropdownDecoration: BoxDecoration(
//                                       color: AppTheme.dropdowncolo,
//                                       borderRadius: BorderRadius.circular(15),
//                                     ),
//                                     items: data.rates.keys
//                                         .toSet()
//                                         .toList()
//                                         .map<DropdownMenuItem<String>>((value) {
//                                       return DropdownMenuItem<String>(
//                                         value: value,
//                                         child: Text(
//                                           '$value:    Select to',
//                                           style: TextStyle(
//                                               fontWeight: FontWeight.bold),
//                                         ),
//                                       );
//                                     }).toList(),
//                                     value: dropdownValue1,
//                                     validator: (value) {
//                                       if (value == null) {
//                                         return 'Please select account';
//                                       }
//                                     },
//                                     onChanged: (String? value) {
//                                       setState(() {
//                                         dropdownValue1 = value!;
//                                       });
//                                     },
//                                   ),
//                                   SizedBox(
//                                     height: 20,
//                                   ),
//                                   Container(
//                                     alignment: Alignment.center,
//                                     height: 50,
//                                     width: 400,
//                                     decoration: BoxDecoration(
//                                       borderRadius: BorderRadius.circular(40),
//                                       border: Border.all(width: 2),
//                                       color: Colors.white,
//                                     ),
//                                     child: Text(
//                                       "Convert Ammount =  $answer",
//                                       style: const TextStyle(
//                                         color: Colors.blueGrey,
//                                         fontWeight: FontWeight.bold,
//                                         fontSize: 15,
//                                       ),
//                                     ),
//                                   ),
//                                 ],
//                               ),
//                             ).pSymmetric(h: 10, v: 10),
//                           ),
//                           const SizedBox(height: 25),
//                         ],
//                       ),
//                     );
//                   }
//                   return const Center(
//                     child: LinearProgressIndicator(
//                       color: Colors.blueGrey,
//                     ),
//                   );
//                 },
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
