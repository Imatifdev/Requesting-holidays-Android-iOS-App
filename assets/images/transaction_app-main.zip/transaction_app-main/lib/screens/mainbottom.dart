// ignore_for_file: prefer_const_constructors, unused_field, prefer_const_literals_to_create_immutables

import 'package:flutter/material.dart';
import 'package:transactionsapp/screens/Home.dart';
import 'package:transactionsapp/screens/profile.dart';
import 'package:transactionsapp/screens/userorder.dart';
import 'package:transactionsapp/utils/theme.dart';

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int pageIndex = 0;

  final _listPage = [
    HomePage(),
    UserOrder(),
    Profile(),
  ];

  @override
  Widget build(BuildContext context) {
    // return CupertinoTabScaffold(
    //   tabBar: CupertinoTabBar(
    //     items: <BottomNavigationBarItem>[
    //       BottomNavigationBarItem(icon: Icon(Icons.home), label: 'HOME'),
    //       BottomNavigationBarItem(icon: Icon(Icons.list), label: 'Orders'),
    //       BottomNavigationBarItem(
    //           icon: Icon(Icons.account_circle_sharp), label: 'Profile'),
    //     ],
    //   ),
    //   tabBuilder: (context, index) {
    //     switch (index) {
    //       case 0:
    //         return CupertinoTabView(
    //           builder: (context) {
    //             return CupertinoPageScaffold(child: HomePage());
    //           },
    //         );
    //       case 1:
    //         return CupertinoTabView(
    //           builder: (context) {
    //             return CupertinoPageScaffold(child: UserOrder());
    //           },
    //         );
    //       case 2:
    //         return CupertinoTabView(
    //           builder: (context) {
    //             return CupertinoPageScaffold(child: Profile());
    //           },
    //         );
    //       default:
    //         return CupertinoTabView(
    //           builder: (context) {
    //             return CupertinoPageScaffold(child: MainScreen());
    //           },
    //         );
    //     }
    //   },
    // );

    return Scaffold(
      body: _listPage[pageIndex],
      bottomNavigationBar: BottomNavigationBar(
          currentIndex: pageIndex,
          elevation: 4,
          onTap: _onItemTapped,
          iconSize: 24,
          type: BottomNavigationBarType.fixed,
          selectedItemColor: AppTheme.newiconcolor,
          unselectedItemColor: Colors.grey,
          items: [
            BottomNavigationBarItem(icon: Icon(Icons.home), label: 'HOME'),
            BottomNavigationBarItem(
                icon: Icon(Icons.view_headline), label: 'Orders'),
            BottomNavigationBarItem(
                icon: Icon(Icons.account_circle_sharp), label: 'Profile'),
          ]),
    );
  }

  void _onItemTapped(int index) {
    setState(() {
      pageIndex = index;
    });
  }
}
