// ignore_for_file: prefer_const_constructors, depend_on_referenced_packages

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:transactionsapp/screens/agentloadorder.dart';
import 'package:transactionsapp/utils/theme.dart';
import 'package:transactionsapp/widgets/custombutton.dart';
import 'package:transactionsapp/widgets/customtext.dart';
import 'package:velocity_x/velocity_x.dart';

class LoadConfirmation extends StatefulWidget {
  const LoadConfirmation({super.key});

  @override
  State<LoadConfirmation> createState() => _LoadConfirmationState();
}

class _LoadConfirmationState extends State<LoadConfirmation> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        // ignore: prefer_const_literals_to_create_immutables
        children: [
          SizedBox(
            height: 50,
          ),
          CustomText(
              TextValue: "Load Order Transfer",
              fontweight: FontWeight.bold,
              TextColor: Colors.black,
              fontsize: 40),
          Divider(
            color: Colors.black,
            thickness: 3,
            height: 6,
          ),
          SizedBox(
            height: 20,
          ),
          CustomText(
              TextValue: "User Name",
              fontweight: FontWeight.bold,
              TextColor: Colors.black,
              fontsize: 24),
          CustomText(
              TextValue: "Ahmed Raza",
              fontweight: FontWeight.normal,
              TextColor: Colors.black,
              fontsize: 18),
          Divider(),
          CustomText(
              TextValue: "Selected Network Transfer",
              fontweight: FontWeight.bold,
              TextColor: Colors.black,
              fontsize: 24),
          Text(
            "Jazzcash",
            style: TextStyle(fontSize: 20),
          ),
          Divider(),
          CustomText(
              TextValue: "Customer Phone Number",
              fontweight: FontWeight.bold,
              TextColor: Colors.black,
              fontsize: 24),
          Text(
            "03001235678",
            style: TextStyle(fontSize: 20),
          ),
          Divider(),
          CustomText(
              TextValue: "Amount to be Transfer in Wallet",
              fontweight: FontWeight.bold,
              TextColor: Colors.black,
              fontsize: 24),
          Text(
            "1300",
            style: TextStyle(fontSize: 20),
          ),
          Divider(),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CustomBtn(
                  height: 50,
                  width: 150,
                  radius: 20,
                  btncol: AppTheme.darkbg,
                  btntxtcol: Colors.white,
                  btntxt: "Next ",
                  btntextsize: 20,
                  onTap: () => Get.to(() => LoadOrder()),
                  fontw: FontWeight.bold),
            ],
          )
        ],
      ).p(30),
    );
  }
}
