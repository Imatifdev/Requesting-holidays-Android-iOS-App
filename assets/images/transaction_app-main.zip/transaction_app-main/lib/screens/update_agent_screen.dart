// ignore_for_file: camel_case_types, depend_on_referenced_packages, must_be_immutable, prefer_const_constructors

import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';

import 'package:transactionsapp/models/getspecificorderbyusertype.dart';
import 'package:transactionsapp/networks/apicall.dart';
import 'package:transactionsapp/screens/agenthome.dart';
import 'package:transactionsapp/utils/loader.dart';
import 'package:transactionsapp/widgets/photo_widget.dart';

import '../utils/theme.dart';

class AgentUpdateScreen extends StatefulWidget {
  final GetSpecificOrderByUsertypeList orderByUsertype;
  const AgentUpdateScreen({
    super.key,
    required this.orderByUsertype,
  });

  @override
  State<AgentUpdateScreen> createState() => _AgentUpdateScreenState();
}

class _AgentUpdateScreenState extends State<AgentUpdateScreen> {
  StreamController<GetSpecificOrderByUsertype> streamController1 =
      StreamController();
  final TextEditingController _transectionIdController =
      TextEditingController();
  TextEditingController remarkController = TextEditingController();
  TextEditingController partialAmountController = TextEditingController();

  final _formKey = GlobalKey<FormState>();

  File? _image;
  double? partialAmount;
  final _picker = ImagePicker();
  Future<void> _openImagePicker() async {
    final XFile? pickedImage =
        await _picker.pickImage(source: ImageSource.gallery);
    if (pickedImage != null) {
      setState(() {
        _image = File(pickedImage.path);
      });
    }
  }

  int _selectedValue = 1;

  void _handleRadioValueChange(int? value) {
    setState(() {
      _selectedValue = value!;
    });
  }

  double inputValue = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: widget.orderByUsertype.request_for_cancel == "1"
          ? Colors.deepOrangeAccent.shade100
          : Colors.grey.shade100,
      appBar: AppBar(
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [AppTheme.profilecardgrad1, AppTheme.profilecardgrad2]),
          ),
        ),
        title: const Text('About Order '),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            // crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  Flexible(
                    child: RadioListTile(
                      title: Text('Complete', style: TextStyle(fontSize: 16.0)),
                      value: 0,
                      groupValue: _selectedValue,
                      onChanged: _handleRadioValueChange,
                    ),
                  ),
                  Flexible(
                    child: RadioListTile(
                      title: Text('Partial', style: TextStyle(fontSize: 16.0)),
                      value: 1,
                      groupValue: _selectedValue,
                      onChanged: _handleRadioValueChange,
                    ),
                  ),
                ],
              ),
              ResuableRow(
                  title: 'Order Id',
                  value: widget.orderByUsertype.id.toString()),
              ResuableRow(
                  title: 'Order Type',
                  value: widget.orderByUsertype.orderType.toString()),
              ResuableRow(
                  title: 'Bank Title',
                  value: widget.orderByUsertype.banktitle ?? ''),
              ResuableRow(
                title: 'Order Status',
                value: widget.orderByUsertype.orderStatus == 'Completed' &&
                        widget.orderByUsertype.ispartial == '1'
                    ? "Partially-Completed"
                    : widget.orderByUsertype.orderStatus.toString(),
                color: widget.orderByUsertype.orderStatus == 'Pending'
                    ? Colors.redAccent
                    : widget.orderByUsertype.orderStatus == 'Completed'
                        ? Colors.green
                        : Colors.red,
              ),
              ResuableRow(
                  title: 'Date',
                  value: widget.orderByUsertype.createdAt.toString()),
              ResuableRow(
                  title: 'Amount',
                  value:
                      // _selectedValue ==2?'Pkr:''$amount':
                      'Pkr: ${widget.orderByUsertype.amount.toString()}'),
              widget.orderByUsertype.orderType.toString() == 'Bank Transfer'
                  ? const SizedBox()
                  : ResuableRow(
                      title: 'Network',
                      value: widget.orderByUsertype.orderType ==
                              'Wallet Transfer'
                          ? widget.orderByUsertype.vTransferAccType.toString()
                          : widget.orderByUsertype.mTransferNetworkType
                              .toString()),
              ResuableRow(
                  title: 'phone Number',
                  value: widget.orderByUsertype.phoneNumber.toString()),
              ResuableRow(
                  title: 'name', value: widget.orderByUsertype.name.toString()),
              ResuableRow(
                  title: 'Client Remarks',
                  value: widget.orderByUsertype.userRemarks.toString()),
              Row(
                children: [
                  const Text('Client  Attachment',
                      style: TextStyle(
                          fontSize: 16,
                          color: Colors.black,
                          fontWeight: FontWeight.bold)),
                  const Spacer(),
                  SizedBox(
                    height: 34,
                    width: 80,
                    child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xff4a4a4a)),
                        onPressed: widget.orderByUsertype.bTransferImg == null
                            ? () {
                                Fluttertoast.showToast(
                                    msg:
                                        "No Attachement Available",
                                    toastLength: Toast.LENGTH_SHORT,
                                    gravity: ToastGravity.BOTTOM,
                                    timeInSecForIosWeb: 1,
                                    backgroundColor: Colors.green,
                                    textColor: Colors.white,
                                    fontSize: 16.0);
                              }
                            : () {
                                Get.to(() => PhotoViewScreen(
                                    image:
                                        widget.orderByUsertype.bTransferImg ??
                                            'Something went wrong',
                                    image2:
                                        widget.orderByUsertype.bTransferImg2 ??
                                            'Something went wrong',
                                    image3:
                                        widget.orderByUsertype.bTransferImg3 ??
                                            'Something went wrong'));
                              },
                        child: const Text(
                          'View ',
                          style: TextStyle(
                              fontSize: 15, fontWeight: FontWeight.bold),
                        )),
                  ),
                ],
              ),
              const Divider(),
              widget.orderByUsertype.orderStatus == "Pending" ||
                      widget.orderByUsertype.ispartial == '1'
                  ? Padding(
                      padding: const EdgeInsets.all(8.0).copyWith(bottom: 0),
                      child: Form(
                        key: _formKey,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            widget.orderByUsertype.ispartial == '0'
                                ? Padding(
                                    padding: const EdgeInsets.all(8.0)
                                        .copyWith(bottom: 0),
                                    child: const Text(
                                      'Transection Id',
                                      style: TextStyle(
                                          fontSize: 13,
                                          color: Colors.black,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  )
                                : Text(""),
                            widget.orderByUsertype.ispartial == '0'
                                ? CustomTextFeild(
                                    controller: _transectionIdController,
                                    hint: 'Enter transaction id ',
                                    fieldName: 'transaction id is ',
                                  )
                                : Text(""),
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: const Text(
                                'Agent Remarks',
                                style: TextStyle(
                                    fontSize: 13,
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(left: 8, right: 8),
                              child: TextFormField(
                                validator: (value) {
                                  if (_selectedValue == 1) {
                                    if (value == null || value.isEmpty) {
                                      return "Remarks is Required";
                                    }
                                  }
                                  return null;
                                },
                                keyboardType: TextInputType.text,
                                textInputAction: TextInputAction.next,
                                controller: remarkController,
                                decoration: InputDecoration(
                                  fillColor: Colors.white,
                                  filled: true,
                                  hintStyle: TextStyle(
                                    fontSize: 14,
                                    color: Colors.green.shade700,
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderSide: const BorderSide(
                                        color: Colors.grey, width: 2.0),
                                    borderRadius: BorderRadius.circular(8.0),
                                  ),
                                  hintText: "Enter you Remarks",
                                  border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(8.0),
                                      borderSide:
                                          const BorderSide(color: Colors.grey)),
                                  helperStyle: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 16,
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(
                              height: 20,
                            ),
                            widget.orderByUsertype.ispartial == '0'
                                ? Column(children: [
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: SizedBox(
                                        height: 52,
                                        width: double.infinity,
                                        child: ElevatedButton(
                                          style: ElevatedButton.styleFrom(
                                            backgroundColor:
                                                const Color(0xff4a4a4a),
                                          ),
                                          onPressed: _openImagePicker,
                                          child: const Text('Upload An Image'),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      alignment: Alignment.center,
                                      width: double.infinity,
                                      height: 100,
                                      decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(20)),
                                      child: _image != null
                                          ? Image.file(_image!,
                                              fit: BoxFit.contain)
                                          : const Text(
                                              'Please select an image'),
                                    ),
                                  ])
                                : Container(),
                            const SizedBox(
                              height: 40,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                _selectedValue == 0
                                    ? SizedBox(
                                        height: 40,
                                        width: 100,
                                        child: ElevatedButton(
                                            style: ElevatedButton.styleFrom(
                                                backgroundColor:
                                                    const Color(0xff4a4a4a)),
                                            onPressed: _selectedValue == 1 ||
                                                    widget.orderByUsertype
                                                            .ispartial ==
                                                        '0'
                                                ? () {
                                                    if (_formKey.currentState!
                                                        .validate()) {
                                                      updateOrder();
                                                    }
                                                  }
                                                : null,
                                            child: const Text(
                                              'UpDate',
                                              style: TextStyle(
                                                  fontSize: 14,
                                                  fontWeight: FontWeight.bold),
                                            )),
                                      )
                                    : widget.orderByUsertype.ispartial == "0"
                                        ? SizedBox(
                                            height: 40,
                                            width: 100,
                                            child: ElevatedButton(
                                              style: ElevatedButton.styleFrom(
                                                  backgroundColor:
                                                      const Color(0xff4a4a4a)),
                                              onPressed: () {
                                                if (_formKey.currentState!
                                                    .validate()) {
                                                  updateOrder();
                                                  updatePartial(widget
                                                      .orderByUsertype.id!);
                                                }
                                              },
                                              child: const Text(
                                                'Partial',
                                                style: TextStyle(
                                                    fontSize: 15,
                                                    fontWeight:
                                                        FontWeight.bold),
                                              ),
                                            ),
                                          )
                                        : SizedBox(
                                            height: 40,
                                            width: 100,
                                            child: ElevatedButton(
                                                style: ElevatedButton.styleFrom(
                                                    backgroundColor:
                                                        const Color(
                                                            0xff4a4a4a)),
                                                onPressed: () {
                                                  if (_formKey.currentState!
                                                      .validate()) {
                                                    updatePartial(widget
                                                        .orderByUsertype.id!);
                                                    updateRemarks(widget
                                                        .orderByUsertype.id!);
                                                  }
                                                },
                                                child: const Text(
                                                  'Partially',
                                                  style: TextStyle(
                                                      fontSize: 14,
                                                      fontWeight:
                                                          FontWeight.bold),
                                                )),
                                          ),
                                widget.orderByUsertype.ispartial == '1'
                                    ? SizedBox(
                                        height: 40,
                                        width: 100,
                                        child: ElevatedButton(
                                            style: ElevatedButton.styleFrom(
                                                backgroundColor:
                                                    const Color(0xff4a4a4a)),
                                            onPressed: _selectedValue == 0
                                                ? () {
                                                    if (_formKey.currentState!
                                                        .validate()) {
                                                      updatePartial(widget
                                                          .orderByUsertype.id!);
                                                      updateRemarks(widget
                                                          .orderByUsertype.id!);
                                                    }
                                                  }
                                                : null,
                                            child: const Text(
                                              'Complete',
                                              style: TextStyle(
                                                  fontSize: 14,
                                                  fontWeight: FontWeight.bold),
                                            )),
                                      )
                                    : Container(),
                                widget.orderByUsertype.orderStatus == "Pending"
                                    ? SizedBox(
                                        height: 40,
                                        width: 100,
                                        child: ElevatedButton(
                                          style: ElevatedButton.styleFrom(
                                              backgroundColor:
                                                  const Color(0xff4a4a4a)),
                                          onPressed: () {
                                            cancelMethod();
                                          },
                                          child: const Text(
                                            'Cancel',
                                            style: TextStyle(
                                                fontSize: 15,
                                                fontWeight: FontWeight.bold),
                                          ),
                                        ),
                                      )
                                    : Container(),
                              ],
                            )
                          ],
                        ),
                      ),
                    )
                  : Container(),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> cancelMethod() async {
    try {
      PopupLoader.show();
      String token = Hive.box('box').get('token');
      String url = '${baseURL}api/v1/agent_update_order';
      Map<String, String> myHeader = {
        "Accept": "application/json",
        "Authorization": 'Bearer $token'
      };
      var response = await http.post(
        Uri.parse(url),
        headers: myHeader,
        body: {
          'order_id': widget.orderByUsertype.id,
          'cancel': '1',
          'agent_remarks': remarkController.text.toString(),
        },
      );
      if (response.statusCode == 200) {
        Fluttertoast.showToast(
            msg: "Order Cancel Successfully",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.green,
            textColor: Colors.white,
            fontSize: 16.0);
        PopupLoader.hide();
        Get.offAll(() => const AgentHome());
      } else {
        Fluttertoast.showToast(
            msg: "Cancel failed",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.TOP,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0);
        PopupLoader.hide();
        Get.offAll(() => const AgentHome());
      }
    } catch (e) {
      PopupLoader.hide();
    }
  }

  void updatePartial(String id) async {
    try {
      String token = Hive.box('box').get('token');

      String url = '${baseURL}api/v1/agent_update_is_partial';
      PopupLoader.show();

      final response = await http.post(Uri.parse(url), body: {
        "order_id": id.toString(),
        "is_partial": _selectedValue.toString(),
      }, headers: {
        "Accept": "application/json",
        "Authorization": 'Bearer $token'
      });
      if (response.statusCode == 200) {
        Fluttertoast.showToast(
            msg: "Partial Updated Successfully",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.green,
            textColor: Colors.white,
            fontSize: 16.0);
        PopupLoader.hide();
        Get.back();
      } else {
        Fluttertoast.showToast(
            msg: "Updation failed",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.TOP,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0);
        PopupLoader.hide();
        Get.back();
      }
    } catch (e) {
      PopupLoader.hide();
    }
  }

  void updateRemarks(String id) async {
    try {
      String token = Hive.box('box').get('token');
      String url = '${baseURL}api/v1/agent_update_order_remarks';
      PopupLoader.show();
      final response = await http.post(Uri.parse(url), body: {
        "order_id": id.toString(),
        "agent_remarks": remarkController.text.toString(),
      }, headers: {
        "Accept": "application/json",
        "Authorization": 'Bearer $token'
      });
      if (response.statusCode == 200) {
        Fluttertoast.showToast(
            msg: "Remarks Updated Successfully",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.green,
            textColor: Colors.white,
            fontSize: 16.0);
        PopupLoader.hide();
        Get.back();
      } else {
        Fluttertoast.showToast(
            msg: "Updation failed",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.TOP,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0);
        PopupLoader.hide();
        Get.back();
      }
    } catch (e) {
      PopupLoader.hide();
    }
  }

  Future<void> updateOrder() async {
    print("out from try........");
    try {
      print("trying...........");
      PopupLoader.show();
      String token = Hive.box('box').get('token');
      String url = '${baseURL}api/v1/agent_update_order';
      Map<String, String> myHeader = {
        "Content-Type": "application/json",
        "Authorization": 'Bearer $token'
      };
      var request = http.MultipartRequest('Post', Uri.parse(url));
      request.fields.addAll({
        'order_id': widget.orderByUsertype.id!,
        'transection_id': _transectionIdController.text.toString(),
        'agent_remarks': remarkController.text.toString(),
      });
      request.files.add(await http.MultipartFile.fromPath(
          'agent_evidence_image', _image!.path));
      request.headers.addAll(myHeader);
      http.StreamedResponse response = await request.send();
      if (response.statusCode == 200) {
        Fluttertoast.showToast(
            msg: "Order update Successfully",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.green,
            textColor: Colors.white,
            fontSize: 16.0);
        PopupLoader.hide();
        Get.offAll(() => const AgentHome());
      } else {
        Fluttertoast.showToast(
            msg: "Update failed",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.TOP,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0);
        PopupLoader.hide();
        Get.offAll(() => const AgentHome());
      }
    } catch (e) {
      PopupLoader.hide();
    }
  }
}

class CustomTextFeild extends StatelessWidget {
  TextEditingController controller;
  String hint, fieldName;
  CustomTextFeild(
      {Key? key,
      required this.controller,
      required this.hint,
      required this.fieldName})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0).copyWith(bottom: 0),
      child: TextFormField(
        controller: controller,
        decoration: InputDecoration(
          fillColor: Colors.white,
          filled: true,
          hintStyle: TextStyle(
            fontSize: 14,
            color: Colors.green.shade700,
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: const BorderSide(color: Colors.grey, width: 2.0),
            borderRadius: BorderRadius.circular(8.0),
          ),
          hintText: hint,
          border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8.0),
              borderSide: const BorderSide(color: Colors.grey)),
          helperStyle: const TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 16,
          ),
        ),
        validator: (value) {
          if (value == null || value.isEmpty) {
            return "$fieldName  Required";
          }

          return null;
        },
      ),
    );
  }
}

class ResuableRow extends StatelessWidget {
  final String value, title;
  final Color? color;
  const ResuableRow({
    Key? key,
    required this.title,
    required this.value,
    this.color = Colors.black,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(7),
      child: Row(
        children: [
          Text(
            title,
            style: const TextStyle(
                fontSize: 16, color: Colors.black, fontWeight: FontWeight.bold),
          ),
          const Spacer(),
          Text(
            value,
            style: TextStyle(
                fontSize: 16, color: color!, fontWeight: FontWeight.bold),
          )
        ],
      ),
    );
  }
}
