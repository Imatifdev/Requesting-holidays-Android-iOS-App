// ignore_for_file: prefer_const_constructors, file_names, depend_on_referenced_packages

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:velocity_x/velocity_x.dart';

import 'package:transactionsapp/screens/agentwalletorder.dart';

import '../utils/theme.dart';
import '../widgets/custombutton.dart';
import '../widgets/customtext.dart';

class BankConfirmation extends StatefulWidget {
  const BankConfirmation({super.key});

  @override
  State<BankConfirmation> createState() => _BankConfirmationState();
}

class _BankConfirmationState extends State<BankConfirmation> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        // ignore: prefer_const_literals_to_create_immutables
        children: [
          const SizedBox(
            height: 50,
          ),
          const CustomText(
              TextValue: "Bank Order Transfer",
              fontweight: FontWeight.bold,
              TextColor: Colors.black,
              fontsize: 40),
          const Divider(
            color: Colors.black,
            thickness: 3,
            height: 6,
          ),
          const SizedBox(
            height: 20,
          ),
          const CustomText(
              TextValue: "User Name",
              fontweight: FontWeight.bold,
              TextColor: Colors.black,
              fontsize: 24),
          const CustomText(
              TextValue: "Ahmed Raza",
              fontweight: FontWeight.normal,
              TextColor: Colors.black,
              fontsize: 18),
          const Divider(),
          Image(
              height: 250,
              width: 200,
              image: AssetImage("assets/images/card.jpg")),
          const Divider(),
          const CustomText(
              TextValue: "Amount to be Transfer in Wallet",
              fontweight: FontWeight.bold,
              TextColor: Colors.black,
              fontsize: 24),
          const Text(
            "54000",
            style: TextStyle(fontSize: 20),
          ),
          const Divider(),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CustomBtn(
                  height: 50,
                  width: 150,
                  radius: 20,
                  btncol: AppTheme.darkbg,
                  btntxtcol: Colors.white,
                  btntxt: "Next ",
                  btntextsize: 20,
                  onTap: () => Get.to(() => WalletOrder()),
                  fontw: FontWeight.bold),
            ],
          )
        ],
      ).p(30),
    );
  }
}
