// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables, non_constant_identifier_names, unused_import, depend_on_referenced_packages, avoid_print

import 'dart:async';
import 'dart:convert';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:hive/hive.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:shimmer/shimmer.dart';
import 'package:transactionsapp/models/home_model.dart';
import 'package:transactionsapp/screens/user_details_screen.dart';
import 'package:transactionsapp/utils/pdf_invoice.dart';
import 'package:transactionsapp/utils/pdf_openfile.dart';
import 'package:transactionsapp/widgets/complete_user_invoice_list.dart';
import 'package:velocity_x/velocity_x.dart';

import 'package:transactionsapp/models/current_balance_model.dart';
import 'package:transactionsapp/models/myorder_model.dart';
import 'package:transactionsapp/networks/apicall.dart';
import 'package:transactionsapp/screens/banktransfer.dart';
import 'package:transactionsapp/screens/cureencychange.dart';
import 'package:transactionsapp/screens/loadtransfer.dart';
import 'package:transactionsapp/screens/wallettransfer.dart';
import 'package:transactionsapp/utils/theme.dart';
import 'package:transactionsapp/widgets/customtext.dart';

import '../Auth__Screens/agent_login.dart';
import '../controller/getbalance_controller.dart';
import '../models/currencymodel.dart';
import '../utils/loader.dart';

class UserOrder extends StatefulWidget {
  const UserOrder({super.key});

  @override
  State<UserOrder> createState() => _UserOrderState();
}

// ignore: constant_identifier_names
String? SelectTransfer;
String finalDate = '';
String? name, email, userType;

GetBalanceController getBalanceController = Get.put(GetBalanceController());

class _UserOrderState extends State<UserOrder> {

  void getCurrentDate() {
    DateTime now = DateTime.now();
    DateFormat formatter = DateFormat('dd-MM-yyyy');
    String formattedDate = formatter.format(now);

    setState(() {
      finalDate = formattedDate;
    });
  }

  MyOrderModel? orderModel;

  StreamController<MyOrderModel> streamController1 = StreamController();
  StreamController<HomeModel> streamController2 = StreamController();
  Timer? _timer;
  @override
  void initState() {
    name = Hive.box('box').get('name');
    email = Hive.box('box').get('email');
    userType = Hive.box('box').get('userType');
    super.initState();
    getCurrentBalance();
    getMyOrder();
    _timer = Timer.periodic(const Duration(seconds: 6), (timer) {
      getCurrentBalance();
      getMyOrder();
    });
  }

  @override
  void dispose() {
    super.dispose();

    _timer?.cancel();
  }
  getMyOrder() async {
    try {
      var token = Hive.box('box').get('token');

      String url = '${baseURL}api/v1/get_my_order';
      final response = await http.get(
        Uri.parse(url),
        headers: {
          "Accept": "application/json",
          "Authorization": 'Bearer $token'
        },
      );

      if (response.statusCode == 200) {
        var jsonResponse = jsonDecode(response.body);
        print("user completed order response is.......$jsonResponse");
        orderModel = MyOrderModel.fromJson(jsonResponse);
        streamController1.sink.add(orderModel!);
        print(jsonResponse);
      } else {}
    } catch (e) {
      if (kDebugMode) {
        print(e.toString());
      }
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: MediaQuery.of(context).size.width,
            decoration: BoxDecoration(
              // color: Color(0xff1f1f1f),
              gradient: LinearGradient(
                begin: Alignment.topRight,
                end: Alignment.bottomLeft,
                colors: [
                  AppTheme.profilecardgrad1,
                  AppTheme.profilecardgrad2,
                ],
              ),

              borderRadius: BorderRadius.only(
                bottomRight: Radius.circular(30.0),
                bottomLeft: Radius.circular(30.0),
              ),
            ),
            height: 290,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                //
                Image(
                  height: 100,
                  width: 130,
                  image: AssetImage("assets/images/apptit.png"),
                ),
                Card(
                  elevation: 10,
                  shadowColor: AppTheme.buttonbackground,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20)),
                  child: Container(
                    height: 160,
                    width: 200,
                    decoration: BoxDecoration(
                        color: Color.fromARGB(154, 247, 241, 241),
                        borderRadius: BorderRadius.circular(20)),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            CustomText(
                                TextValue: name ?? '',
                                fontweight: FontWeight.bold,
                                TextColor: AppTheme.kBlack,
                                fontsize: 14),
                            SizedBox(
                              width: 05,
                            ),
                            Image.asset(
                              "assets/images/cardlogo.png",
                              height: 30,
                              width: 30,
                            )
                          ],
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Text(email.toString(),
                            style: TextStyle(
                                color: AppTheme.kBlack, fontSize: 12)),

                        // Text(userType.toString()),

                        SizedBox(
                          height: 10,
                        ),
                        CustomText(
                            TextValue: "Your Current Balance is: ",
                            fontweight: FontWeight.bold,
                            TextColor: AppTheme.kBlack,
                            fontsize: 12),

                        SizedBox(
                          height: 10,
                        ),
                        StreamBuilder<HomeModel>(
                          stream: streamController2.stream,
                          builder: (context, snapshot) {
                            if (snapshot.hasData) {
                              switch (snapshot.connectionState) {
                                case ConnectionState.waiting:
                                  return Center(
                                    child: CircularProgressIndicator(
                                      color: Colors.white,
                                    ),
                                  );

                                default:
                                  if (snapshot.hasError) {
                                    return const Center(
                                      child: Text('data'),
                                    );
                                  } else {
                                    HomeModel currentBalance =
                                    snapshot.data as HomeModel;
                                    return CustomText(
                                        TextValue:
                                        "SAR : ${currentBalance.data!.balance?.convertedBalanceAmount ?? '0.01'}",
                                        fontweight: FontWeight.bold,
                                        TextColor: AppTheme.kBlack,
                                        fontsize: 18)
                                        .pOnly();
                                  }
                              }
                            }
                            return Center(
                              child: CircularProgressIndicator(
                                color: Colors.white,
                              ),
                            );
                          },
                        ),
                      ],
                    ).p(15),
                  ),
                ).pOnly(left: 20),

              ],
            ).p(10),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0).copyWith(right: 20),
            child: Row(
              children: [
                CustomText(
                    TextValue: "All Orders",
                    fontweight: FontWeight.bold,
                    TextColor: Colors.black,
                    fontsize: 24),
                Expanded(
                  child: InkWell(
                    onTap: () {
                      Get.to(() => CompleteInvoiceScreen());
                    },
                    child: Align(
                      alignment: Alignment.topRight,
                      child: ElevatedButton.icon(
                        icon: Icon(Icons.download),
                        style: ElevatedButton.styleFrom(
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(
                                23,
                              ),
                            ),
                            backgroundColor: Color(0xff4a4a4a)),
                        onPressed: () async {
                          List<MyOrderList> completedList = [];
                          double totalAmount = 0.0;
                          double totalInSAR = 0.0;
                          completedList = orderModel!.data!
                              .where((element) =>
                                  element.orderStatus == 'Completed')
                              .toList();
                          for (int i = 0; i < completedList.length; i++) {
                            totalAmount +=
                                double.parse(completedList[i].amount!);
                            totalInSAR +=
                                double.parse(completedList[i].amountAfterConvert!);
                          }
                          final pdf = await PdfInvoice.generateFile(
                              orderModel: orderModel!,
                              istypeAgent: false,
                              totalAmount: totalAmount,
                            totalInSAR: totalInSAR,
                          );
                          PdfApi.openFile(pdf!);
                        },
                        label: Text('Download Statement'),
                      ),
                    ),
                  ),
                )
              ],
            ),
          ),
          StreamBuilder<MyOrderModel>(
            stream: streamController1.stream,
            builder: (context, snapshot) {
              if (snapshot.hasData) {
                switch (snapshot.connectionState) {
                  case ConnectionState.waiting:
                    return ListView.builder(
                      itemCount: 4,
                      itemBuilder: (context, index) {
                        return Shimmer.fromColors(
                          baseColor: Colors.grey.shade700,
                          highlightColor: Colors.grey.shade100,
                          enabled: true,
                          child: Column(
                            children: [
                              ListTile(
                                leading: Container(
                                  height: 50,
                                  width: 50,
                                  color: Colors.white,
                                ),
                                title: Container(
                                  width: 100,
                                  height: 8.0,
                                  color: Colors.white,
                                ),
                                subtitle: Container(
                                  width: double.infinity,
                                  height: 8.0,
                                  color: Colors.white,
                                ),
                              ),
                            ],
                          ),
                        );
                      },
                    );

                  default:
                    if (snapshot.hasError) {
                      return const Center(
                        child: Text('data'),
                      );
                    } else {
                      MyOrderModel orderModel = snapshot.data as MyOrderModel;

                      if (orderModel.data!.isEmpty) {
                        return const Center(
                          child: Text('Empty List'),
                        );
                      }
                      return Expanded(
                        child: ListView.builder(
                          padding: EdgeInsets.zero,
                          itemCount: orderModel.data!.length,
                          itemBuilder: (context, index) {
                            var myOrderList = orderModel.data![index];

                            return InkWell(
                              onTap: () {
                                MyOrderList dataDetails = myOrderList;
                                Get.to(
                                  () => UserDetailsScreen(
                                      orderByUsertype: dataDetails),
                                );
                              },
                              child: Card(
                                shadowColor:Color.fromARGB(255, 14, 13, 13),
                                color:myOrderList.orderStatus =='cancelled'?Colors.lime.shade200: Colors.grey.shade200,
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(20)),
                                child: Padding(
                                  padding: const EdgeInsets.all(3.0),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      SizedBox(height: 5,),
                                      Center(
                                        child: Text(
                                          myOrderList.orderType == "Created By Admin"
                                              ? myOrderList.userRemarks ?? ''
                                              : myOrderList.agentRemarks ?? '',
                                          style: TextStyle(fontSize: 16, fontWeight: FontWeight.normal),
                                        ),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.all(8.0)
                                            .copyWith(bottom: 0),
                                        child: Row(
                                          children: [
                                            Text(
                                              'Order Id',
                                              style: TextStyle(
                                                  fontSize: 16,
                                                  color: AppTheme.kBlack,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                            Spacer(),
                                            Text(
                                              myOrderList.id.toString(),
                                              style: TextStyle(
                                                  fontSize: 16,
                                                  color: AppTheme.kBlack,
                                                  fontWeight: FontWeight.bold),
                                            )
                                          ],
                                        ),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.all(8.0)
                                            .copyWith(bottom: 0),
                                        child: Row(
                                          children: [
                                            Text(
                                              'Account Num',
                                              style: TextStyle(
                                                  fontSize: 16,
                                                  color: AppTheme.kBlack,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                            Spacer(),
                                            Text(
                                              myOrderList.phoneNumber
                                                  .toString(),
                                              style: TextStyle(
                                                  fontSize: 16,
                                                  color: AppTheme.kBlack,
                                                  fontWeight: FontWeight.bold),
                                            )
                                          ],
                                        ),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.all(8.0)
                                            .copyWith(bottom: 0),
                                        child: Row(
                                          children: [
                                            Text(
                                              'Order Type',
                                              style: TextStyle(
                                                  fontSize: 16,
                                                  color: AppTheme.kBlack,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                            Spacer(),
                                            Text(
                                              myOrderList.orderType.toString(),
                                              style: TextStyle(
                                                  fontSize: 16,
                                                  color: AppTheme.kBlack,
                                                  fontWeight: FontWeight.bold),
                                            )
                                          ],
                                        ),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.all(8.0)
                                            .copyWith(top: 0, bottom: 0),
                                        child: Row(
                                          children: [
                                            Text(
                                              'Amount ',
                                              style: TextStyle(
                                                  fontSize: 15,
                                                  color: AppTheme.kBlack,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                            Spacer(),
                                            myOrderList.orderType =="Created By Admin"?Text(
                                              'SAR: ${addMethod(myOrderList.amountAfterConvert.toString(), myOrderList.tax.toString()).toString()}',
                                              style: TextStyle(
                                                  fontSize: 15,
                                                  color: AppTheme.kBlack,
                                                  fontWeight: FontWeight.bold),
                                            ):
                                            myOrderList.orderNature =="Next Day"?Text(myOrderList.amount.toString(),
                                              style: TextStyle(
                                                  fontSize: 15,
                                                  color: AppTheme.kBlack,
                                                  fontWeight: FontWeight.bold),):
                                            Text(
                                              'PKR: ${addMethod(myOrderList.amount.toString(), myOrderList.tax.toString()).toString()}',
                                              style: TextStyle(
                                                  fontSize: 15,
                                                  color: AppTheme.kBlack,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.all(8.0)
                                            .copyWith(top: 0, bottom: 1),
                                        child: Row(
                                          children: [
                                            Text(
                                              'Order Status',
                                              style: TextStyle(
                                                  fontSize: 15,
                                                  color: AppTheme.kBlack,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                            Spacer(),
                                            Text(
                                              myOrderList.orderStatus
                                                  .toString(),
                                              style: TextStyle(
                                                  fontSize: 15,
                                                  color: myOrderList
                                                              .orderStatus ==
                                                          'Pending'
                                                      ? Colors.blueAccent
                                                      : myOrderList
                                                                  .orderStatus ==
                                                              'Completed'
                                                          ? Colors.green
                                                          : Colors.red,
                                                  fontWeight: FontWeight.bold),
                                            )
                                          ],
                                        ),
                                      ),
                                      Align(
                                        alignment: Alignment.topRight,
                                        child: ElevatedButton(

                                          onPressed:
                                          myOrderList.orderStatus == 'Pending' && myOrderList.request_for_cancel =="0"?
                                              () {
                                            cancelOrder(myOrderList.id.toString());
                                          }
                                          :null,
                                          style: ElevatedButton.styleFrom(
                                            padding: EdgeInsets.symmetric(vertical:6, horizontal:6),
                                            shape: RoundedRectangleBorder(
                                              borderRadius: BorderRadius.circular(8),
                                            ),
                                            backgroundColor: Color(0xffEA6F82)
                                          ),
                                          child:myOrderList.request_for_cancel =='1'?Text("Request sent",style: TextStyle(color: Colors.deepOrange),):Text('Cancel Order',style: TextStyle(
                                            fontSize: 12
                                          ),),
                                        ),
                                      )
                                    ],
                                  ).p(10),
                                ),
                              ),
                            );
                          },
                          shrinkWrap: true,
                          physics: BouncingScrollPhysics(),
                          scrollDirection: Axis.vertical,
                        ).pSymmetric(h: 20),
                      );
                    }
                }
              }
              return Center(
                child: CircularProgressIndicator.adaptive(),
              );
            },
          ),
          //CurrencyCon()
        ],
      ),
    );
  }

  getCurrentBalance() async {
    String token = Hive.box('box').get('token');
    // if (kDebugMode) {
    //   print(token);
    // }
    // if (kDebugMode) {
    //   print('above api call');
    // }
    String url = '${baseURL}api/v1/get_user_balance';

    final response = await http.get(Uri.parse(url), headers: {
      "Accept": "application/json",
      "Authorization": 'Bearer $token'
    });
    if (response.statusCode == 200) {
      var data = jsonDecode(response.body);
      HomeModel hm=HomeModel.fromJson(data);

      print("home model  ${hm.data?.balance?.balanceAmount}");
      String? checkStatus=hm.data?.userStatus?.status.toString();
      streamController2.sink.add(hm);
      var data2=data["user_status"];

      };
    }
  }

  addMethod(String amount, String tax) {
    // if (kDebugMode) {
    //   print('amout.................... : $amount');
    // }
    // print("tax $tax");

    double value = double.parse(amount) + double.parse(tax);
    // print("value : $value");
    return value;
  }

  void cancelOrder(String id) async {
    try {
      String token = Hive.box('box').get('token');
      String url = '${baseURL}api/v1/request_for_cancel_order';
      PopupLoader.show();


      final response = await http.post(Uri.parse(url), body: {
        "order_id":id
      }, headers: {
        "Accept": "application/json",
        "Authorization": 'Bearer $token'
      });
      if (response.statusCode == 200) {
        Fluttertoast.showToast(
            msg: "Requested Successfully",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.green,
            textColor: Colors.white,
            fontSize: 16.0);
        PopupLoader.hide();
      } else {
        Fluttertoast.showToast(
            msg: "Requested failed,may be agent full the order",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.TOP,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0);
        PopupLoader.hide();
        Get.back();
      }
    } catch (e) {
      PopupLoader.hide();
      if (kDebugMode) {
      }
    }
  }

