// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables, non_constant_identifier_names, depend_on_referenced_packages, file_names

import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:hive/hive.dart';
import 'package:transactionsapp/Auth__Screens/homeauth.dart';
import 'package:transactionsapp/controller/getbalance_controller.dart';
import 'package:transactionsapp/models/current_balance_model.dart';
import 'package:transactionsapp/models/home_model.dart';
import 'package:transactionsapp/screens/banktransfer.dart';
import 'package:transactionsapp/screens/loadtransfer.dart';
import 'package:transactionsapp/screens/wallettransfer.dart';
import 'package:transactionsapp/utils/theme.dart';
import 'package:transactionsapp/widgets/customtext.dart';
import 'package:velocity_x/velocity_x.dart';
import 'package:http/http.dart' as http;
import '../networks/apicall.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

// ignore: constant_identifier_names
String? SelectTransfer; //no radio button will be selected

class _HomePageState extends State<HomePage> {
  String? name, email, userType;

  String? bankRate,loadRate,walletRate,immediateRate;
  bool loadTransfer=true,bankTransfer=true,walletTransfer=true;
  // StreamController<CurrentBalance> streamController1 = StreamController();
  StreamController<HomeModel> streamController1 = StreamController();
  Timer? _timer;
  @override
  void initState() {
    super.initState();
    getCurrentBalance();
    getRateUiStatus();
    name = Hive.box('box').get('name');
    email = Hive.box('box').get('email');
    userType = Hive.box('box').get('userType');
    _timer = Timer.periodic(const Duration(seconds: 3), (timer) {
      getCurrentBalance();
      getRateUiStatus();

    });
  }

  @override
  void dispose() {
    super.dispose();
    _timer?.cancel();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(
                // color: Color(0xff1f1f1f),
                gradient: LinearGradient(
                  begin: Alignment.topRight,
                  end: Alignment.bottomLeft,
                  colors: [
                    AppTheme.profilecardgrad1,
                    AppTheme.profilecardgrad2,
                  ],
                ),

                borderRadius: BorderRadius.only(
                  bottomRight: Radius.circular(30.0),
                  bottomLeft: Radius.circular(30.0),
                ),
              ),
              height: 290,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  //
                  Image(
                    height: 100,
                    width: 130,
                    image: AssetImage("assets/images/apptit.png"),
                  ),
                  Card(
                    elevation: 10,
                    shadowColor: AppTheme.buttonbackground,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20)),
                    child: Container(
                      height: 160,
                      width: 200,
                      decoration: BoxDecoration(
                          color: Color.fromARGB(154, 247, 241, 241),
                          borderRadius: BorderRadius.circular(20)),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              CustomText(
                                  TextValue: name ?? '',
                                  fontweight: FontWeight.bold,
                                  TextColor: AppTheme.kBlack,
                                  fontsize: 14),
                              SizedBox(
                                width: 05,
                              ),
                              Image.asset(
                                "assets/images/cardlogo.png",
                                height: 30,
                                width: 30,
                              )
                            ],
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Text(email.toString(),
                              style: TextStyle(
                                  color: AppTheme.kBlack, fontSize: 12)),

                          // Text(userType.toString()),

                          SizedBox(
                            height: 10,
                          ),
                          CustomText(
                              TextValue: "Your Current Balance is: ",
                              fontweight: FontWeight.bold,
                              TextColor: AppTheme.kBlack,
                              fontsize: 12),

                          SizedBox(
                            height: 10,
                          ),
                          StreamBuilder<HomeModel>(
                            stream: streamController1.stream,
                            builder: (context, snapshot) {
                              if (snapshot.hasData) {
                                switch (snapshot.connectionState) {
                                  case ConnectionState.waiting:
                                    return Center(
                                      child: CircularProgressIndicator(
                                        color: Colors.white,
                                      ),
                                    );

                                  default:
                                    if (snapshot.hasError) {
                                      return const Center(
                                        child: Text('data'),
                                      );
                                    } else {
                                      HomeModel currentBalance =
                                          snapshot.data as HomeModel;
                                      return CustomText(
                                              TextValue:
                                                  "SAR : ${currentBalance.data!.balance?.convertedBalanceAmount ?? '0.01'}",
                                              fontweight: FontWeight.bold,
                                              TextColor: AppTheme.kBlack,
                                              fontsize: 18)
                                          .pOnly();
                                    }
                                }
                              }
                              return Center(
                                child: CircularProgressIndicator(
                                  color: Colors.white,
                                ),
                              );
                            },
                          ),
                        ],
                      ).p(15),
                    ),
                  ).pOnly(left: 20),

                ],
              ).p(10),
            ),
            SizedBox(
              height: 10,
            ),
            Padding(
                padding: const EdgeInsets.only(left: 10, right: 10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      height: 40,
                      width: double.infinity,
                      decoration: BoxDecoration(
                          color: Colors.grey.shade200,
                          border: Border.all(color: Colors.grey, width: 1.5),
                          borderRadius: BorderRadius.circular(8)),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(left: 10),
                            child: Text(
                              "Wallet Rate",
                              style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w500),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(right: 10),
                            child:walletRate != null?Text(
                              "1 SAR = $walletRate",
                              style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w500),
                            ):Text("Not Assigned Yet",style: TextStyle(
                              fontSize: 16,fontWeight: FontWeight.w500,color: Colors.black38
                            ),)
                          )
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Container(
                      height: 40,
                      width: double.infinity,
                      decoration: BoxDecoration(
                          color: Colors.grey.shade200,
                          border: Border.all(color: Colors.grey, width: 1.5),
                          borderRadius: BorderRadius.circular(8)),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(left: 10),
                            child: Text(
                              "Bank Rate",
                              style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w500),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(right: 10),
                            child:bankRate != null?Text(
                              "1 SAR = $bankRate",
                              style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w500),
                            ):Text("Not Assigned Yet",style: TextStyle(
                                fontSize: 16,fontWeight: FontWeight.w500,color: Colors.black38
                            ),)
                          )
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Container(
                      height: 40,
                      width: double.infinity,
                      decoration: BoxDecoration(
                          color: Colors.grey.shade200,
                          border: Border.all(color: Colors.grey, width: 1.5),
                          borderRadius: BorderRadius.circular(8)),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(left: 10),
                            child: Text(
                              "Immediate Rate",
                              style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w500),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(right: 10),
                            child:immediateRate != null? Text(
                              "1 SAR = $immediateRate",
                              style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w500),
                            ):Text("Not Assigned Yet",style: TextStyle(
                                fontSize: 16,fontWeight: FontWeight.w500,color: Colors.black38
                            ),)
                          )
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Container(
                      height: 40,
                      width: double.infinity,
                      decoration: BoxDecoration(
                          color: Colors.grey.shade200,
                          border: Border.all(color: Colors.grey, width: 1.5),
                          borderRadius: BorderRadius.circular(8)),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(left: 10),
                            child: Text(
                              "Load Rate",
                              style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w500),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(right: 10),
                            child:loadRate != null? Text(
                              "1 SAR = $loadRate",
                              style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w500),
                            ):Text("Not Assigned Yet",style: TextStyle(
                                fontSize: 16,fontWeight: FontWeight.w500,color: Colors.black38
                            ),)
                          )
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        walletTransfer?Container():
                        walletRate == null || walletRate == '0'
                            ? Container()
                            : InkWell(
                          onTap: walletRate == null || walletRate == '0.00'
                              ? () {
                            Fluttertoast.showToast(
                              msg: "Wallet Transfer Rate is 0",
                              toastLength: Toast.LENGTH_SHORT,
                              gravity: ToastGravity.TOP,
                              timeInSecForIosWeb: 1,
                              backgroundColor: Colors.red,
                              textColor: Colors.white,
                              fontSize: 16.0,
                            );
                          }
                              : () {
                            Get.to(() => WalletTransfer(walletRate));
                          },

                          child: Container(
                            height: 100,
                            width: 100,
                            decoration: BoxDecoration(
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.grey.withOpacity(0.5),
                                    spreadRadius: 2,
                                    blurRadius: 10,
                                    offset: Offset(
                                        0, 3), // changes position of shadow
                                  ),
                                ],
                                color: Colors.grey.shade200,
                                borderRadius: BorderRadius.circular(20)),
                            child: Column(
                              children: [
                                Image(
                                  height: 60,
                                  width: 60,
                                  fit: BoxFit.cover,
                                  image: AssetImage("assets/images/wallet.png"),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(top: 10),
                                  child: Text(
                                    "Wallet Transfer",
                                    style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 12,
                                        fontWeight: FontWeight.w500),
                                    textAlign: TextAlign.center,
                                  ),
                                )
                              ],
                            ),
                          ),
                        ),

                        bankTransfer?Container():
                        bankRate == null || bankRate == '0'
                            ? Container()
                            : InkWell(
                          onTap: bankRate == null || bankRate == '0.00'
                              ? () {
                            Fluttertoast.showToast(
                              msg: "Bank Transfer Rate is 0",
                              toastLength: Toast.LENGTH_SHORT,
                              gravity: ToastGravity.TOP,
                              timeInSecForIosWeb: 1,
                              backgroundColor: Colors.red,
                              textColor: Colors.white,
                              fontSize: 16.0,
                            );
                          }
                              : () {
                            Get.to(() => BankTransfer(bankRate,immediateRate));
                          },

                          child: Container(
                              height: 100,
                              width: 100,
                              decoration: BoxDecoration(
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.grey.withOpacity(0.5),
                                      spreadRadius: 2,
                                      blurRadius: 10,
                                      offset: Offset(
                                          0, 3), // changes position of shadow
                                    ),
                                  ],
                                  color: Colors.grey.shade200,
                                  borderRadius: BorderRadius.circular(20)),
                              child: Column(
                                children: [
                                  Image(
                                    height: 60,
                                    width: 60,
                                    fit: BoxFit.cover,
                                    image: AssetImage("assets/images/bank.png"),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(top: 10),
                                    child: Text(
                                      "Bank Transfer",
                                      style: TextStyle(
                                          color: Colors.black,
                                          fontSize: 12,
                                          fontWeight: FontWeight.w500),
                                      textAlign: TextAlign.center,
                                    ),
                                  )
                                ],
                              )),
                        ),
                        loadTransfer?Container():
                        loadRate == null || loadRate == '0,00'
                            ? Container()
                            : InkWell(
                          onTap: loadRate == null || loadRate == '0.00'
                              ? () {
                            Fluttertoast.showToast(
                              msg: "Load Transfer Rate is 0",
                              toastLength: Toast.LENGTH_SHORT,
                              gravity: ToastGravity.TOP,
                              timeInSecForIosWeb: 1,
                              backgroundColor: Colors.red,
                              textColor: Colors.white,
                              fontSize: 16.0,
                            );
                          }
                              : () {
                            Get.to(() => LoadTransfer(loadRate));
                          },
                          child: Container(
                              height: 100,
                              width: 100,
                              decoration: BoxDecoration(
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.grey.withOpacity(0.5),
                                      spreadRadius: 2,
                                      blurRadius: 10,
                                      offset: Offset(
                                          0, 3), // changes position of shadow
                                    ),
                                  ],
                                  color: Colors.grey.shade200,
                                  borderRadius: BorderRadius.circular(20)),
                              child: Column(
                                children: [
                                  Image(
                                    height: 60,
                                    width: 60,
                                    fit: BoxFit.cover,
                                    image: AssetImage(
                                      "assets/images/load.png",
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(top: 10),
                                    child: Text(
                                      "Load Transfer",
                                      style: TextStyle(
                                          color: Colors.black,
                                          fontSize: 12,
                                          fontWeight: FontWeight.w500),
                                      textAlign: TextAlign.center,
                                    ),
                                  )
                                ],
                              )),
                        ),
                      ],
                    )
                  ],
                )),

            //CurrencyCon()
          ],
        ),
      ),
    );
  }

  getCurrentBalance() async {
    String token = Hive.box('box').get('token');
    // if (kDebugMode) {
    //   print(token);
    // }
    // if (kDebugMode) {
    //   print('above api call');
    // }
    String url = '${baseURL}api/v1/get_user_balance';

    final response = await http.get(Uri.parse(url), headers: {
      "Accept": "application/json",
      "Authorization": 'Bearer $token'
    });

    // if (kDebugMode) {
    //   print('after api calling ${1 + 1}');
    // }
    if (response.statusCode == 200) {
      // if (kDebugMode) {
      //   print('inside status code');
      // }
      // if (kDebugMode) {
      //   print(response.body);
      // }
      var data = jsonDecode(response.body);
      // CurrentBalance currentBalance = CurrentBalance.fromJson(data);
      HomeModel hm=HomeModel.fromJson(data);
      String? checkStatus=hm.data?.userStatus?.status.toString();
      streamController1.sink.add(hm);
      var data2=data["user_status"];
      if(checkStatus=="1"){}
     else if(checkStatus=="0"){
        Fluttertoast.showToast(
            msg: "Account is de-activated",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.TOP,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0);
        Get.offAll(()=>AuthHome());
      }else if(checkStatus=="2"){
        Fluttertoast.showToast(
            msg: "Account is deleted ",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.TOP,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0);
        Get.offAll(()=>AuthHome());
      };
    }
  }



  getRateUiStatus() async {
    String token = Hive.box('box').get('token');
    // if (kDebugMode) {
    //   print(token);
    // }
    // if (kDebugMode) {
    //   print('above api call');
    // }
    // String url = '${baseURL}api/v1/get_latest_rates';
    String url = '${baseURL}api/v1/get_latest_rates';

    final response = await http.get(Uri.parse(url), headers: {
      "Accept": "application/json",
      "Authorization": 'Bearer $token'
    });

    // if (kDebugMode) {
    //   print('after api calling ${1 + 1}');
    // }
    if (response.statusCode == 200) {
      // if (kDebugMode) {
      //   print('inside status code');
      // }
      // if (kDebugMode) {
      //   print(response.statusCode.toString());
      // }



        var data = jsonDecode(response.body);
        int lenthData=data['data'].length;
        for(int i=0;i<lenthData;i++){
        if(data['data'][i]['service_type'].toString()=="Load Transfer"){
          if(data['data'][i]['active']=="1"){ loadTransfer=false;
          loadRate=data['data'][i]['rate'];}
        }
        if(data['data'][i]['service_type'].toString()=="Bank Transfer"){
          if(data['data'][i]['active']=="1") {bankTransfer=false;
          bankRate=data['data'][i]['rate'];
          immediateRate=data['data'][i]['immediate_rate'];}
        }
       if(data['data'][i]['service_type'].toString()=="Wallet Transfer"){
          if(data['data'][i]['active']=="1") {walletTransfer=false;
          walletRate=data['data'][i]['rate'];}
        }
        }

        setState(() {
      });
    }
  }
}
