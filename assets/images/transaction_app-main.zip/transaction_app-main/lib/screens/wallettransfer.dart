// ignore_for_file: prefer_const_constructors, depend_on_referenced_packages

import 'dart:convert';

import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hive/hive.dart';
import 'package:transactionsapp/networks/apicall.dart';
import 'package:transactionsapp/utils/loader.dart';
import 'package:velocity_x/velocity_x.dart';

import 'package:transactionsapp/utils/theme.dart';
import 'package:transactionsapp/widgets/custombutton.dart';
import 'package:http/http.dart' as http;
import '../widgets/customtext.dart';
import 'package:fluttertoast/fluttertoast.dart';

import 'Home.dart';
import 'mainbottom.dart';

class WalletTransfer extends StatefulWidget {
  String? walletRate;

  WalletTransfer(this.walletRate);

  @override
  State<WalletTransfer> createState() => _WalletTransferState();
}

class _WalletTransferState extends State<WalletTransfer> {
  final List<String> genderItems = [
    'Jazzcash',
    'Easypaisa',
    'Upaisa',
    'others'
  ];

  double tax = 0;
  String? selectedValue;

  // int voucherValue = 0;
  String voucher_id = 'none';

  final _formKey = GlobalKey<FormState>();
  TextEditingController numcontroller = TextEditingController();
  TextEditingController nameontroller = TextEditingController();
  TextEditingController ammountcontroller = TextEditingController();
  TextEditingController vouchercontroller = TextEditingController();
  TextEditingController remarkController = TextEditingController();
  double multiplier = 1;
  double num1=0;
  int valueMultiply=1;

  double? voucherNum=0;
  bool voucherbool=false;
  double? numberWallet;

  @override
  Widget build(BuildContext context) {
     num1 = double.parse(widget.walletRate.toString());
    // num1 = num1! + voucherValue;

    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topRight,
                  end: Alignment.bottomLeft,
                  colors: [
                    AppTheme.profilecardgrad1,
                    AppTheme.profilecardgrad2,
                  ],
                ),
                borderRadius: BorderRadius.only(
                  bottomRight: Radius.circular(30.0),
                  bottomLeft: Radius.circular(30.0),
                ),
              ),
              width: double.infinity,
              height: MediaQuery.of(context).size.height * .30,
              child: Column(
                children: const [
                  SizedBox(
                    height: 10,
                  ),
                  Image(
                    height: 100,
                    width: 130,
                    image: AssetImage("assets/images/apptit.png"),
                  ),
                  SizedBox(
                    height: 30,
                  ),
                  CustomText(
                      TextValue: "Wallet Transfer",
                      fontweight: FontWeight.bold,
                      TextColor: Colors.white,
                      fontsize: 36),
                ],
              ),
            ),
            SizedBox(
              height: 30,
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                CustomText(
                        TextValue: "Select Account",
                        fontweight: FontWeight.bold,
                        TextColor: Colors.black,
                        fontsize: 25)
                    .pOnly(left: 30),
                Form(
                  key: _formKey,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const SizedBox(height: 30),
                      DropdownButtonFormField2(
                        focusColor: Colors.white,
                        decoration: InputDecoration(
                          fillColor: Colors.white,
                          contentPadding: EdgeInsets.zero,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(20),
                          ),
                          //Add more decoration as you want here
                          //Add label If you want but add hint outside the decoration to be aligned in the button perfectly.
                        ),
                        isExpanded: true,
                        hint: const Text(
                          'Select Wallet Account',
                          style: TextStyle(
                            fontSize: 14,
                          ),
                        ),
                        icon: const Icon(
                          Icons.arrow_drop_down,
                          color: Colors.black45,
                        ),
                        iconSize: 30,
                        buttonHeight: 50,
                        buttonPadding: const EdgeInsets.only(right: 10),
                        dropdownDecoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(15),
                        ),
                        items: genderItems
                            .map((item) => DropdownMenuItem<String>(
                                  value: item,
                                  child: Text(
                                    item,
                                    style: const TextStyle(
                                        fontSize: 16,
                                        color: Colors.black,
                                        fontWeight: FontWeight.w400),
                                  ),
                                ))
                            .toList(),
                        validator: (value) {
                          if (value == null) {
                            return 'Please select account';
                          }
                          return null;
                        },
                        onChanged: (value) {
                          selectedValue = value.toString();
                        },
                        onSaved: (value) {},
                      ),
                      // SizedBox(
                      //   height: 10,
                      // ),
                      // // DropdownButtonFormField2(
                      //   focusColor: Colors.white,
                      //   decoration: InputDecoration(
                      //     fillColor: Colors.white,
                      //     contentPadding: EdgeInsets.zero,
                      //     border: OutlineInputBorder(
                      //       borderRadius: BorderRadius.circular(10),
                      //     ),
                      //     //Add more decoration as you want here
                      //     //Add label If you want but add hint outside the decoration to be aligned in the button perfectly.
                      //   ),
                      //   isExpanded: true,
                      //   hint: const Text(
                      //     'Select Bank ',
                      //     style: TextStyle(
                      //       fontSize: 14,
                      //     ),
                      //   ),
                      //   icon: const Icon(
                      //     Icons.arrow_drop_down,
                      //     color: Colors.black45,
                      //   ),
                      //   iconSize: 30,
                      //   buttonHeight: 60,
                      //   buttonPadding: const EdgeInsets.only(right: 10),
                      //   dropdownDecoration: BoxDecoration(
                      //     color: Colors.white,
                      //     borderRadius: BorderRadius.circular(15),
                      //   ),
                      //   items: bankitems
                      //       .map((item) => DropdownMenuItem<String>(
                      //             value: item,
                      //             child: Text(
                      //               item,
                      //               style: const TextStyle(
                      //                   fontSize: 16,
                      //                   color: Colors.black,
                      //                   fontWeight: FontWeight.w400),
                      //             ),
                      //           ))
                      //       .toList(),
                      //   validator: (value) {
                      //     if (value == null) {
                      //       return 'Select Bank ';
                      //     }
                      //     return null;
                      //   },
                      //   onChanged: (value) {
                      //     selectedValue = value.toString();
                      //
                      //   },
                      //   onSaved: (value) {},
                      // ),
                      SizedBox(
                        height: 10,
                      ),
                      TextFormField(
                        keyboardType: TextInputType.text,
                        textInputAction: TextInputAction.next,
                        controller: nameontroller,
                        // validator: (value) {
                        //   if (value!.isEmpty) {
                        //     return 'Please select number';
                        //   }
                        //   return null;
                        // },
                        decoration: InputDecoration(
                          counterText: "",
                          hintText: "  Enter Your Name",
                          fillColor: AppTheme.dropdowncolo,
                          //Add isDense true and zero Padding.
                          //Add Horizontal padding using buttonPadding and Vertical padding by increasing buttonHeight instead of add Padding here so that The whole TextField Button become clickable, and also the dropdown menu open under The whole TextField Button.
                          contentPadding: EdgeInsets.all(10),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(20),
                          ),
                          //Add more decoration as you want here
                          //Add label If you want but add hint outside the decoration to be aligned in the button perfectly.
                        ),
                      ),
                      SizedBox(
                        height: 15,
                      ),
                      TextFormField(
                        keyboardType: TextInputType.number,
                        maxLength: 11,
                        textInputAction: TextInputAction.next,
                        controller: numcontroller,
                        validator: (value) {
                          if (value!.length < 11) {
                            return 'Please enter a valid number';
                          }
                          return null;
                        },
                        decoration: InputDecoration(
                          counterText: "",
                          hintText: "  Enter your number",
                          fillColor: AppTheme.dropdowncolo,
                          //Add isDense true and zero Padding.
                          //Add Horizontal padding using buttonPadding and Vertical padding by increasing buttonHeight instead of add Padding here so that The whole TextField Button become clickable, and also the dropdown menu open under The whole TextField Button.
                          contentPadding: EdgeInsets.all(10),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(20),
                          ),
                          //Add more decoration as you want here
                          //Add label If you want but add hint outside the decoration to be aligned in the button perfectly.
                        ),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 7),
                        child: TextFormField(
                          keyboardType: TextInputType.number,
                          textInputAction: TextInputAction.next,
                          controller: ammountcontroller,
                          validator: (value) {
                            if (value!.isEmpty) {
                              return 'Please enter amount';
                            }
                            int amount = int.parse(value);
                            if (amount > 250000) {
                              return 'Amount should be less than or equal to 2,50,000';
                            }
                            if (amount < 1) {
                              return 'Amount should be greater than or equal to 1';
                            }
                            return null;
                          },
                          // onChanged: (String value) {
                          //   setState(() {
                          //     multiplier = value.isEmpty
                          //         ? 0
                          //         : int.parse(value) * (num1!+voucherNum!);
                          //     valueMultiply=  int.parse(value);
                          //   });
                          // },
                          maxLength: 10,
                          decoration: InputDecoration(
                            counterText: "",
                            hintText: "Enter amount in PKR",
                            fillColor: AppTheme.dropdowncolo,
                            //Add isDense true and zero Padding.
                            //Add Horizontal padding using buttonPadding and Vertical padding by increasing buttonHeight instead of add Padding here so that The whole TextField Button become clickable, and also the dropdown menu open under The whole TextField Button.
                            contentPadding: EdgeInsets.all(10),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20),
                            ),
                            //Add more decoration as you want here
                            //Add label If you want but add hint outside the decoration to be aligned in the button perfectly.
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 15,
                      ),
                      Container(
                        height: 65,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            color: Colors.grey.shade200),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            SizedBox(
                              width: MediaQuery.of(context).size.width * 0.55,
                              height: 60,
                              child: Padding(
                                padding: const EdgeInsets.only(top: 7),
                                child: TextFormField(
                                  keyboardType: TextInputType.number,
                                  textInputAction: TextInputAction.next,
                                  controller: vouchercontroller,
                                  onChanged: (String value) {},
                                  decoration: InputDecoration(
                                    counterText: "",
                                    hintText: "Enter Voucher no.",
                                    fillColor: AppTheme.dropdowncolo,
                                    //Add isDense true and zero Padding.
                                    //Add Horizontal padding using buttonPadding and Vertical padding by increasing buttonHeight instead of add Padding here so that The whole TextField Button become clickable, and also the dropdown menu open under The whole TextField Button.
                                    contentPadding: EdgeInsets.all(10),
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(20),
                                    ),
                                    //Add more decoration as you want here
                                    //Add label If you want but add hint outside the decoration to be aligned in the button perfectly.
                                  ),
                                ),
                              ),
                            ),
                            ElevatedButton(
                              child: Text("Apply"),
                              onPressed: () {
                                getVoucherValidate(
                                  vouchercontroller.text.toString().trim(),
                                );
                              },
                            ),
                          ],
                        ),
                      ),

                      Visibility(
                        visible: voucherbool,
                        child: Text("Voucher Add $voucherNum",style: TextStyle(fontWeight: FontWeight.bold,color: Colors.green),),
                      ),
                      SizedBox(
                        height: 15,
                      ),
                      TextFormField(
                        keyboardType: TextInputType.text,
                        textInputAction: TextInputAction.next,
                        controller: remarkController,
                        decoration: InputDecoration(
                          hintText: "Enter your Remarks",
                          fillColor: AppTheme.dropdowncolo,
                          //Add isDense true and zero Padding.
                          //Add Horizontal padding using buttonPadding and Vertical padding by increasing buttonHeight instead of add Padding here so that The whole TextField Button become clickable, and also the dropdown menu open under The whole TextField Button.
                          contentPadding: EdgeInsets.all(10),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(20),
                          ),
                          //Add more decoration as you want here
                          //Add label If you want but add hint outside the decoration to be aligned in the button perfectly.
                        ),
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          CustomBtn(
                              height: 40,
                              width: 120,
                              radius: 15,
                              btncol: Color(0xff4a4a4a),
                              btntxtcol: AppTheme.btntxt,
                              btntxt: "Continue",
                              btntextsize: 14,
                              onTap: () {
                                if (_formKey.currentState!.validate()) {
                                  showDialog(
                                    context: context,
                                    builder: (ctx) => AlertDialog(
                                      title: const Text("Confirmation"),
                                      content: SizedBox(
                                        height: MediaQuery.of(context).size.height *0.6,
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            const Text(
                                              "Please Verify your details",
                                              style: TextStyle(
                                                  fontSize: 17,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                            SizedBox(
                                              height: 10,
                                            ),
                                            Text(
                                              "Name",
                                              style: TextStyle(
                                                  fontSize: 14,
                                                  fontWeight: FontWeight.bold),
                                            ),

                                            Text(
                                              nameontroller.text,
                                              style: TextStyle(
                                                fontSize: 14,
                                              ),
                                            ),
                                            Divider(),
                                            Text(
                                              "Account No",
                                              style: TextStyle(
                                                  fontSize: 14,
                                                  fontWeight: FontWeight.bold),
                                            ),

                                            Text(
                                              numcontroller.text,
                                              style: TextStyle(
                                                fontSize: 14,
                                              ),
                                            ),
                                            Divider(),
                                            SizedBox(
                                              height: 5,
                                            ),
                                            Text(
                                              "Amount",
                                              style: TextStyle(
                                                  fontSize: 14,
                                                  fontWeight: FontWeight.bold),
                                            ),

                                            Text(
                                              ammountcontroller.text.trim(),
                                              style: TextStyle(
                                                fontSize: 12,
                                              ),
                                            ),
                                            Divider(),
                                            Text(
                                              "Selected Wallet  ",
                                              style: TextStyle(
                                                  fontSize: 14,
                                                  fontWeight: FontWeight.bold),
                                            ),

                                            Text(
                                              selectedValue.toString(),
                                              style: TextStyle(
                                                  fontSize: 12,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                            Divider(),
                                            Text(
                                              "Voucher  Amount  ",
                                              style: TextStyle(
                                                  fontSize: 14,
                                                  fontWeight: FontWeight.bold,color: Colors.green),
                                            ),

                                            Text(
                                              voucherNum.toString(),
                                              style: TextStyle(
                                                  fontSize: 12,
                                                  fontWeight: FontWeight.bold,color: Colors.green),
                                            ),
                                            Divider(),
                                            Text(
                                              "Total Rate  ",
                                              style: TextStyle(
                                                  fontSize: 14,
                                                  fontWeight: FontWeight.bold,color: Colors.red),
                                            ),

                                            Text(
                                              "${total()}",
                                              style: TextStyle(
                                                  fontSize: 12,
                                                  fontWeight: FontWeight.bold,color: Colors.red),
                                            ),
                                            Divider(),
                                          ],
                                        ),
                                      ),
                                      actions: <Widget>[
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceAround,
                                          children: [
                                            TextButton(
                                              onPressed: () {
                                                Navigator.of(ctx).pop();
                                              },
                                              child: Container(
                                                decoration: BoxDecoration(
                                                    color: AppTheme.darkbg,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            20)),
                                                padding:
                                                    const EdgeInsets.all(14),
                                                child: const Text(
                                                  "Edit Info",
                                                  style: TextStyle(
                                                      color: Colors.white),
                                                ),
                                              ),
                                            ),
                                            TextButton(
                                              onPressed: () {
                                                createOrder();
                                                Navigator.of(ctx).pop();
                                              },
                                              child: Container(
                                                decoration: BoxDecoration(
                                                    color: AppTheme.darkbg,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            20)),
                                                padding:
                                                    const EdgeInsets.all(14),
                                                child: const Text(
                                                  "Create Order",
                                                  style: TextStyle(
                                                      color: Colors.white),
                                                ),
                                              ),
                                            ),
                                          ],
                                        )
                                      ],
                                    ),
                                  );
                                  //createOrder();
                                }
                                // else {
                                //   showDialog(
                                //     context: context,
                                //     builder: (ctx) => AlertDialog(
                                //       title: const Text("Alert"),
                                //       content: const Text(
                                //           "Please Confirm your details"),
                                //       actions: <Widget>[
                                //         TextButton(
                                //           onPressed: () {
                                //             Navigator.of(ctx).pop();
                                //           },
                                //           child: Container(
                                //             decoration: BoxDecoration(
                                //                 color: AppTheme.darkbg,
                                //                 borderRadius:
                                //                     BorderRadius.circular(20)),
                                //             padding: const EdgeInsets.all(14),
                                //             child: const Text(
                                //               "Confirm",
                                //               style: TextStyle(
                                //                   color: Colors.white),
                                //             ),
                                //           ),
                                //         ),
                                //       ],
                                //     ),
                                //   );
                                // }
                              },
                              fontw: FontWeight.bold),
                          CustomBtn(
                              height: 40,
                              width: 120,
                              radius: 15,
                              btncol: Color(0xff4a4a4a),
                              btntxtcol: AppTheme.btntxt,
                              btntxt: "Cancel",
                              btntextsize: 14,
                              onTap: () {
                                showDialog(
                                  context: context,
                                  builder: (ctx) => AlertDialog(
                                    title: const Text("Alert"),
                                    content: const Text(
                                        "Are you sure to want cancel this order"),
                                    actions: <Widget>[
                                      TextButton(
                                        onPressed: () {
                                          Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                  builder: (context) =>
                                                      MainScreen()));
                                        },
                                        child: Container(
                                          decoration: BoxDecoration(
                                              color: AppTheme.darkbg,
                                              borderRadius:
                                                  BorderRadius.circular(20)),
                                          padding: const EdgeInsets.all(14),
                                          child: const Text(
                                            "Cancel",
                                            style:
                                                TextStyle(color: Colors.white),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                );
                              },
                              fontw: FontWeight.bold)
                        ],
                      ),
                      SizedBox(
                        height: 50,
                      )
                    ],
                  ),
                ).pSymmetric(h: 30),
              ],
            ),
          ],
        ),
      ),
    );
  }

  double total(){
    double aa=num1 + voucherNum!;
    return valueMultiply*aa;

    return multiplier! ;//+ voucherNum!;
  }

  void createOrder() async {
    try {
      String token = Hive.box('box').get('token');

      String url = '${baseURL}api/v1/create_order';
      PopupLoader.show();


      final response = await http.post(Uri.parse(url), body: {
        "order_type": "Wallet Transfer",
        "amount": ammountcontroller.text.toString(),
        "user_remarks": remarkController.text.toString(),
        "phone_number": numcontroller.text.toString(),
        "v_transfer_acc_type": selectedValue ?? "others",
        "tax": '0',
        'convert_rate': total().toString(),
        'amount_after_convert': total().toString(),
        "title": nameontroller.text.toString(),
        "voucher_id": voucher_id,
      }, headers: {
        "Accept": "application/json",
        "Authorization": 'Bearer $token'
      });
      if (response.statusCode == 200) {
        Fluttertoast.showToast(
            msg: "Order Created Successfully",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.green,
            textColor: Colors.white,
            fontSize: 16.0);
        PopupLoader.hide();

        Get.back();
      } else {
        remarkController.clear();
        Fluttertoast.showToast(
            msg: "Transaction failed, may be agent is not available",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.TOP,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0);
        PopupLoader.hide();
        Get.back();
      }
    } catch (e) {
      PopupLoader.hide();
    }
  }

  void getVoucherValidate(String voucher) async {
    try {
      String token = Hive.box('box').get('token');

      String url = '${baseURL}api/v1/get_single_voucher';
      PopupLoader.show();

      final response = await http.post(Uri.parse(url), body: {
        "voucher_no": voucher,
      }, headers: {
        "Accept": "application/json",
        "Authorization": 'Bearer $token'
      });
      var data = jsonDecode(response.body);
      if (response.statusCode == 200) {
        if(data['data']['status']=="used"){
          voucherbool=false;
          voucherNum=0;
          Fluttertoast.showToast(
              msg: "Voucher Used ",
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.BOTTOM,
              timeInSecForIosWeb: 1,
              backgroundColor: Colors.green,
              textColor: Colors.white,
              fontSize: 16.0);
          PopupLoader.hide();
        }else{
        Fluttertoast.showToast(
            msg: "Voucher Active ",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.green,
            textColor: Colors.white,
            fontSize: 16.0);
        PopupLoader.hide();
        setState(() {
        if (data['data']['status'] == 'not-used') {
          voucherNum =  double.parse(data['data']['voucher_percent']) ;
          voucher_id=data['data']['id'];
        }
        voucherbool=true;

        });
        // Get.back();
      }} else {
        remarkController.clear();
        Fluttertoast.showToast(
            msg: "Voucher Used",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.TOP,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0);
        PopupLoader.hide();
        // Get.back();
      }
    } catch (e) {
      PopupLoader.hide();
    }
  }
}
