// ignore_for_file: public_member_api_docs, sort_constructors_first, prefer_const_literals_to_create_immutables, camel_case_types
// ignore_for_file: prefer_const_constructors

import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:transactionsapp/networks/apicall.dart';
import 'package:transactionsapp/utils/loader.dart';
import 'package:transactionsapp/utils/theme.dart';
import 'package:transactionsapp/widgets/custombutton.dart';
// ignore: depend_on_referenced_packages
import 'package:velocity_x/velocity_x.dart';

import '../widgets/customtext.dart';
import 'mainbottom.dart';

class LoadTransfer extends StatefulWidget {
  String? walletRate;

  LoadTransfer(this.walletRate);

  @override
  State<LoadTransfer> createState() => _LoadTransferState();
}

class _LoadTransferState extends State<LoadTransfer> {
  final _formKey = GlobalKey<FormState>();
  TextEditingController numcontroller = TextEditingController();
  TextEditingController ammountcontroller = TextEditingController();
  TextEditingController remarkController = TextEditingController();
  TextEditingController vouchercontroller = TextEditingController();
  String? valueData;
  int voucherValue = 0;
  String voucher_id = 'none';
  String selectedNetwork = '';
  double multiplier = 1;
  double num1=0;
  int valueMultiply=1;

  double? voucherNum=0;

  bool voucherbool=false;

  @override
  Widget build(BuildContext context) {
    num1 = double.parse(widget.walletRate.toString());
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topRight,
                    end: Alignment.bottomLeft,
                    colors: [
                      AppTheme.profilecardgrad1,
                      AppTheme.profilecardgrad2,
                    ],
                  ),
                  borderRadius: BorderRadius.only(
                    bottomRight: Radius.circular(30.0),
                    bottomLeft: Radius.circular(30.0),
                  ),
                ),
                width: double.infinity,
                height: 250,
                child: Column(
                  children: [
                    SizedBox(
                      height: 20,
                    ),
                    Image(
                      height: 100,
                      width: 130,
                      image: AssetImage("assets/images/apptit.png"),
                    ),
                    SizedBox(
                      height: 50,
                    ),
                    CustomText(
                        TextValue: "Load Transfer",
                        fontweight: FontWeight.bold,
                        TextColor: Colors.white,
                        fontsize: 40),
                  ],
                )),
            SizedBox(
              height: 30,
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                CustomText(
                        TextValue: "Prepaid Mobile Account",
                        fontweight: FontWeight.bold,
                        TextColor: AppTheme.kBlack,
                        fontsize: 25)
                    .pOnly(left: 30, bottom: 20),
                CustomText(
                        TextValue: "Select a Network",
                        fontweight: FontWeight.bold,
                        TextColor: AppTheme.kBlack,
                        fontsize: 20)
                    .pOnly(left: 30, bottom: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Expanded(
                      child: InkWell(
                        onTap: () {
                          setState(() {
                            selectedNetwork = 'Jazz';
                          });
                          Fluttertoast.showToast(
                              msg: "$valueData is Selected",
                              toastLength: Toast.LENGTH_SHORT,
                              gravity: ToastGravity.BOTTOM,
                              timeInSecForIosWeb: 1,
                              backgroundColor: Colors.green,
                              textColor: Colors.white,
                              fontSize: 16.0);
                        },
                        child: selectnetwork(
                          fit: BoxFit.contain,
                          networkname: 'Jazz',
                          imageurl: 'assets/images/jazz.png',
                          isSelected: selectedNetwork == 'Jazz',
                          onTap: () {
                            setState(() {
                              selectedNetwork = 'Jazz';
                              valueData = 'Jazz';

                            });
                          },
                        ),
                      ),
                    ),
                    Expanded(
                      child: InkWell(
                        onTap: () {
                          setState(() {
                            selectedNetwork = 'Ufone';
                          });
                          Fluttertoast.showToast(
                              msg: "$valueData is Selected",
                              toastLength: Toast.LENGTH_SHORT,
                              gravity: ToastGravity.BOTTOM,
                              timeInSecForIosWeb: 1,
                              backgroundColor: Colors.green,
                              textColor: Colors.white,
                              fontSize: 16.0);
                        },
                        child: selectnetwork(
                          fit: BoxFit.cover,
                          networkname: 'Ufone',
                          imageurl: 'assets/images/u.png',
                          isSelected: selectedNetwork == 'Ufone',
                          onTap: () {
                            setState(() {
                              selectedNetwork = 'Ufone';
                              valueData = 'Ufone';
                            });
                          },

                        ),
                      ),
                    ),
                    Expanded(
                      child: InkWell(
                        onTap: () {
                          setState(() {
                            selectedNetwork = 'Zong';
                          });
                          Fluttertoast.showToast(
                              msg: "$valueData is Selected",
                              toastLength: Toast.LENGTH_SHORT,
                              gravity: ToastGravity.BOTTOM,
                              timeInSecForIosWeb: 1,
                              backgroundColor: Colors.green,
                              textColor: Colors.white,
                              fontSize: 16.0);
                        },
                        child: selectnetwork(
                          fit: BoxFit.fitHeight,
                          networkname: 'Zong',
                          imageurl: 'assets/images/zn.png',
                          isSelected: selectedNetwork == 'Zong',
                          onTap: () {
                            setState(() {
                              selectedNetwork = 'Zong';
                              valueData = 'Zong';

                            });
                          },
                        ),
                      ),
                    ),
                    Expanded(
                      child: InkWell(
                        onTap: () {
                          print("value data before...........$valueData");
                          setState(() {
                            selectedNetwork = 'Telenor';
                          });
                          Fluttertoast.showToast(
                              msg: "$valueData is Selected",
                              toastLength: Toast.LENGTH_SHORT,
                              gravity: ToastGravity.BOTTOM,
                              timeInSecForIosWeb: 1,
                              backgroundColor: Colors.green,
                              textColor: Colors.white,
                              fontSize: 16.0);
                        },
                        child: selectnetwork(
                          fit: BoxFit.cover,
                          networkname: 'Telenor',
                          imageurl: 'assets/images/tn.png',
                          isSelected: selectedNetwork == 'Telenor',
                          onTap: () {
                            setState(() {
                              selectedNetwork = 'Telenor';
                              valueData = 'Telenor';

                            });
                          },
                        ),
                      ),
                    ),
                  ],
                ).pSymmetric(h: 10),
                Form(
                  key: _formKey,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(height: 30),
                      SizedBox(
                        height: 10,
                      ),
                      CustomText(
                          TextValue: "Enter Phone Number",
                          fontweight: FontWeight.bold,
                          TextColor: Colors.black,
                          fontsize: 17),
                      SizedBox(
                        height: 10,
                      ),
                      TextFormField(
                        textInputAction: TextInputAction.next,
                        keyboardType: TextInputType.number,
                        maxLength: 11,
                        controller: numcontroller,
                        validator: (value) {
                          if (value!.length < 11) {
                            return 'Please enter a Valid Numbers';
                          }
                          return null;
                        },
                        decoration: InputDecoration(
                          counterText: "",
                          prefixIcon: Icon(
                            Icons.contact_phone,
                            size: 25,
                          ),
                          hintText: " Enter Numbers",
                          fillColor: AppTheme.dropdowncolo,
                          //Add isDense true and zero Padding.
                          //Add Horizontal padding using buttonPadding and Vertical padding by increasing buttonHeight instead of add Padding here so that The whole TextField Button become clickable, and also the dropdown menu open under The whole TextField Button.
                          contentPadding: EdgeInsets.zero,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(20),
                          ),
                          //Add more decoration as you want here
                          //Add label If you want but add hint outside the decoration to be aligned in the button perfectly.
                        ),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 7),
                        child: TextFormField(
                          keyboardType: TextInputType.number,
                          textInputAction: TextInputAction.next,
                          controller: ammountcontroller,
                          validator: (value) {
                            if (value!.isEmpty) {
                              return 'Please enter amount';
                            }
                            int amount = int.parse(value);
                            if (amount >10000) {
                              return 'Amount should be less than or equal to 10,000';
                            }
                            if (amount < 1) {
                              return 'Amount should be greater than or equal to 1';
                            }
                            return null;
                          },
                          // onChanged: (String value) {
                          //   setState(() {
                          //     multiplier = value.isEmpty
                          //         ? 0
                          //         : int.parse(value) * (num1!+voucherNum!);
                          //     valueMultiply=  int.parse(value);
                          //   });
                          // },
                          maxLength: 6,
                          decoration: InputDecoration(
                            counterText: "",
                            hintText: "Enter amount in PKR",
                            fillColor: AppTheme.dropdowncolo,
                            //Add isDense true and zero Padding.
                            //Add Horizontal padding using buttonPadding and Vertical padding by increasing buttonHeight instead of add Padding here so that The whole TextField Button become clickable, and also the dropdown menu open under The whole TextField Button.
                            contentPadding: EdgeInsets.all(10),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20),
                            ),
                            //Add more decoration as you want here
                            //Add label If you want but add hint outside the decoration to be aligned in the button perfectly.
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 15,
                      ),
                      Container(
                        height: 65,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            color: Colors.grey.shade200),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            SizedBox(
                              width: MediaQuery.of(context).size.width * 0.55,
                              height: 60,
                              child: Padding(
                                padding: const EdgeInsets.only(top: 7),
                                child: TextFormField(
                                  keyboardType: TextInputType.number,
                                  textInputAction: TextInputAction.next,
                                  controller: vouchercontroller,
                                  // validator: (value) {
                                  //   if (value!.isEmpty) {
                                  //     return 'Please enter ammount';
                                  //   }
                                  //   return null;
                                  // },
                                  onChanged: (String value) {},
                                  decoration: InputDecoration(
                                    counterText: "",
                                    hintText: "Enter Voucher",
                                    fillColor: AppTheme.dropdowncolo,
                                    //Add isDense true and zero Padding.
                                    //Add Horizontal padding using buttonPadding and Vertical padding by increasing buttonHeight instead of add Padding here so that The whole TextField Button become clickable, and also the dropdown menu open under The whole TextField Button.
                                    contentPadding: EdgeInsets.all(10),
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(20),
                                    ),
                                    //Add more decoration as you want here
                                    //Add label If you want but add hint outside the decoration to be aligned in the button perfectly.
                                  ),
                                ),
                              ),
                            ),
                            ElevatedButton(
                              child: Text("Apply"),
                              onPressed: () {
                                getVoucherValidate(
                                  vouchercontroller.text.toString().trim(),
                                );
                              },
                            ),
                          ],
                        ),
                      ),
                      SizedBox(height: 10),
                      Visibility(
                        visible: voucherbool,
                        child: Text("Voucher Add $voucherNum",style: TextStyle(fontWeight: FontWeight.bold,color: Colors.green),),
                      ),
                      SizedBox(height: 10),
                      //CurrencyCon(),
                      TextFormField(
                        textInputAction: TextInputAction.next,
                        keyboardType: TextInputType.text,
                        controller: remarkController,
                        decoration: InputDecoration(
                          prefixIcon: Icon(
                            Icons.mark_chat_read_outlined,
                            size: 25,
                          ),
                          hintText: "Enter your Remarks ",
                          fillColor: AppTheme.dropdowncolo,
                          //Add isDense true and zero Padding.
                          //Add Horizontal padding using buttonPadding and Vertical padding by increasing buttonHeight instead of add Padding here so that The whole TextField Button become clickable, and also the dropdown menu open under The whole TextField Button.
                          contentPadding: EdgeInsets.zero,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(20),
                          ),
                          //Add more decoration as you want here
                          //Add label If you want but add hint outside the decoration to be aligned in the button perfectly.
                        ),
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          CustomBtn(
                              height: 40,
                              width: 120,
                              radius: 15,
                              btncol: Color(0xff4a4a4a),
                              btntxtcol: AppTheme.btntxt,
                              btntxt: "Continue",
                              btntextsize: 16,
                              onTap: () {
                                if (_formKey.currentState!.validate()) {
                                  showDialog(
                                    context: context,
                                    builder: (ctx) => AlertDialog(
                                      title: const Text("Confirmation"),
                                      content: SizedBox(
                                        height: MediaQuery.of(context).size.height *0.6,
                                        child: Column(
                                          crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              "Account No",
                                              style: TextStyle(
                                                  fontSize: 14,
                                                  fontWeight: FontWeight.bold),
                                            ),

                                            Text(
                                              numcontroller.text,
                                              style: TextStyle(
                                                fontSize: 17,
                                              ),
                                            ),
                                            Divider(),
                                            SizedBox(
                                              height: 5,
                                            ),
                                            Text(
                                              "Amount",
                                              style: TextStyle(
                                                  fontSize: 14,
                                                  fontWeight: FontWeight.bold),
                                            ),

                                            Text(
                                              ammountcontroller.text.trim(),
                                              style: TextStyle(
                                                fontSize: 12,
                                              ),
                                            ),
                                            Divider(),
                                            Text(
                                              "Selected Network  ",
                                              style: TextStyle(
                                                  fontSize: 14,
                                                  fontWeight: FontWeight.bold),
                                            ),

                                            Text(
                                              "$valueData",
                                              style: TextStyle(
                                                  fontSize: 12,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                            Divider(),
                                            Text(
                                              "Voucher  Amount  ",
                                              style: TextStyle(
                                                  fontSize: 14,
                                                  fontWeight: FontWeight.bold,color: Colors.green),
                                            ),

                                            Text(
                                              voucherNum.toString(),
                                              style: TextStyle(
                                                  fontSize: 12,
                                                  fontWeight: FontWeight.bold,color: Colors.green),
                                            ),
                                            Divider(),

                                            Text(
                                              "Total  Rate  ",
                                              style: TextStyle(
                                                  fontSize: 14,
                                                  fontWeight: FontWeight.bold,color: Colors.red),
                                            ),

                                            Text(
                                              "${total()}",
                                              style: TextStyle(
                                                  fontSize: 12,
                                                  fontWeight: FontWeight.bold,color: Colors.red),
                                            ),
                                            Divider(),
                                          ],
                                        ),
                                      ),
                                      actions: <Widget>[
                                        Row(
                                          mainAxisAlignment:
                                          MainAxisAlignment.spaceAround,
                                          children: [
                                            TextButton(
                                              onPressed: () {
                                                Navigator.of(ctx).pop();
                                              },
                                              child: Container(
                                                decoration: BoxDecoration(
                                                    color: AppTheme.darkbg,
                                                    borderRadius:
                                                    BorderRadius.circular(
                                                        20)),
                                                padding:
                                                const EdgeInsets.all(14),
                                                child: const Text(
                                                  "Edit Info",
                                                  style: TextStyle(
                                                      color: Colors.white),
                                                ),
                                              ),
                                            ),
                                            TextButton(
                                              onPressed: () {
                                                createOrder();
                                                Navigator.of(ctx).pop();
                                              },
                                              child: Container(
                                                decoration: BoxDecoration(
                                                    color: AppTheme.darkbg,
                                                    borderRadius:
                                                    BorderRadius.circular(
                                                        20)),
                                                padding:
                                                const EdgeInsets.all(14),
                                                child: const Text(
                                                  "Create Order",
                                                  style: TextStyle(
                                                      color: Colors.white),
                                                ),
                                              ),
                                            ),
                                          ],
                                        )
                                      ],
                                    ),
                                  );
                                } else {
                                  // showDialog(
                                  //   context: context,
                                  //   builder: (ctx) => AlertDialog(
                                  //     title: const Text("Alert"),
                                  //     content: const Text(
                                  //         "Please Confirm your details"),
                                  //     actions: <Widget>[
                                  //       TextButton(
                                  //         onPressed: () {
                                  //           Navigator.of(ctx).pop();
                                  //         },
                                  //         child: Container(
                                  //           decoration: BoxDecoration(
                                  //               color: AppTheme.darkbg,
                                  //               borderRadius:
                                  //                   BorderRadius.circular(20)),
                                  //           padding: const EdgeInsets.all(14),
                                  //           child: const Text(
                                  //             "Confirm",
                                  //             style: TextStyle(
                                  //                 color: Colors.white),
                                  //           ),
                                  //         ),
                                  //       ),
                                  //     ],
                                  //   ),
                                  // );
                                }
                              },
                              fontw: FontWeight.bold),
                          CustomBtn(
                              height: 40,
                              width: 120,
                              radius: 15,
                              btncol: Color(0xff4a4a4a),
                              btntxtcol: AppTheme.btntxt,
                              btntxt: "Cancel",
                              btntextsize: 16,
                              onTap: () {
                                showDialog(
                                  context: context,
                                  builder: (ctx) => AlertDialog(
                                    title: const Text("Alert"),
                                    content: const Text(
                                        "Are you sure to want cancel this order"),
                                    actions: <Widget>[
                                      TextButton(
                                        onPressed: () {
                                          Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                  builder: (context) =>
                                                      MainScreen()));
                                          // Navigator.ge(ctx).pop();
                                        },
                                        child: Container(
                                          decoration: BoxDecoration(
                                              color: AppTheme.darkbg,
                                              borderRadius:
                                                  BorderRadius.circular(20)),
                                          padding: const EdgeInsets.all(14),
                                          child: const Text(
                                            "Cancel",
                                            style:
                                                TextStyle(color: Colors.white),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                );
                              },
                              fontw: FontWeight.bold)
                        ],
                      ),
                      SizedBox(
                        height: 50,
                      )
                    ],
                  ),
                ).pSymmetric(h: 30),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void createOrder() async {
    try {
      PopupLoader.show();

      String token = Hive.box('box').get('token');
      String url = '${baseURL}api/v1/create_order';

      String amount = ammountcontroller.text.toString();
      String num = numcontroller.text.toString();


     var bodyy=  {
        "order_type": "Load Transfer",
    "amount": amount,
    "phone_number": num,
    "user_remarks": remarkController.text.toString(),
    "m_transfer_network_type": valueData ?? 'network was not selected',
    "tax": '0',
    'convert_rate': num1.toString(),
    'amount_after_convert': total().toString(),
       "voucher_id": voucher_id,
    };
      final response = await http.post(
        Uri.parse(url),
       body:bodyy,
        headers: {
          "Accept": "application/json",
          "Authorization": 'Bearer $token'
        },
      );
      if (response.statusCode == 200) {
        PopupLoader.hide();
        Fluttertoast.showToast(
            msg: "Order Created Successfully",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.green,
            textColor: Colors.white,
            fontSize: 16.0);
        Get.back();
      } else if(response.statusCode == 400){
        PopupLoader.hide();
        Fluttertoast.showToast(
            msg: "Agent Not available",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.TOP,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0);
      }else{
        PopupLoader.hide();
        Fluttertoast.showToast(
            msg: "Transaction failed",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.TOP,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0);
        Get.back();
      }
    } catch (e) {
      PopupLoader.hide();
    }
  }

  double total(){
    double aa=num1 + voucherNum!;

    return valueMultiply*aa;

    return multiplier! ;//+ voucherNum!;
  }


  void getVoucherValidate(String voucher) async {
    try {
      String token = Hive.box('box').get('token');

      String url = '${baseURL}api/v1/get_single_voucher';
      PopupLoader.show();

      final response = await http.post(Uri.parse(url), body: {
        "voucher_no": voucher,
      }, headers: {
        "Accept": "application/json",
        "Authorization": 'Bearer $token'
      });
      var data = jsonDecode(response.body);
      if (response.statusCode == 200) {
        if(data['data']['status']=="used"){
          voucherbool=false;
          voucherNum=0;
          Fluttertoast.showToast(
              msg: "Voucher Used ",
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.BOTTOM,
              timeInSecForIosWeb: 1,
              backgroundColor: Colors.green,
              textColor: Colors.white,
              fontSize: 16.0);
          PopupLoader.hide();
        }else{
          Fluttertoast.showToast(
              msg: "Voucher Active ",
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.BOTTOM,
              timeInSecForIosWeb: 1,
              backgroundColor: Colors.green,
              textColor: Colors.white,
              fontSize: 16.0);
          PopupLoader.hide();
          setState(() {
            if (data['data']['status'] == 'not-used') {
              voucherNum =  double.parse(data['data']['voucher_percent']) ;
              voucher_id=data['data']['id'];
            }
            voucherbool=true;

          });
          // Get.back();
        }} else {
        remarkController.clear();
        Fluttertoast.showToast(
            msg: "Voucher Used",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.TOP,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0);
        PopupLoader.hide();
        // Get.back();
      }
    } catch (e) {
      PopupLoader.hide();
    }
  }



}
class selectnetwork extends StatelessWidget {
  final String imageurl;
  final String networkname;
  final BoxFit fit;
  final bool isSelected;
  final VoidCallback onTap;

  const selectnetwork({
    Key? key,
    required this.imageurl,
    required this.networkname,
    required this.fit,
    required this.isSelected,
    required this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Card(
        elevation: isSelected ? 10 : 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        color: isSelected ? Colors.deepOrangeAccent : Colors.white,
        child: Column(
          children: [
            Image.asset(
              imageurl,
              fit: fit,
              height: 50,
              width: 50,
            ).pSymmetric(h: 10),
            Text(
              networkname,
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
          ],
        ).p(5),
      ),
    );
  }
}

