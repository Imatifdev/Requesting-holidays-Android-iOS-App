// ignore_for_file: non_constant_identifier_names, prefer_const_constructors, unnecessary_string_interpolations

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:transactionsapp/models/myorder_model.dart';
import 'package:transactionsapp/networks/apicall.dart';
import 'package:transactionsapp/widgets/photo_widget.dart';

import '../utils/theme.dart';

class UserDetailsScreen extends StatefulWidget {
  final MyOrderList orderByUsertype;
  const UserDetailsScreen({super.key, required this.orderByUsertype});

  @override
  State<UserDetailsScreen> createState() => _UserDetailsScreenState();
}

class _UserDetailsScreenState extends State<UserDetailsScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [AppTheme.profilecardgrad1, AppTheme.profilecardgrad2]),
          ),
        ),
        title: const Text('About Order'),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ResuableRow(
                  title: 'Order Id',
                  value: widget.orderByUsertype.id.toString()),
              ResuableRow(
                  title: 'Bank Title',
                  value: widget.orderByUsertype.bankTitle ?? ''),
              ResuableRow(
                  title: 'Order Type',
                  value: widget.orderByUsertype.orderType.toString()),
              ResuableRow(
                title: 'Order Status',
                value: widget.orderByUsertype.orderStatus.toString(),
                color: widget.orderByUsertype.orderStatus == 'Pending'
                    ? Colors.redAccent
                    : widget.orderByUsertype.orderStatus == 'Completed'
                        ? Colors.green
                        : Colors.red,
              ),
              ResuableRow(
                  title: 'Date',
                  value: widget.orderByUsertype.createdAt!
                      .toString()
                      .substring(0, 7)),
              widget.orderByUsertype.orderType =="Created By Admin"?ResuableRow(
                  title: 'Amount in SAR',
                  value: widget.orderByUsertype.amountAfterConvert.toString()):
              ResuableRow(
                  title: 'Amount in PKR',
                  value: widget.orderByUsertype.amount.toString()),
              ResuableRow(
                  title: 'Tax ',
                  value:  '${widget.orderByUsertype.tax.toString()}'),
              widget.orderByUsertype.orderType =="Created By Admin"?
              ResuableRow(
                  title: 'Total in SAR ',
                  value:
                  ' ${addMethod(widget.orderByUsertype.amountAfterConvert.toString(), widget.orderByUsertype.tax.toString()).toString()}'):
              ResuableRow(
                  title: 'Total Amount ',
                  value:
                      ' ${addMethod(widget.orderByUsertype.amount.toString(), widget.orderByUsertype.tax.toString()).toString()}'),
              ResuableRow(
                  title: 'phone Number',
                  value: widget.orderByUsertype.phoneNumber.toString()),
              widget.orderByUsertype.orderType == 'Wallet Transfer'
                  ? ResuableRow(
                      title: 'name',
                      value: widget.orderByUsertype.name.toString())
                  : widget.orderByUsertype.orderType == 'Bank Transfer'
                      ? ResuableRow(
                          title: 'name',
                          value: widget.orderByUsertype.name.toString())
                      : Container(),
              ResuableRow(
                  title: 'Network',
                  value: widget.orderByUsertype.orderType == 'Wallet Transfer'
                      ? widget.orderByUsertype.vTransferAccType ?? 'Empty'
                      : widget.orderByUsertype.mTransferNetworkType ?? 'Empty'),
              Row(
                children: [
                  const Text('Customer  Attachment',
                      style: TextStyle(
                          fontSize: 16,
                          color: Colors.black,
                          fontWeight: FontWeight.bold)),
                  const Spacer(),
                  SizedBox(
                    height: 34,
                    width: 80,
                    child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xff4a4a4a)),
                        onPressed: widget.orderByUsertype.bTransferImg == null
                            ? () {
                          Fluttertoast.showToast(
                              msg:
                              "No Attachement Available",
                              toastLength: Toast.LENGTH_SHORT,
                              gravity: ToastGravity.BOTTOM,
                              timeInSecForIosWeb: 1,
                              backgroundColor: Colors.green,
                              textColor: Colors.white,
                              fontSize: 16.0);
                        }
                            : () {
                          Get.to(() => PhotoViewScreen(
                              image:
                              widget.orderByUsertype.bTransferImg ??
                                  'Something went wrong',
                              image2:
                              widget.orderByUsertype.bTransferImg2 ??
                                  'Something went wrong',
                              image3:
                              widget.orderByUsertype.bTransferImg3 ??
                                  'Something went wrong'));
                        },
                        child: const Text(
                          'View ',
                          style: TextStyle(
                              fontSize: 15, fontWeight: FontWeight.bold),
                        )),
                  ),
                ],
              ),
              SizedBox(
                height: 12,
              ),
              //agent
              Center(
                child: Text('About Agent',
                    style: const TextStyle(
                        fontSize: 20,
                        color: Color(0xff1f1f1f),
                        fontWeight: FontWeight.bold)),
              ),
              ResuableRow(
                  title: 'Order Id',
                  value: widget.orderByUsertype.id.toString()),
              ResuableRow(
                  title: 'Order Type',
                  value: widget.orderByUsertype.orderType.toString()),

              ResuableRow(
                  title: 'Date',
                  value: widget.orderByUsertype.createdAt!
                      .toString()
                      .substring(0, 7)),
              ResuableRow(
                  title: 'Amount',
                  value: widget.orderByUsertype.amount.toString()),
              ResuableRow(
                  title: 'Agent Trancaction id',
                  value: widget.orderByUsertype.agentTransectionId ?? 'Empty'),
              widget.orderByUsertype.agentEvidenceImage == null
                  ? Container()
                  : widget.orderByUsertype.orderStatus == 'Completed'
                      ? Row(
                          children: [
                            const Text('Agent  Attachment',
                                style: TextStyle(
                                    fontSize: 16,
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold)),
                            const Spacer(),
                            SizedBox(
                              height: 34,
                              width: 80,
                              child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                      backgroundColor: Color(0xff4a4a4a)),
                                  onPressed: () {
                                    Get.to(() => PhotoViewScreen(
                                        image: widget
                                            .orderByUsertype.agentEvidenceImage
                                            .toString(),
                                        image2: "",
                                        image3: "",)
                                    );},
                                  child: const Text(
                                    'View ',
                                    style: TextStyle(
                                        fontSize: 15,
                                        fontWeight: FontWeight.bold),
                                  )),
                            ),
                          ],
                        )
                      : Row(
                          children: [
                            const Text('Agent  Attachment',
                                style: TextStyle(
                                    fontSize: 16,
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold)),
                            const Spacer(),
                            SizedBox(
                              height: 34,
                              width: 80,
                              child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                      backgroundColor: Color(0xff4a4a4a)),
                                  onPressed: () {
                                    Fluttertoast.showToast(
                                        msg: "Your Order Status is Pending",
                                        toastLength: Toast.LENGTH_SHORT,
                                        gravity: ToastGravity.BOTTOM,
                                        timeInSecForIosWeb: 1,
                                        backgroundColor: Colors.redAccent,
                                        textColor: Colors.white,
                                        fontSize: 16.0);
                                  },
                                  child: const Text(
                                    'View ',
                                    style: TextStyle(
                                        fontSize: 15,
                                        fontWeight: FontWeight.bold),
                                  )),
                            ),
                          ],
                        ),
              ResuableRow(
                  title: 'Agent Remark',
                  value: widget.orderByUsertype.agentRemarks ?? 'Empty')
            ],
          ),
        ),
      ),
    );
  }

  addMethod(String amount, String tax) {
    double value = double.parse(amount) + double.parse(tax);
    return value;
  }
  multiplymethod(String amount, String rate) {
    double value = double.parse(amount) + double.parse(rate);
    return value;
  }

  String humanReadableTime(double dt) {
    DateTime dateTime = DateTime.fromMillisecondsSinceEpoch(dt as int);
    return DateFormat('dd MM yyyy').format(dateTime);
  }
}

ResuableRow({
  required String title,
  required String value,
  Color color = Colors.black,
}) {
  return Padding(
    padding: const EdgeInsets.all(5),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(
              fontSize: 16, color: Colors.black, fontWeight: FontWeight.bold),
        ),
        const Spacer(),
        Text(
          value,
          style: TextStyle(
              fontSize: 16, color: color, fontWeight: FontWeight.w500),
        )
      ],
    ),
  );
}
