// ignore_for_file: prefer_const_literals_to_create_immutables, prefer_const_constructors, unnecessary_new, sort_child_properties_last, depend_on_referenced_packages

import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:transactionsapp/Auth__Screens/user_login.dart';
import 'package:transactionsapp/screens/partially_completed.dart';
import 'package:velocity_x/velocity_x.dart';

import 'package:transactionsapp/Auth__Screens/homeauth.dart';
import 'package:transactionsapp/utils/theme.dart';
import 'package:transactionsapp/widgets/all_order_screen.dart';
import 'package:transactionsapp/widgets/complete_order_screen.dart';
import 'package:transactionsapp/widgets/pending_order_screen.dart';

import '../controller/getbalance_controller.dart';
import '../models/current_balance_model.dart';
import '../models/getspecificorderbyusertype.dart';
import '../models/home_model.dart';
import '../networks/apicall.dart';
import '../widgets/customtext.dart';
import 'package:http/http.dart' as http;

class AgentHome extends StatefulWidget {
  const AgentHome({super.key});

  @override
  State<AgentHome> createState() => _AgentHomeState();
}

class _AgentHomeState extends State<AgentHome> {
  String? name, userType, agentType;

  StreamController<HomeModel> streamController4 = StreamController();
  Timer? _timer;
  @override
  void initState() {
    super.initState();
    name = Hive.box('box').get('name');
    userType = Hive.box('box').get('userType');
    agentType = Hive.box('box').get('agentType');

    getCurrentBalance();
    _timer = Timer.periodic(const Duration(seconds: 6), (timer) {
      getCurrentBalance();
    });
  }

  @override
  void dispose() {
    super.dispose();

    _timer?.cancel();
  }

  GetSpecificOrderByUsertype? orderByUsertype;

  @override
  Widget build(BuildContext context) {
    if (kDebugMode) {
      print('object');
    }
    return new DefaultTabController(
      length: 4,
      child: new Scaffold(
        appBar: new AppBar(
          flexibleSpace: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    AppTheme.profilecardgrad1,
                    AppTheme.profilecardgrad2
                  ]),
            ),
          ),
          leading: Image(
            image: AssetImage("assets/images/applogo.png"),
          ).pOnly(left: 10),
          toolbarHeight: 140,
          title: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0).copyWith(bottom: 0, left: 0),
                child: Row(
                  children: [
                    Text(
                      'Agent Id: ',
                      style: TextStyle(fontSize: 15),
                    ),
                    Text(
                      name ?? 'name',
                      style: TextStyle(fontSize: 15),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0).copyWith(bottom: 4, left: 0),
                child: Row(
                  children: [
                    Text(
                      'Type : ',
                      style: TextStyle(fontSize: 14),
                    ),
                    Text(
                      userType ?? "usertype",
                      style: TextStyle(fontSize: 14),
                    ),
                  ],
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Expanded(
                    child: Text(
                      "Current Balance ",
                      style: TextStyle(fontSize: 16),
                    ),
                  ),
                  StreamBuilder<HomeModel>(
                    stream: streamController4.stream,
                    builder: (context, snapshot) {
                      if (snapshot.hasData) {
                        switch (snapshot.connectionState) {
                          case ConnectionState.waiting:
                            return Center(
                              child: CircularProgressIndicator(
                                color: Colors.white,
                              ),
                            );

                          default:
                            if (snapshot.hasError) {
                              return const Center(
                                child: Text('data'),
                              );
                            } else {
                              HomeModel currentBalance =
                              snapshot.data as HomeModel;
                              return CustomText(
                                  TextValue:
                                  "${currentBalance.data!.balance?.balanceAmount ?? '0.01'}PKR",
                                  fontweight: FontWeight.w500,
                                  TextColor: Colors.white,
                                  fontsize: 16)
                                  .pOnly(right: 50);
                            }
                        }
                      }
                      return Center(
                        child: CircularProgressIndicator(
                          color: Colors.white,
                        ),
                      );
                    },
                  )
                ],
              ),
              Padding(
                padding: const EdgeInsets.all(8.0).copyWith(top: 4, left: 0),
                child: Text(
                  agentType ?? 'agent',
                  style: TextStyle(fontSize: 20),
                ),
              ),
            ],
          ),
          actions: [
            IconButton(
              onPressed: () {
                Hive.box('box').clear();
                Fluttertoast.showToast(
                    msg: "Agent LogOut",
                    toastLength: Toast.LENGTH_SHORT,
                    gravity: ToastGravity.BOTTOM,
                    timeInSecForIosWeb: 1,
                    backgroundColor: Colors.green,
                    textColor: Colors.white,
                    fontSize: 16.0);
                Get.offAll(() => LoginPage());
              },
              icon: Icon(
                Icons.logout,
              ),
            ),
          ],
          bottom: TabBar(
            tabs: [
              Tab(
                child: Column(
                  children: [Icon(Icons.timer), Text("Pending",style: TextStyle(fontSize: 13),)],
                ),
              ),
              Tab(
                child: Column(
                  children: [Icon(Icons.done), Text("Complete",style: TextStyle(fontSize: 13),)],
                ),
              ),
              Tab(
                child: Column(
                  children: [Icon(Icons.all_inbox), Text("All Orders",style: TextStyle(fontSize: 13),)],
                ),
              ),
              Tab(
                child: Column(
                  children: [Icon(Icons.all_inbox), Text("Partially",style: TextStyle(fontSize: 13),)],
                ),
              ),
            ],
          ),
        ),
        body: Padding(
          padding: const EdgeInsets.all(6.0),
          child: TabBarView(
            children: [PendingScreen(), CompleteScreen(), AllOrderScreen(),PartiallyCompletedView()],
          ),
        ),
      ),
    );
  }

  getCurrentBalance() async {
    String token = Hive.box('box').get('token');
    String url = '${baseURL}api/v1/get_user_balance';

    final response = await http.get(Uri.parse(url), headers: {
      "Accept": "application/json",
      "Authorization": 'Bearer $token'
    });
    if (response.statusCode == 200) {
      var data = jsonDecode(response.body);
      HomeModel hm=HomeModel.fromJson(data);
      String? checkStatus=hm.data?.userStatus?.status.toString();
      streamController4.sink.add(hm);
      var data2=data["user_status"];

    };
  }
}



// Widget CompletedOrder() {
//   return ListView.builder(
//       itemCount: 3,
//       itemBuilder: (BuildContext context, int index) {
//         return Card(
//           color: Colors.greenAccent,
//           elevation: 10,
//           shape:
//               RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
//           child: Padding(
//             padding: const EdgeInsets.all(8.0),
//             child: SizedBox(
//               height: 100,
//               width: double.infinity,
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   Text(
//                     "Telenor load transfer",
//                     style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
//                   ),
//                   Text(
//                     "Muhammad",
//                     style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
//                   ),
//                 ],
//               ),
//             ),
//           ),
//         );
//       });
// }

// Widget PendingOrder() {
//   return ListView.builder(
//       itemCount: 2,
//       itemBuilder: (BuildContext context, int index) {
//         return Card(
//           color: Colors.greenAccent,
//           elevation: 10,
//           shape:
//               RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
//           child: Padding(
//             padding: const EdgeInsets.all(8.0),
//             child: SizedBox(
//               height: 100,
//               width: double.infinity,
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   Text(
//                     "Telenor load transfer",
//                     style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
//                   ),
//                   Text(
//                     "Muhammad",
//                     style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
//                   ),
//                 ],
//               ),
//             ),
//           ),
//         );
//       });
// }
