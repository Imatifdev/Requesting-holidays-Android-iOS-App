// To parse this JSON data, do
//
//     final welcome = welcomeFromJson(jsonString);

import 'dart:convert';

OderDataModel welcomeFromJson(String str) => OderDataModel.fromJson(json.decode(str));

String welcomeToJson(OderDataModel data) => json.encode(data.toJson());

class OderDataModel {
  OderDataModel({
    required this.success,
    required this.data,
    required this.message,
  });

  bool success;
  List<Datum> data;
  String message;

  factory OderDataModel.fromJson(Map<String, dynamic> json) => OderDataModel(
    success: json["success"],
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
    message: json["message"],
  );

  Map<String, dynamic> toJson() => {
    "success": success,
    "data": List<dynamic>.from(data.map((x) => x.toJson())),
    "message": message,
  };
}

class Datum {
  Datum({
    required this.id,
    required this.orderType,
    this.supType,
    required this.depositerId,
    this.resolveAgentId,
    this.resolveDate,
    required this.depositerCurrency,
    this.agentCurrency,
    required this.amount,
    required this.convertRate,
    required this.amountAfterConvert,
    required this.orderStatus,
    this.agentTransectionId,
    required this.createdAt,
    required this.updatedAt,
  });

  int id;
  String orderType;
  dynamic supType;
  String depositerId;
  String? resolveAgentId;
  DateTime? resolveDate;
  String depositerCurrency;
  String? agentCurrency;
  String amount;
  String convertRate;
  String amountAfterConvert;
  String orderStatus;
  String? agentTransectionId;
  DateTime createdAt;
  DateTime updatedAt;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    id: json["id"],
    orderType: json["order_type"],
    supType: json["sup_type"],
    depositerId: json["depositer_id"],
    resolveAgentId: json["resolve_agent_id"],
    resolveDate: json["resolve_date"] == null ? null : DateTime.parse(json["resolve_date"]),
    depositerCurrency: json["depositer_currency"],
    agentCurrency: json["agent_currency"],
    amount: json["amount"],
    convertRate: json["convert_rate"],
    amountAfterConvert: json["amount_after_convert"],
    orderStatus: json["order_status"],
    agentTransectionId: json["agent_transection_id"],
    createdAt: DateTime.parse(json["created_at"]),
    updatedAt: DateTime.parse(json["updated_at"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "order_type": orderType,
    "sup_type": supType,
    "depositer_id": depositerId,
    "resolve_agent_id": resolveAgentId,
    "resolve_date": resolveDate?.toIso8601String(),
    "depositer_currency": depositerCurrency,
    "agent_currency": agentCurrency,
    "amount": amount,
    "convert_rate": convertRate,
    "amount_after_convert": amountAfterConvert,
    "order_status": orderStatus,
    "agent_transection_id": agentTransectionId,
    "created_at": createdAt.toIso8601String(),
    "updated_at": updatedAt.toIso8601String(),
  };
}
