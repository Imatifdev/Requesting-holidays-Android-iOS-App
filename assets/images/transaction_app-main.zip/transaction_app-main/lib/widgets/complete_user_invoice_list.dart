import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:transactionsapp/models/myorder_model.dart';
import 'package:transactionsapp/networks/apicall.dart';
import 'package:http/http.dart' as http;
import 'package:transactionsapp/screens/user_details_screen.dart';
import 'package:transactionsapp/utils/theme.dart';

class CompleteInvoiceScreen extends StatefulWidget {
  const CompleteInvoiceScreen({
    super.key,
  });

  @override
  State<CompleteInvoiceScreen> createState() => _CompleteInvoiceScreenState();
}

class _CompleteInvoiceScreenState extends State<CompleteInvoiceScreen> {
  StreamController? _controller;
  Stream? _stream;

  @override
  void initState() {
    _controller = StreamController();
    _stream = _controller!.stream;

    super.initState();
    getMyOrder();
  }

  getMyOrder() async {
    try {
      var token = Hive.box('box').get('token');
      _controller!.add('loading');
      String url = '${baseURL}api/v1/get_my_order';
      final response = await http.get(
        Uri.parse(url),
        headers: {
          "Accept": "application/json",
          "Authorization": 'Bearer $token'
        },
      );
      if (response.statusCode == 200) {
        var jsonResponse = jsonDecode(response.body);
        MyOrderModel orderModel = MyOrderModel.fromJson(jsonResponse);
        _controller!.add(orderModel);
      } else {
        _controller!.add('wrong');
      }
    } catch (e) {
      _controller!.add('wrong');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green,
        title: const Text('Complete Invoice List   '),
      ),
      body: StreamBuilder(
        stream: _stream,
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            if (snapshot.data == 'loading') {
              return const Center(
                child: CircularProgressIndicator(),
              );
            } else if (snapshot.data == 'wrong') {
              return const Center(
                child: Text('something went wrong'),
              );
            } else {
              List<MyOrderList> completedList = [];

              MyOrderModel orderByUsertype = snapshot.data as MyOrderModel;

              completedList = orderByUsertype.data!
                  .where((element) => element.orderStatus == 'Completed')
                  .toList();
              if (completedList.isEmpty) {
                return const Center(
                  child: Text('List is Empty'),
                );
              }
              return Padding(
                padding: const EdgeInsets.all(8.0),
                child: ListView.builder(
                    physics: const BouncingScrollPhysics(),
                    itemCount: completedList.length,
                    itemBuilder: (BuildContext context, int index) {
                      var myOrderList = completedList[index];
                      return GestureDetector(
                        onTap: () {
                          Get.to(
                            () => UserDetailsScreen(
                              orderByUsertype: myOrderList,
                            ),
                          );
                        },
                        child: Card(
                          color: AppTheme.dropdowncolo,
                          elevation: 4,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8)),
                          child: Padding(
                            padding: const EdgeInsets.all(3.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Row(
                                    children: [
                                      const Text(
                                        'Order Type',
                                        style: TextStyle(
                                            fontSize: 16,
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold),
                                      ),
                                      const Spacer(),
                                      Text(
                                        myOrderList.orderType.toString(),
                                        style: const TextStyle(
                                            fontSize: 16,
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold),
                                      )
                                    ],
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.all(8.0)
                                      .copyWith(top: 0),
                                  child: Row(
                                    children: [
                                      const Text(
                                        'Amount',
                                        style: TextStyle(
                                            fontSize: 15,
                                            fontWeight: FontWeight.bold),
                                      ),
                                      const Spacer(),
                                      Text(
                                        myOrderList.amount.toString(),
                                        style: const TextStyle(
                                            fontSize: 15,
                                            fontWeight: FontWeight.bold),
                                      ),
                                    ],
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.all(8.0)
                                      .copyWith(top: 0),
                                  child: Row(
                                    children: [
                                      const Text(
                                        'Order Status',
                                        style: TextStyle(
                                            fontSize: 15,
                                            fontWeight: FontWeight.bold),
                                      ),
                                      const Spacer(),
                                      Text(
                                        myOrderList.orderStatus.toString(),
                                        style: TextStyle(
                                            fontSize: 15,
                                            color: myOrderList.orderStatus ==
                                                    'Pending'
                                                ? Colors.redAccent
                                                : myOrderList.orderStatus ==
                                                        'Completed'
                                                    ? Colors.green
                                                    : Colors.black12,
                                            fontWeight: FontWeight.bold),
                                      )
                                    ],
                                  ),
                                )
                              ],
                            ),
                          ),
                        ),
                      );
                    }),
              );
            }
          }
          return const Center(
            child: Text('something went wrong'),
          );
        },
      ),
    );
  }
}
