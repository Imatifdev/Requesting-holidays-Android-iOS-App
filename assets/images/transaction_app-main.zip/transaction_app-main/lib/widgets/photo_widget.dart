import 'package:flutter/material.dart';
import 'package:photo_view/photo_view.dart';
import 'package:transactionsapp/networks/apicall.dart';
import 'package:dots_indicator/dots_indicator.dart';

class PhotoViewScreen extends StatefulWidget {
  String image;
  String image2;
  String image3;
  PhotoViewScreen({Key? key, required this.image, required this.image2, required this.image3});

  @override
  State<PhotoViewScreen> createState() => _PhotoViewScreenState();
}

class _PhotoViewScreenState extends State<PhotoViewScreen> {
  List<String> images = [];
  int currentPageIndex = 0;

  @override
  void initState() {
    super.initState();
    // Add the images to the images list if they are not null or empty
    if (widget.image.isNotEmpty) {
      images.add(widget.image);
    }
    if (widget.image2.isNotEmpty) {
      images.add(widget.image2);
    }
    if (widget.image3.isNotEmpty) {
      images.add(widget.image3);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          PageView.builder(
            itemCount: images.length,
            onPageChanged: (index) {
              setState(() {
                currentPageIndex = index;
              });
            },
            itemBuilder: (context, index) {
              return PhotoView(
                imageProvider: NetworkImage('${baseURL}public/${images[index]}'),
              );
            },
          ),
          Positioned(
            bottom: 20,
            left: 0,
            right: 0,
            child: Center(
              child: DotsIndicator(
                dotsCount: images.length,
                position: currentPageIndex.toInt(),
                decorator: DotsDecorator(
                  activeColor: Colors.deepOrangeAccent,
                  activeSize: const Size(12, 12),
                  spacing: const EdgeInsets.all(4),
                  color: Colors.grey,
                  size: const Size(8, 8),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
