// ignore_for_file: public_member_api_docs, sort_constructors_first, non_constant_identifier_names
import 'package:flutter/material.dart';

class CustomText extends StatelessWidget {
  final String TextValue;
  final FontWeight fontweight;
  final Color TextColor;
  final double fontsize;
  const CustomText({
    Key? key,
    required this.TextValue,
    required this.fontweight,
    required this.TextColor,
    required this.fontsize,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Text(
      TextValue,
      style: TextStyle(
          fontSize: fontsize, fontWeight: fontweight, color: TextColor),
    );
  }
}
