// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'package:flutter/material.dart';
import 'package:transactionsapp/utils/theme.dart';

class CustomBtn extends StatelessWidget {
  final double height;
  final double width;
  final double radius;
  final Color btncol;
  final Color btntxtcol;
  final String btntxt;
  final double btntextsize;
  final VoidCallback onTap;
  final FontWeight fontw;
  const CustomBtn({
    Key? key,
    required this.height,
    required this.width,
    required this.radius,
    required this.btncol,
    required this.btntxtcol,
    required this.btntxt,
    required this.btntextsize,
    required this.onTap,
    required this.fontw,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
        splashColor: AppTheme.darkbg,
        onTap: onTap,
        child: Container(
          height: height,
          width: width,
          decoration: BoxDecoration(
            color: btncol,
            borderRadius: BorderRadius.circular(radius),
          ),
          child: Center(
            child: Text(
              btntxt,
              style: TextStyle(
                color: btntxtcol,
                fontSize: btntextsize,
                fontWeight: fontw,
              ),
            ),
          ),
        ));
  }
}
