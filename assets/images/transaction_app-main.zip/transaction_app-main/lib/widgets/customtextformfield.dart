// ignore_for_file: public_member_api_docs, sort_constructors_first, non_constant_identifier_names
// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';

Widget textformfeild({
  required boolTitleShowHide,
  required fieldName,
  hint_text,
  rightLabel = "",
  icon,
  padding,
  required Function? returnDatacall,
}) {
  return Container(
    height: boolTitleShowHide ? 138 : 100,
    padding:
        padding ?? const EdgeInsets.only(left: 8, right: 8, top: 0, bottom: 0),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        boolTitleShowHide
            ? Padding(
                padding: const EdgeInsets.only(bottom: 5),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      fieldName,
                      style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w600,
                          fontSize: 16),
                    ),
                  ],
                ),
              )
            : Container(
                height: 10,
              ),
        TextFormField(
          autovalidateMode: AutovalidateMode.onUserInteraction,
          maxLength: fieldName =="User_code"?5:8,
          validator: (value) {
            if (value == null || value.isEmpty) {
              return "$fieldName  Required";
            }
            if (fieldName == "Client Id" || fieldName == "Email") {
              if (value.contains("A")) {
                return ("Agent not allowed");
              }
            }
            if (fieldName == "Client Id" || fieldName == "Email") {
              if (!value.startsWith("C") || value.length != 5) {
                return "ID must be a valid 5-digit value";
              }

            }
            return null;
          },
          decoration: InputDecoration(
            fillColor: Colors.white,
            filled: true,
            hintStyle: const TextStyle(fontSize: 14, color: Colors.black45),
            focusedBorder: OutlineInputBorder(
              borderSide: BorderSide(color: Colors.grey, width: 2.0),
              borderRadius: BorderRadius.circular(15.0),
            ),
            hintText: hint_text,
            border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15.0),
                borderSide: BorderSide(color: Colors.grey)),
            helperStyle: const TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
          ),
          onChanged: (val) {
            returnDatacall!(val);
          },
        ),
        InkWell(
          child: Align(
            alignment: Alignment.bottomRight,
            child: Text(
              rightLabel,
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  decoration: TextDecoration.underline),
            ),
          ),
          onTap: () {},
        ),
      ],
    ),
  );
}

Widget Agentformfeild({
  required boolTitleShowHide,
  required fieldName,
  hint_text,
  rightLabel = "",
  icon,
  padding,
  required Function? returnDatacall,
}) {
  return Container(
    height: boolTitleShowHide ? 138 : 100,
    padding:
        padding ?? const EdgeInsets.only(left: 8, right: 8, top: 0, bottom: 0),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        boolTitleShowHide
            ? Padding(
                padding: const EdgeInsets.only(bottom: 5),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      fieldName,
                      style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w600,
                          fontSize: 16),
                    ),
                  ],
                ),
              )
            : Container(
                height: 10,
              ),
        TextFormField(
          autovalidateMode: AutovalidateMode.onUserInteraction,
          maxLength: fieldName =="User_code"?5:8,
          validator: (value) {
            if (value == null || value.isEmpty) {
              return "$fieldName  Required";
            }
            if (fieldName == "Agent Id" || fieldName == "Email") {
              if (value.contains("C")) {
                return ("Client not allowed");
              }
            }
            if (fieldName == "Agent Id" || fieldName == "Email") {
              if (!value.startsWith("A") || value.length != 5) {
                return "ID must be a valid 5-digit value";
              }

            }

            return null;
          },
          decoration: InputDecoration(
            fillColor: Colors.white,
            filled: true,
            hintStyle: const TextStyle(fontSize: 14, color: Colors.black45),
            focusedBorder: OutlineInputBorder(
              borderSide: BorderSide(color: Colors.grey, width: 2.0),
              borderRadius: BorderRadius.circular(15.0),
            ),


            hintText: hint_text,
            border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15.0),
                borderSide: BorderSide(color: Colors.grey)),
            helperStyle: const TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
          ),

          onChanged: (val) {
            returnDatacall!(val);
          },
        ),
        InkWell(
          child: Align(
            alignment: Alignment.bottomRight,
            child: Text(
              rightLabel,
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  decoration: TextDecoration.underline),
            ),
          ),
          onTap: () {},
        ),
      ],
    ),
  );
}
