// ignore_for_file: prefer_const_constructors, camel_case_types

import 'package:flutter/material.dart';

class passfieldwidget extends StatefulWidget {
  final TextEditingController controller;
  final FormFieldValidator? validate;
  const passfieldwidget({
    Key? key,
    required this.controller,
    this.validate,
  }) : super(key: key);

  @override
  State<passfieldwidget> createState() => _passfieldwidgetState();
}

class _passfieldwidgetState extends State<passfieldwidget> {
  bool _ispasshidden = true;

  void _togglePasswordView() {
    setState(() {
      _ispasshidden = !_ispasshidden;
    });
  }

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      obscureText: _ispasshidden,
      keyboardType: TextInputType.visiblePassword,
      decoration: InputDecoration(
        suffixIcon: InkWell(
          onTap: _togglePasswordView,
          child: Icon(
            _ispasshidden ? Icons.visibility : Icons.visibility_off,
          ),
        ),
        hintText: "a124266",
        fillColor: Colors.white,
        focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(width: 1, color: Colors.white)),
        border: OutlineInputBorder(
            borderSide: BorderSide(width: 1, color: Colors.white),
            borderRadius: BorderRadius.circular(20)),
        filled: true,
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(20),
          borderSide: BorderSide(width: 1, color: Colors.white),
        ),
        errorBorder: OutlineInputBorder(
          //<-- SEE HERE
          borderSide: BorderSide(width: 3, color: Colors.redAccent),
        ),
      ),
    );
  }
}
