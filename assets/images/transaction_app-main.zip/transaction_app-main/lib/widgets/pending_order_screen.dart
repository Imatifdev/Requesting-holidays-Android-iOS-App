import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:hive/hive.dart';
import 'package:transactionsapp/models/getspecificorderbyusertype.dart';
import 'package:http/http.dart' as http;
import 'package:transactionsapp/networks/apicall.dart';

import 'package:transactionsapp/screens/update_agent_screen.dart';
import 'package:shimmer/shimmer.dart';

class PendingScreen extends StatefulWidget {
  const PendingScreen({
    Key? key,
  }) : super(key: key);

  @override
  State<PendingScreen> createState() => _PendingScreenState();
}

class _PendingScreenState extends State<PendingScreen> {
  StreamController<GetSpecificOrderByUsertype> streamController1 =
      StreamController();
  Timer? _timer;
  @override
  void initState() {
    super.initState();
    orderFetch();
    _timer = Timer.periodic(const Duration(seconds: 4), (timer) {
      orderFetch();
    });
  }

  @override
  void dispose() {
    super.dispose();
    _timer?.cancel();
    streamController1.close();
  }

  @override
  Widget build(BuildContext context) {
    return
      Scaffold(
            body: StreamBuilder<GetSpecificOrderByUsertype>(
              stream: streamController1.stream,
              builder: (context, snapshot) {
                if (snapshot.hasData) {
                  switch (snapshot.connectionState) {
                    case ConnectionState.waiting:
                      return ListView.builder(
                        itemCount: 4,
                        itemBuilder: (context, index) {
                          return Shimmer.fromColors(
                            baseColor: Colors.grey.shade700,
                            highlightColor: Colors.grey.shade100,
                            enabled: true,
                            child: Column(
                              children: [
                                ListTile(
                                  leading: Container(
                                    height: 50,
                                    width: 50,
                                    color: Colors.white,
                                  ),
                                  title: Container(
                                    width: 100,
                                    height: 8.0,
                                    color: Colors.white,
                                  ),
                                  subtitle: Container(
                                    width: double.infinity,
                                    height: 8.0,
                                    color: Colors.white,
                                  ),
                                ),
                              ],
                            ),
                          );
                        },
                      );

                    default:
                      if (snapshot.hasError) {
                        return const Center(
                          child: Text('data'),
                        );
                      } else {
                        GetSpecificOrderByUsertype specificOrderByUsertype =
                            snapshot.data!;
                        List<GetSpecificOrderByUsertypeList> pendingList = [];
                        pendingList = specificOrderByUsertype.data!
                            .where(
                                (element) => element.orderStatus == 'Pending')
                            .toList();

                        if (pendingList.isEmpty) {
                          return const Center(
                            child: Text('Empty List'),
                          );
                        }
                        return ListView.builder(
                            shrinkWrap: true,
                            scrollDirection: Axis.vertical,
                            physics: const BouncingScrollPhysics(),
                            itemCount: pendingList.length,
                            itemBuilder: (BuildContext context, int index) {
                              var specificOrderByUsertypeList =
                                  pendingList[index];
                              return GestureDetector(
                                onTap: () {
                                  Get.to(AgentUpdateScreen(orderByUsertype: specificOrderByUsertypeList));
                                },
                                child: Card(
                                  color: specificOrderByUsertypeList
                                              .request_for_cancel ==
                                          '1'
                                      ? Colors.deepOrangeAccent.shade100
                                      : Colors.grey.shade300,
                                  elevation: 2,
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(12)),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Padding(
                                        padding: const EdgeInsets.all(8.0)
                                            .copyWith(bottom: 0),
                                        child: Row(
                                          children: [
                                            const Text(
                                              'Order Id',
                                              style: TextStyle(
                                                  fontSize: 16,
                                                  color: Colors.black,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                            const Spacer(),
                                            Text(
                                              specificOrderByUsertypeList.id
                                                  .toString(),
                                              style: const TextStyle(
                                                  fontSize: 16,
                                                  color: Colors.black,
                                                  fontWeight: FontWeight.bold),
                                            )
                                          ],
                                        ),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Row(
                                          children: [
                                            const Text(
                                              'Order Type',
                                              style: TextStyle(
                                                  fontSize: 16,
                                                  color: Colors.black,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                            const Spacer(),
                                            Text(
                                              specificOrderByUsertypeList
                                                  .orderType
                                                  .toString(),
                                              style: const TextStyle(
                                                  fontSize: 16,
                                                  color: Colors.black,
                                                  fontWeight: FontWeight.bold),
                                            )
                                          ],
                                        ),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Row(
                                          children: [
                                            const Text(
                                              'Account No',
                                              style: TextStyle(
                                                  fontSize: 16,
                                                  color: Colors.black,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                            const Spacer(),
                                            Text(
                                              specificOrderByUsertypeList
                                                  .phoneNumber
                                                  .toString(),
                                              style: const TextStyle(
                                                  fontSize: 16,
                                                  color: Colors.black,
                                                  fontWeight: FontWeight.bold),
                                            )
                                          ],
                                        ),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.all(8.0)
                                            .copyWith(top: 0),
                                        child: Row(
                                          children: [
                                            const Text(
                                              'Amount',
                                              style: TextStyle(
                                                  fontSize: 15,
                                                  color: Colors.black,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                            const Spacer(),
                                            Text(
                                              'Pkr: ${specificOrderByUsertypeList.amount.toString()}',
                                              style: const TextStyle(
                                                  fontSize: 15,
                                                  color: Colors.black,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                          ],
                                        ),
                                      ),
                                      // Padding(
                                      //   padding:
                                      //       const EdgeInsets.all(8.0).copyWith(top: 0),
                                      //   child: Row(
                                      //     children: [
                                      //       const Text(
                                      //         'Depositer Name',
                                      //         style: TextStyle(
                                      //             fontSize: 15,
                                      //             color: Colors.black,
                                      //             fontWeight: FontWeight.bold),
                                      //       ),
                                      //       const Spacer(),
                                      //       Text(
                                      //         specificOrderByUsertypeList.depositorName
                                      //             .toString(),
                                      //         style: const TextStyle(
                                      //             fontSize: 15,
                                      //             color: Colors.black,
                                      //             fontWeight: FontWeight.bold),
                                      //       )
                                      //     ],
                                      //   ),
                                      // ),
                                      Padding(
                                        padding: const EdgeInsets.all(8.0)
                                            .copyWith(top: 0),
                                        child: Row(
                                          children: [
                                            const Text(
                                              'Date',
                                              style: TextStyle(
                                                  fontSize: 15,
                                                  color: Colors.black,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                            const Spacer(),
                                            Text(
                                              specificOrderByUsertypeList
                                                  .createdAt
                                                  .toString(),
                                              style: const TextStyle(
                                                  fontSize: 15,
                                                  color: Colors.black,
                                                  fontWeight: FontWeight.bold),
                                            )
                                          ],
                                        ),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.all(8.0)
                                            .copyWith(top: 0),
                                        child: Row(
                                          children: [
                                            const Text(
                                              'Order Status',
                                              style: TextStyle(
                                                  fontSize: 15,
                                                  color: Colors.black,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                            const Spacer(),
                                            Text(
                                              specificOrderByUsertypeList
                                                  .orderStatus
                                                  .toString(),
                                              style: TextStyle(
                                                  color:
                                                      specificOrderByUsertypeList
                                                                  .orderStatus ==
                                                              'Pending'
                                                          ? Colors.lime
                                                          : Colors.green,
                                                  fontSize: 15,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                          ],
                                        ),
                                      ),
                                      specificOrderByUsertypeList.orderType ==
                                              'Bank Transfer'
                                          ? ResuableRow(
                                              title: 'order Nature',
                                              value: specificOrderByUsertypeList
                                                  .orderNature
                                                  .toString())
                                          : Container()
                                    ],
                                  ),
                                ),
                              );
                            });
                      }
                  }
                } else if (snapshot.hasError) {
                  return const Center(
                    child: Text('Error'),
                  );
                } else {
                  return ListView.builder(
                    itemCount: 4,
                    itemBuilder: (context, index) {
                      return Shimmer.fromColors(
                        baseColor: Colors.grey.shade700,
                        highlightColor: Colors.grey.shade100,
                        enabled: true,
                        child: Column(
                          children: [
                            ListTile(
                              leading: Container(
                                height: 50,
                                width: 50,
                                color: Colors.white,
                              ),
                              title: Container(
                                width: 100,
                                height: 8.0,
                                color: Colors.white,
                              ),
                              subtitle: Container(
                                width: double.infinity,
                                height: 8.0,
                                color: Colors.white,
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  );
                }
              },
            ),
          );
        // : AgentUpdateScreen(
        //     orderByUsertype: snapshotData!
        //         .data![selectedCardIndex], // Pass the selected data
        //   );
  }

  Future<void> orderFetch() async {
    String token = Hive.box('box').get('token');

    String url = '${baseURL}api/v1/get_specific_order_by_usertype';
    final response = await http.get(
      Uri.parse(url),
      // Send authorization headers to the backend.
      headers: {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
    );
    if (response.statusCode == 200) {
      // If the server did return a 200 OK response,
      // then parse the JSON.
      var data = jsonDecode(response.body);
      GetSpecificOrderByUsertype getSpecificOrderByUsertype =
          GetSpecificOrderByUsertype.fromJson(data);
      streamController1.sink.add(getSpecificOrderByUsertype);
      print(data);
    } else {
      throw Exception('Failed to load data');
    }
  }
}
